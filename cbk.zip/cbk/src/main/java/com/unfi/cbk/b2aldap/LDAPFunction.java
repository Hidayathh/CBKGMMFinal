package com.unfi.cbk.b2aldap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import org.apache.log4j.Logger;

public class LDAPFunction {

	static Logger log = Logger.getLogger(LDAPFunction.class);
	private String userId;
	private String baseDN;
	HashMap<String, String> ldapProMap;
	private LDAPDirectory ldapDir;

	private int scope;

	public LDAPFunction(String userId, HashMap<String, String> ldapProMap) throws Exception {
		this.userId = userId;
		this.ldapProMap = ldapProMap;

		try {
			initialize(ldapProMap);
		} catch (Exception e) {
			throw e;
		}

	}

	private void initialize(HashMap<String, String> ldapProMap) throws Exception {
		if (ldapDir != null)
			return;
		ldapDir = new LDAPDirectory();
		try {
			ldapDir.connect(ldapProMap.get("ldapHostName"), Integer.parseInt(ldapProMap.get("ldapPortNumber")), Integer.parseInt(ldapProMap.get("ldapVersion")),
					ldapProMap.get("ldapUserName"), ldapProMap.get("ldapPassword"));
		} catch (Exception e) {
			ldapDir = null;
			log.error("Exception Not getting LDAP connection (Initialize): " + e);
			throw e;
		}
		baseDN = ldapProMap.get("baseDN");

		// CO 14091
		scope = Integer.parseInt(ldapProMap.get("ldapScope"));
	}

	public void closeLDAPConnection() {
		try {
			if (ldapDir != null) {
				ldapDir.disconnect();
			}
		} catch (Exception e) {
			log.error("Exception in closeLDAPConnection():" + e);
		}
	}

	public String getUserName() throws Exception {
		String userName = null;

		String filterUID = "uid=" + userId;

		Hashtable hashTable = null;
		try {

			if ((hashTable = ldapDir.read(baseDN, filterUID, null, scope)) != null) {
				Object value[] = (Object[]) hashTable.get("cn");
				userName = value == null ? null : value[0].toString();
			}
		} catch (Exception e) {
			throw e;
		}

		if (userName == null) {
			String tMsg = "Error in Getting User Name.  For User Id: \"" + userId
					+ "\" doesn't exist in the LDAP directory.";
			throw new Exception(tMsg);
		}
		return userName;
	}

	public List displayUserIds() {

		Hashtable hashTable = null;
		List list = new ArrayList();
		String groupDN = "cn=arssvugroup,ou=groups,ou=associates,dc=albertsons,dc=com";
		try {
			if ((hashTable = ldapDir.read(groupDN, new String[] { "uniquemember" })) != null) {
				Object value[] = (Object[]) hashTable.get("uniquemember");
				if (value != null) {
					for (int i = 0; i < value.length; i++) {
						log.debug(value[i].toString());
						list.add(value[i].toString().substring(4, value[i].toString().indexOf(',')));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * This function undoes whatever initialize() does.
	 * 
	 * @return void
	 * @exception java.lang.Exception
	 */
	public void destroy() throws Exception {
		if (ldapDir == null) {
			return;
		}

		try {
			// Disconnect the connection with the server.
			ldapDir.disconnect();
		} catch (Exception e) {
			throw e; // Rethrow the exception.
		} finally {
			ldapDir = null;
		}
	}

}
