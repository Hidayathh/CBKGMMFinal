package com.unfi.cbk.b2aldap;

import java.util.HashMap;

import org.apache.log4j.Logger;



/**
 * The LDAPHandler class handles all operations that require a call to LDAP and
 * the associated manipulation of the LDAP data.
 * 
 * Calls to LDAP are needed to determine vendors associated with a user, the
 * type of user, and valid vendor numbers.
 * 
 * 
 */
public class LDAPHandler {
	static Logger log = Logger.getLogger(LDAPHandler.class);

	private LDAPFunction ldap;
	HashMap<String, String> ldapProMap;
	private UserDetail detail = null;

	/**
	 * Initializes a newly created <code>LDAPHandler</code> object. The constructor
	 * takes a user ID and makes it available to the entire instance.
	 * 
	 * @param userId The LDAP ID of the user.
	 * @since 1.0
	 */
	public LDAPHandler(String userId) {
	}

	/**
	 * Returns an LDAP Connection object specific to this app. This method takes no
	 * arguments but creates a new LDAP connection.
	 * <p>
	 * The caller is expected to handle any exceptions and look for a null object
	 * returned.
	 *
	 * @return the LDAP connection
	 * @see LDAPFuncs
	 * @since 1.0
	 */
	public LDAPFunction getLDAPConnection(String userId, HashMap<String, String> ldapProMap) throws Exception {
		LDAPFunction ldap = null;

		// Exceptions should be handled by the caller
		this.ldap = new LDAPFunction(userId, ldapProMap);
		return this.ldap;
	}

	/**
	 * Releases an LDAP Connection object specific to this app. This method takes a
	 * <code>LDAPFuncs</code> object as the parameter and calls its
	 * <code>destroy<code>.
	 *
	 * &#64;param ldap      the <code>LDAPFuncs</code> connection to be
	 * released
	 * 
	 * @see LDAPFuncs
	 * @since 1.0
	 */
	public void closeLDAPConnection(LDAPFunction ldap) {
		try {
			if (ldap != null) {
				ldap.destroy();
			}
		} catch (Exception e) {
			log.error("Exception in closeLDAPConnection():" + e);
		}
	}

	private void initUserDetail() {
		if (ldap != null) {
			if (this.detail == null) {
				try {
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public String getUserName() {
		initUserDetail();
		return detail.getFullName();
	}



}