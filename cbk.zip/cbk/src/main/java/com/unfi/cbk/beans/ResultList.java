package com.unfi.cbk.beans;

import java.util.List;

/**
 * @author yhp6y2l
 * @version 1.0
 */
public class ResultList {
	private List list;
	private Integer totalCount;

	/**
	 * @return
	 */
	public List getList() {
		return list;
	}

	/**
	 * @return
	 */
	public Integer getTotalCount() {
		return totalCount;
	}

	/**
	 * @param list
	 */
	public void setList(List list) {
		this.list = list;
	}

	/**
	 * @param integer
	 */
	public void setTotalCount(Integer integer) {
		totalCount = integer;
	}

}
