package com.unfi.cbk.beans;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import com.unfi.cbk.util.Constants;

/**
 * The UserDataBean class is used to determine and hold data about the user so
 * that other classes and JSP's can have access to the data.
 *
 * @author yhp6y2l
 * @since 1.0
 */
public class UserDataBean implements Serializable {

	private static final long serialVersionUID = 1L;

	static Logger log = Logger.getLogger(UserDataBean.class);

	private HttpServletRequest request;

	/**
	 * Initializes a newly created <code>UserDataBean</code> object. The constructor
	 * takes an HttpServletRequest object and a MessageResources object.
	 * 
	 * @param request              the <code>HttpServletRequest</code> object for
	 *                             this request
	 * @param environmentResources the <code>MessageResources</code> object specific
	 *                             to this environment.
	 */
	public UserDataBean(HttpServletRequest request) {
		this.request = request;
	}

	/**
	 * Get the userId.
	 * 
	 * @return the user's login ID
	 */
	public String getUserId() {
		return request.getRemoteUser();
	}

	/**
	 * Get the userCommonName.
	 * 
	 * @return the user's common name
	 */
	public String getUserCommonName() {
		return request.getUserPrincipal().getName();
	}

	/**
	 * Get the userRoles.
	 * 
	 * @return the user's roles
	 */
	// public String getUserRoles() {
	// return this.userRoles;
	// }

	

	private boolean hasRole(String role) {
		return request.isUserInRole(role);
	}

	
	public boolean isReadOnly() {
		return hasRole(Constants.READONLY_ROLE);
	}

	public boolean isUpdate() {
		return hasRole(Constants.UPDATE_ROLE);
	}

	public boolean isAdmin() {
		return hasRole(Constants.ADMIN_ROLE);
	}

	
}