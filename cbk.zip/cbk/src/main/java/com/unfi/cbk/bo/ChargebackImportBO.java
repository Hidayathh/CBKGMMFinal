
package com.unfi.cbk.bo;

import java.util.Date;
import java.util.List;

import com.unfi.cbk.util.DateFunctions;

/**
 * The Chargeback class is a means for representing a single result when
 * searching for Chargebacks.
 * <p>
 * Each property represents a column in the display table.
 *
 * @author vpil001
 * @since 1.0
 */
public class ChargebackImportBO {

	/*
	 * CBK
	 */

	public ChargebackImportBO() {

	}

	public ChargebackImportBO(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	private String companyCode;
	private String invoiceNumber;
	private String locationNumber;
	private String locationName;
	private String invoiceDate;
	private String vendorId;
	private String netAmount;
	private String chargebackTotal;
	private String attachmentType;

	private String originator;
	private String approver;
	private String fin;
	private String ca;
	private int documentNumber;
	private Integer typeId;
	private String typeName;
	private Integer memberCount;
	private String documentEncKey;
	private Date checkDate;
	private Date bankClearDate;
	private Date dueDate;
	private String docType;
	private String mimeType;
	private String notFound;
	private String creatorId;

	private String account;
	private List searchResults;

	public List getSearchResults() {
		return searchResults;
	}

	public void setSearchResults(List searchResults) {
		this.searchResults = searchResults;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public Date getApprovalDate() {
		return approvalDate;
	}

	public void setApprovalDate(Date approvalDate) {
		this.approvalDate = approvalDate;
	}

	private byte[] fileData;

	public byte[] getFileData() {
		return fileData;
	}

	public void setFileData(byte[] fileData) {
		this.fileData = fileData;
	}

	public String getAttachmentName() {
		return attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	public String getAttachmentType() {
		return attachmentType;
	}

	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}

	private String attachmentName;

	private Date approvalDate;

	private String dcNumber;
	private String itemNumber;
	private Integer itemPack;
	private String itemSize;
	private String itemDesc;
	private String itemUpc;
	private String itemSlot;
	private String division;
	private String region;
	private String subFund;
	private String subFundNumber;
	private String itemQuantity;
	private Double itemPrice;
	private Double extension;

	private String accountNumber;
	private String distLocNumber;
	private String productGrp;
	private Double distributionAmt;
	private String vendorInvoice;

	private Integer attachment;
	private Integer barCode;
	private String shortDesc;
	private Integer exported;
	private Integer cancelled;
	private Integer inProcess;
	private String nextAproverId;
	private String interInstr;
	private String referenceNumber;

	private String Total;

	private String stepNumber;

	private String originalApprover;

	private byte[] attachmentFile;
	private String filename;

	public byte[] getAttachmentFile() {
		return attachmentFile;
	}

	public void setAttachmentFile(byte[] attachmentFile) {
		this.attachmentFile = attachmentFile;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public Date getAttachmentDate() {
		return attachmentDate;
	}

	public void setAttachmentDate(Date attachmentDate) {
		this.attachmentDate = attachmentDate;
	}

	private Date attachmentDate;

	public String getOriginalApprover() {
		return originalApprover;
	}

	public void setOriginalApprover(String originalApprover) {
		this.originalApprover = originalApprover;
	}

	public String getChargebackTotal() {
		return chargebackTotal;
	}

	public void setChargebackTotal(String chargebackTotal) {
		this.chargebackTotal = chargebackTotal;
	}

	public String getTotal() {
		return Total;
	}

	public void setTotal(String total) {
		Total = total;
	}

	public String getStepNumber() {
		return stepNumber;
	}

	public void setStepNumber(String stepNumber) {
		this.stepNumber = stepNumber;
	}

	public String getRouteId() {
		return routeId;
	}

	public void setRouteId(String routeId) {
		this.routeId = routeId;
	}

	public String getApproverName() {
		return approverName;
	}

	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}

	private String productGrpCode;

	// private String roleId;
	private String role;
	private String routeId;

	private Integer roleId;
	private String roleDesc;
	private String defForm;
	private String approverId;
	private String approverName;
	private Integer lineNumber;
	private String productCode;
	private String reasonAcctNumber;
	private String reasonCode;
	private String prdGrpCode;
	private String vendorName;

	private String subFundsForChargeback;

	public String getSubFundsForChargeback() {
		return subFundsForChargeback;
	}

	public void setSubFundsForChargeback(String subFundsForChargeback) {
		this.subFundsForChargeback = subFundsForChargeback;
	}

	public Double getExtension() {
		return extension;
	}

	public void setExtension(Double extension) {
		this.extension = extension;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorAddr1() {
		return vendorAddr1;
	}

	public void setVendorAddr1(String vendorAddr1) {
		this.vendorAddr1 = vendorAddr1;
	}

	public String getVendorAddr2() {
		return vendorAddr2;
	}

	public void setVendorAddr2(String vendorAddr2) {
		this.vendorAddr2 = vendorAddr2;
	}

	public String getVendorCity() {
		return vendorCity;
	}

	public void setVendorCity(String vendorCity) {
		this.vendorCity = vendorCity;
	}

	public String getVendorState() {
		return vendorState;
	}

	public void setVendorState(String vendorState) {
		this.vendorState = vendorState;
	}

	public String getVendorPostCode() {
		return vendorPostCode;
	}

	public void setVendorPostCode(String vendorPostCode) {
		this.vendorPostCode = vendorPostCode;
	}

	private String vendorAddr1;
	private String vendorAddr2;
	private String vendorCity;
	private String vendorState;
	private String vendorPostCode;

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getSubFund() {
		return subFund;
	}

	public void setSubFund(String subFund) {
		this.subFund = subFund;
	}

	public String getSubFundNumber() {
		return subFundNumber;
	}

	public void setSubFundNumber(String subFundNumber) {
		this.subFundNumber = subFundNumber;
	}

	public String getReasonAcctNumber() {
		return reasonAcctNumber;
	}

	public void setReasonAcctNumber(String reasonAcctNumber) {
		this.reasonAcctNumber = reasonAcctNumber;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public Integer getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(Integer lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/*
	 * public String getRoleId() { return roleId; }
	 * 
	 * public void setRoleId(String roleId) { this.roleId = roleId; }
	 */
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

	public String getDefForm() {
		return defForm;
	}

	public void setDefForm(String defForm) {
		this.defForm = defForm;
	}

	public String getApproverId() {
		return approverId;
	}

	public void setApproverId(String approverId) {
		this.approverId = approverId;
	}

	public Date getCheckDate() {
		return checkDate;
	}

	public void setCheckDate(Date checkDate) {
		this.checkDate = checkDate;
	}

	public String getVendorInvoice() {
		return vendorInvoice;
	}

	public void setVendorInvoice(String vendorInvoice) {
		this.vendorInvoice = vendorInvoice;
	}

	public Integer getAttachment() {
		return attachment;
	}

	public void setAttachment(Integer attachment) {
		this.attachment = attachment;
	}

	public Integer getBarCode() {
		return barCode;
	}

	public void setBarCode(Integer barCode) {
		this.barCode = barCode;
	}

	public String getShortDesc() {
		return shortDesc;
	}

	public void setShortDesc(String shortDesc) {
		this.shortDesc = shortDesc;
	}

	public Integer getExported() {
		return exported;
	}

	public void setExported(Integer exported) {
		this.exported = exported;
	}

	public Integer getCancelled() {
		return cancelled;
	}

	public void setCancelled(Integer cancelled) {
		this.cancelled = cancelled;
	}

	public Integer getInProcess() {
		return inProcess;
	}

	public void setInProcess(Integer inProcess) {
		this.inProcess = inProcess;
	}

	public String getNextAproverId() {
		return nextAproverId;
	}

	public void setNextAproverId(String nextAproverId) {
		this.nextAproverId = nextAproverId;
	}

	public String getInterInstr() {
		return interInstr;
	}

	public void setInterInstr(String interInstr) {
		this.interInstr = interInstr;
	}

	public String getProductGrpCode() {
		return productGrpCode;
	}

	public void setProductGrpCode(String productGrpCode) {
		this.productGrpCode = productGrpCode;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getDistLocNumber() {
		return distLocNumber;
	}

	public void setDistLocNumber(String distLocNumber) {
		this.distLocNumber = distLocNumber;
	}

	public String getProductGrp() {
		return productGrp;
	}

	public void setProductGrp(String productGrp) {
		this.productGrp = productGrp;
	}

	public Double getDistributionAmt() {
		return distributionAmt;
	}

	public void setDistributionAmt(Double distributionAmt) {
		this.distributionAmt = distributionAmt;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getDcNumber() {
		return dcNumber;
	}

	public void setDcNumber(String dcNumber) {
		this.dcNumber = dcNumber;
	}

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public Integer getItemPack() {
		return itemPack;
	}

	public void setItemPack(Integer itemPack) {
		this.itemPack = itemPack;
	}

	public String getItemSize() {
		return itemSize;
	}

	public void setItemSize(String itemSize) {
		this.itemSize = itemSize;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public String getItemUpc() {
		return itemUpc;
	}

	public void setItemUpc(String itemUpc) {
		this.itemUpc = itemUpc;
	}

	public String getItemSlot() {
		return itemSlot;
	}

	public void setItemSlot(String itemSlot) {
		this.itemSlot = itemSlot;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(String itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

	public Double getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(Double itemPrice) {
		this.itemPrice = itemPrice;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getPrdGrpCode() {
		return prdGrpCode;
	}

	public void setPrdGrpCode(String prdGrpCode) {
		this.prdGrpCode = prdGrpCode;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public Integer getMemberCount() {
		return memberCount;
	}

	public void setMemberCount(Integer memberCount) {
		this.memberCount = memberCount;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getLocationNumber() {
		return locationNumber;
	}

	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public int getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(int documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	/*
	 * public String getVendor() { return vendor; }
	 * 
	 * public void setVendor(String vendor) { this.vendor = vendor; }
	 */

	public String getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}

	public String getOriginator() {
		return originator;
	}

	public void setOriginator(String originator) {
		this.originator = originator;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public String getFin() {
		return fin;
	}

	public void setFin(String fin) {
		this.fin = fin;
	}

	public String getCa() {
		return ca;
	}

	public void setCa(String ca) {
		this.ca = ca;
	}

	public String getNotFound() {
		return notFound;
	}

	public void setNotFound(String notFound) {
		this.notFound = notFound;
	}

	public String getInvoiceDateString() {
		String s = null;
		if (invoiceDate != null) {
			s = DateFunctions.formatDate(invoiceDate);
		}
		return s;
	}

	/*
	 * public void setInvoiceDateString(String s) { if (s != null &&
	 * s.trim().length() > 0) { invoiceDate = DateFunctions.stringToDate(s); } }
	 */

	/**
	 * Get documentEncKey
	 * 
	 * @return String
	 */
	public String getDocumentEncKey() {
		return documentEncKey;
	}

	/**
	 * Set documentEncKey
	 * 
	 * @param string <code>String</code> to set
	 */
	public void setDocumentEncKey(String string) {
		documentEncKey = string;
	}

	public String getCheckDateString() {
		String s = null;
		if (checkDate != null) {
			s = DateFunctions.formatDate(checkDate);
		}
		return s;
	}

	public void setCheckDateString(String s) {
		if (s != null && s.trim().length() > 0) {
			checkDate = DateFunctions.stringToDate(s);
		}
	}

	/**
	 * @return
	 */
	public Date getBankClearDate() {
		return bankClearDate;
	}

	/**
	 * @param date
	 */
	public void setBankClearDate(Date date) {
		bankClearDate = date;
	}

	public String getBankClearDateString() {
		String s = null;
		if (bankClearDate != null) {
			s = DateFunctions.formatDate(bankClearDate);
		}
		return s;
	}

	/**
	 * @return
	 */
	public String getMimeType() {
		return mimeType;
	}

	/**
	 * @param string
	 */
	public void setMimeType(String string) {
		mimeType = string;
	}

	/**
	 * @return
	 */
	public Date getDueDate() {
		return dueDate;
	}

	/**
	 * @param date
	 */
	public void setDueDate(Date date) {
		dueDate = date;
	}

	public String getDueDateString() {
		String s = null;
		if (dueDate != null) {
			s = DateFunctions.formatDate(dueDate);
		}
		return s;
	}

}