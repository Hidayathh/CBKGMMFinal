package com.unfi.cbk.bo;

/**
 * The Chargeback class is a means for representing a single result when
 * searching for Chargebacks.
 * <p>
 * Each property represents a column in the display table.
 *
 * @author vpil001
 * @since 1.0
 */
public class ChargebackInterfaceBO {

	private String file;

	private String recordType;
	private String proclevel;
	private String dueDate;
	// private Date dueDate;
	private String vendorNumber;
	private String creatorId;
	private String cbkType;
	private String cbkReason;
	private String description;
	private String reference;
	private String invoiceNumber;

	private String itemLine;
	private String itemPack;
	private String itemCode;
	private String prodGroup;
	private String quantity;
	private String itemPrice;
	private String dcNumber;
	private Integer itemNumber;
	private String itemSize;
	private String itemDesc;
	private String itemUpc;
	private String itemSlot;
	private String division;
	private String region;
	private String subFund;
	private String interInstr;
	private String inProcess;
	private String exported;
	private String cancelled;
	private String barCode;
	private String vendorInvoice;
	private String invoiceDate;
	private String attachmentType;

	private String companyCode;
	private String locationNumber;
	private String stateProdCode;
	private String accNumber;
	private String amount;
	private Double distributionAmt;

	private String stepNumber;
	private String approverId;

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getProclevel() {
		return proclevel;
	}

	public void setProclevel(String proclevel) {
		this.proclevel = proclevel;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public String getCbkType() {
		return cbkType;
	}

	public void setCbkType(String cbkType) {
		this.cbkType = cbkType;
	}

	public String getCbkReason() {
		return cbkReason;
	}

	public void setCbkReason(String cbkReason) {
		this.cbkReason = cbkReason;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getItemLine() {
		return itemLine;
	}

	public void setItemLine(String itemLine) {
		this.itemLine = itemLine;
	}

	public String getItemPack() {
		return itemPack;
	}

	public void setItemPack(String itemPack) {
		this.itemPack = itemPack;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getProdGroup() {
		return prodGroup;
	}

	public void setProdGroup(String prodGroup) {
		this.prodGroup = prodGroup;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(String itemPrice) {
		this.itemPrice = itemPrice;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getLocationNumber() {
		return locationNumber;
	}

	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}

	public String getStateProdCode() {
		return stateProdCode;
	}

	public void setStateProdCode(String stateProdCode) {
		this.stateProdCode = stateProdCode;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getVendorNumber() {
		return vendorNumber;
	}

	public void setVendorNumber(String vendorNumber) {
		this.vendorNumber = vendorNumber;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}

	public String getStepNumber() {
		return stepNumber;
	}

	public void setStepNumber(String stepNumber) {
		this.stepNumber = stepNumber;
	}

	public String getApproverId() {
		return approverId;
	}

	public void setApproverId(String approverId) {
		this.approverId = approverId;
	}

	public String getDcNumber() {
		return dcNumber;
	}

	public void setDcNumber(String dcNumber) {
		this.dcNumber = dcNumber;
	}

	public Integer getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Integer itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getItemSize() {
		return itemSize;
	}

	public void setItemSize(String itemSize) {
		this.itemSize = itemSize;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public String getItemUpc() {
		return itemUpc;
	}

	public void setItemUpc(String itemUpc) {
		this.itemUpc = itemUpc;
	}

	public String getItemSlot() {
		return itemSlot;
	}

	public void setItemSlot(String itemSlot) {
		this.itemSlot = itemSlot;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getSubFund() {
		return subFund;
	}

	public void setSubFund(String subFund) {
		this.subFund = subFund;
	}

	public String getInterInstr() {
		return interInstr;
	}

	public void setInterInstr(String interInstr) {
		this.interInstr = interInstr;
	}

	public String getInProcess() {
		return inProcess;
	}

	public void setInProcess(String inProcess) {
		this.inProcess = inProcess;
	}

	public String getExported() {
		return exported;
	}

	public void setExported(String exported) {
		this.exported = exported;
	}

	public String getCancelled() {
		return cancelled;
	}

	public void setCancelled(String cancelled) {
		this.cancelled = cancelled;
	}

	public String getBarCode() {
		return barCode;
	}

	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}

	public String getVendorInvoice() {
		return vendorInvoice;
	}

	public void setVendorInvoice(String vendorInvoice) {
		this.vendorInvoice = vendorInvoice;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getAttachmentType() {
		return attachmentType;
	}

	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}

	public Double getDistributionAmt() {
		return distributionAmt;
	}

	public void setDistributionAmt(Double distributionAmt) {
		this.distributionAmt = distributionAmt;
	}

}
