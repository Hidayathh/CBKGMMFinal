/*
 * Created on Mar 20, 2006
 * @author yhp6y2l
 */
package com.unfi.cbk.common.util.ui;

import java.util.List;

/**
 * 
 * @author yhp6y2l
 *
 */
public interface ListSource {
	public List getList();
}
