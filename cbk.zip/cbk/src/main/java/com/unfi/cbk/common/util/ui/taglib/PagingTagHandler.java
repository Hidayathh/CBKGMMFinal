package com.unfi.cbk.common.util.ui.taglib;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;

import com.unfi.cbk.common.util.ui.Pageable;

/**
 * 
 * @author yhp6y2l
 *
 */
public class PagingTagHandler extends TagSupport {

	static Logger log = Logger.getLogger(PagingTagHandler.class);
	private int start = 1;
	private int total;
	private int offset = 10;
	private boolean showAll = false;
	private String name = null;
	private String action = null;
	private int showAllMax = 0;
	private static final String openLink = "<a href=\"javascript:void();\" onClick=\"javascript:";
	private static final String closeLink = "</a>";

	/**
	 * 
	 */
	public PagingTagHandler() {
		super();
	}

	/**
	 * @param name The name to set.
	 */
	public void setName(String name) {
		this.name = name;
	}

	public int doStartTag() throws JspException {
		try {
			Object obj = pageContext.getAttribute(name);
			if (obj == null) {
				obj = pageContext.getRequest().getAttribute(name);
			}
			if (obj == null) {
				obj = pageContext.getServletContext().getAttribute(name);
			}
			if (obj != null) {
				if (obj instanceof Pageable) {
					Pageable pageable = (Pageable) obj;
					showAll = pageable.isShowAll();
					total = pageable.getTotalRecords();
					if (showAll) {
						start = 1;
						offset = total;
					} else {
						start = pageable.getCurrentRecord();
						offset = pageable.getDisplayCount();
					}

				} else {
					throw new ClassCastException(name + " cannot be cast to Pageable");
				}
			}
		} catch (Exception e) {
			log.error("Exception in doStartTag() " + e);
			// e.printStackTrace();
		}

		try {
			JspWriter out = pageContext.getOut();
			out.print(display());
		} catch (Exception e) {
			log.error("Exception in doStartTag() " + e);
			// e.printStackTrace();
		}

		start = 1;
		total = 0;
		offset = 10;
		name = null;
		action = null;

		return SKIP_BODY;
	}

	public void release() {
		super.release();
	}

	/**
	 * @param string
	 */
	public void setAction(String string) {
		action = string;
	}

	public String display() {
		// convenience variables
		boolean showNext = true;
		boolean showPrev = true;

		String closeScript = "\';document." + name + ".action=\'" + action + "\';document." + name
				+ ".submit();return false;\">";
		// String openScript = openLink + "document." + name +
		// ".currentRecord.value=\'";
		String openScript = openLink + "document.getElementsByName('currentRecord')[0].value=\'";
		// String displayControlValue = "document." + name + ".displayCount.value=\'";
		String displayControlValue = "document.getElementsByName('displayCount')[0].value=\'";
		int last = 1;
		if (offset != 0) {
			last = (total / offset) * offset + 1;
			if (last > total) {
				last = last - offset;
			}
		}

		int back = start - offset;
		if (back <= 1) {
			back = 1;
		}

		int forward = start + offset;
		if (forward >= total) {
			forward = last;
		}

		int curLast = start + offset - 1;
		if (curLast > total) {
			curLast = total;
		}

		StringBuffer buf = new StringBuffer();
		// buf.append("<input type=\"hidden\" name=\"currentRecord\" value=\"");
		// buf.append(start);
		// buf.append("\" />\n");

		// make sure that the offset will not walk off the end of the results bean
		// and set the next button display to false
		if (start + offset > total) {
			showNext = false;
		}

		// set the previous button display to false
		if (start == 1) {
			showPrev = false;
		}

		// If there are no results, make sure the start value is 0, not 1.
		if (total == 0) {
			start = 0;
		}

		buf.append("<div style=\"font-size: 1.0em; margin: 5px 0 0 0; padding-bottom: 2px; padding-top: 2px");
		if (total == 0) {
			buf.append("visibility=\'hidden\';");
		}
		buf.append("\">");

		// if we are at the first set of records disable the go to start button
		if (showPrev) {
			buf.append(openScript);
			buf.append("1");
			buf.append(closeScript);
			buf.append(
					"<img src=\"images/vcr_first.gif\" alt=\"first page\" width=\"30\" height=\"32\" border=\"0\" />");
			buf.append(closeLink);
		} else {
			buf.append(
					"<img src=\"images/vcr_gray_first.gif\" alt=\"first page\" width=\"30\" height=\"32\" border=\"0\" />");
		}
		// if we are at the first set of records disable the go back button
		if (showPrev) {
			buf.append(openScript);
			buf.append(back);
			buf.append(closeScript);
			buf.append(
					"<img src=\"images/vcr_prev.gif\" alt=\"previous page\" width=\"30\" height=\"32\" border=\"0\" />");
			buf.append(closeLink);
		} else {
			buf.append(
					"<img src=\"images/vcr_gray_prev.gif\" alt=\"previous page\" width=\"30\" height=\"32\" border=\"0\" />");
		}
		// if we are at the end disable to forward button
		if (showNext) {
			buf.append(openScript);
			buf.append(forward);
			buf.append(closeScript);
			buf.append("<img src=\"images/vcr_next.gif\" width=\"30\" height=\"32\" alt=\"next page\" border=\"0\" />");
			buf.append(closeLink);
		} else {
			buf.append(
					"<img src=\"images/vcr_gray_next.gif\" width=\"30\" height=\"32\" alt=\"next page\" border=\"0\" />");
		}
		if (showNext) {
			buf.append(openScript);
			buf.append(last);
			buf.append(closeScript);
			buf.append("<img src=\"images/vcr_last.gif\" width=\"30\" height=\"32\" alt=\"last page\" border=\"0\" />");
			buf.append(closeLink);
		} else {
			buf.append(
					"<img src=\"images/vcr_gray_last.gif\" width=\"30\" height=\"32\" alt=\"last page\" border=\"0\" />");
		}
		buf.append("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
		buf.append("Displaying <strong>" + start + " to " + curLast + "</strong> of " + total);

		if (canShowAll() && (showPrev || showNext || showAll)) {
			buf.append(" &nbsp; &nbsp; &nbsp;");
			buf.append(
					"<input type=\"checkbox\" name=\"showAll\" value=\"true\" onclick=\"vcrShowAll(this.checked);\" ");
			if (showAll) {
				buf.append("checked=\"checked\" ");
			}
			buf.append("\\>Show All");

		}
		/*
		 * buf.append("<select name=\"displayCount\" onChange=\"javascript:document." +
		 * name + ".currentRecord.value=\'1\';document." + name + ".action='" + action +
		 * "\';document." + name + ".submit();return false;\">"); buf.append("<option" +
		 * (offset == 5?" selected=selected":"")+ ">5</option>"); buf.append("<option" +
		 * (offset == 10?" selected=selected":"")+ ">10</option>"); buf.append("<option"
		 * + (offset == 25?" selected=selected":"") + ">25</option>");
		 * buf.append("<option" + (offset == 50?" selected=selected":"") +
		 * ">50</option>"); buf.append("<option" + (offset ==
		 * 75?" selected=selected":"") + ">75</option>"); buf.append("<option" + (offset
		 * == 100?" selected=selected":"") + ">100</option>"); buf.append("</select>");
		 */
		buf.append("</div> ");

		return buf.toString();
	}

	/**
	 * @param i
	 */
	public void setShowAllMax(String s) {
		showAllMax = Integer.parseInt(s);
	}

	public boolean canShowAll() {
		if (showAllMax == 0 || total <= showAllMax) {
			return true;
		}
		return false;

	}

}
