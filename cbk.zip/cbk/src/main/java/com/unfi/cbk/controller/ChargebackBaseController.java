package com.unfi.cbk.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author yhp6y2l
 * @since 3.0
 */
public class ChargebackBaseController {// extends DispatchAction {
	static Logger log = Logger.getLogger(ChargebackBaseController.class);

	/**
	 * This is a fix for the bug in the DispatchAction execute method. If execute is
	 * called with the method name execute recursion occures. This over ride sniffs
	 * that out and throws an IllegalArgumentException is excute is passed.
	 */
	public ModelAndView execute(ModelAndView in_mapping, Object in_form, HttpServletRequest in_request) throws Exception {
		// String parameterName = in_mapping.getParameter();
		// if (parameterName != null) {
		String methodName = in_request.getParameter("action");
		if (methodName != null && ("execute".equals(methodName) || "perform".equals(methodName))) {
			throw new IllegalArgumentException("illegal parameter");
		}
		// }
		if (in_form == null) {
			log.error("Null form found.");
		}
		return in_mapping;
	}

}
