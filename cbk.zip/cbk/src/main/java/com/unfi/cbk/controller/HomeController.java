package com.unfi.cbk.controller;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

/**
 * 
 * @author yhp6y2l
 *
 */
@Controller
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class HomeController {
	static Logger log = Logger.getLogger(HomeController.class);

	@RequestMapping(value = "/home", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView execute() throws Exception {
		System.out.println("---HomeController.java-----");
		ModelAndView mav = new ModelAndView();

		mav.setViewName("homePageDef");
		
		//mav.setViewName("home");

		log.debug("***** HOME *****");

		// return mapping.findForward("home");
		return mav;
	}
	

}