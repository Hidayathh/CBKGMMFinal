package com.unfi.cbk.controller.chargeback;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.AdminResultsBO;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.CreateNewUserBO;
import com.unfi.cbk.controller.PageAccessResolver;
import com.unfi.cbk.delegates.AdminDelegate;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.delegates.UserSearchResultDeligate;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.forms.ChargebackAdminForm;
//import com.unfi.cbk.dao.ibImpl.MaintenanceDaoImpl;
import com.unfi.cbk.forms.ChargebackSearchForm;
import com.unfi.cbk.forms.CreateNewUserForm;
import com.unfi.cbk.forms.UserSearchForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.DateFunctions;

/**
 * The ChargebackAdminAction class is the struts action called for the search
 * criteria entry page. The action sets the user data in the request, sets any
 * values needed for the form, and forwards to the JSP specific to the userType.
 *
 * @author vpil001
 * @since 1.0
 */
@Controller("chargebackAdminAction_chargeback")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class AdminController {// extends Action {
	static Logger log = Logger.getLogger(AdminController.class);
	@Autowired
	ActionMessages errors;
	@Autowired
	ActionMessages messages;

	@Autowired
	private ChargebackSearchDelegate chargebackSearchDelegate;

	@Autowired
	private AdminDelegate adminDelegate;

	@Autowired
	private UserSearchResultDeligate userSearchResultDeligate;

	public AdminController(UserSearchResultDeligate userSearchResultDeligate) {
		this.userSearchResultDeligate = userSearchResultDeligate;
	}

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	@RequestMapping(value = "/chargebackAdmin", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=admin" })
	public ModelAndView admin(@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackSearchForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackSearchForm.reset();
		}

		log.debug("***** CHARGEBACK ADMIN *****admin*****");

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		// Finish with
		mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("open"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackSearchForm", chargebackSearchForm);

		return mav;

	}

	@RequestMapping(value = "/userSearchResults", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView execute(@ModelAttribute("userSearchForm") UserSearchForm userSearchForm,
			HttpServletRequest request) throws Exception {

		ModelAndView mav = new ModelAndView();

		if (request.getParameter("isformreset") != null) {
			userSearchForm.reset(request);
		}

		log.debug("***** CHARGEBACK ADMIN *****userSearchResults***");
		Map searchParametersFrom = userSearchForm.getMap();
		// Define the display parameters
		int maxRows = 20;
		userSearchForm.setDisplayCount(maxRows);

		if (userSearchForm.isShowAll()) {
			searchParametersFrom.put("showAll", "true");
		} else {
			searchParametersFrom.put("rowStart", new Integer(userSearchForm.getCurrentRecord()));
			searchParametersFrom.put("rowEnd", new Integer(userSearchForm.getCurrentRecord() + maxRows - 1));
		}
		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}
		String location = null;

		if (userSearchForm.getLocation() != null) {
			location = userSearchForm.getLocation();
		}
		if (request.getParameter("location") != null) {
			location = request.getParameter("location");
		}
		// Location
		if (userSearchForm.getLocation() != null && userSearchForm.getLocationNumber() != "") {
			if (("2").equals(userSearchForm.getLocation()) && userSearchForm.getLocationNumber() != "") {
				searchParametersFrom.put("location", userSearchForm.getLocation());
				searchParametersFrom.put("locationNumber", userSearchForm.getLocationNumber().substring(0, 2));
			}
		}

		// Roles
		if (userSearchForm.getRoles() != null) {
			if (userSearchForm.getRoles() != null && userSearchForm.getRoles().equals("1")) {
				userSearchForm.setRoleSelected("");
			}
			searchParametersFrom.put("roleSelected", userSearchForm.getRoleSelected());
		}

		// userId - Originator
		if (userSearchForm.getOriginator() != null && !userSearchForm.getOriginator().isEmpty()) {
			searchParametersFrom.put("userId", userSearchForm.getOriginator());
		}

		// Status
		searchParametersFrom.put("status", userSearchForm.getStatus());
		if (userSearchForm.getStatus() != null) {
			if (userSearchForm.getStatus() != null && userSearchForm.getStatus().equals("1")) {
				userSearchForm.setStatusSelected("");
			}
			searchParametersFrom.put("statusSelected", userSearchForm.getStatusSelected());
		}

		ResultList searchResults = null;
		if ((("".equals(userSearchForm.getLocationNumber()) || userSearchForm.getLocationNumber() == null)
				&& ("".equals(userSearchForm.getRoleSelected()) || userSearchForm.getRoleSelected() == null))
				&& ("".equals(userSearchForm.getOriginator()) || userSearchForm.getOriginator() == null)) {
			searchResults = userSearchResultDeligate.allUsers(searchParametersFrom);
		} else if (((userSearchForm.getLocationNumber().isEmpty() || userSearchForm.getLocationNumber() == null)
				&& (userSearchForm.getRoleSelected().isEmpty() || userSearchForm.getRoleSelected() == null))
				&& userSearchForm.getOriginator() != null) {
			searchResults = userSearchResultDeligate.specificUserSearch(searchParametersFrom);
		} else if (((userSearchForm.getLocationNumber().isEmpty() || userSearchForm.getLocationNumber() == null)
				&& (userSearchForm.getOriginator() == null || userSearchForm.getOriginator().isEmpty()))
				&& userSearchForm.getRoleSelected() != null) {
			searchResults = userSearchResultDeligate.specificRoleIdSearch(searchParametersFrom);
		} else {
			searchResults = userSearchResultDeligate.specificUserResults(searchParametersFrom);
		}

		userSearchForm.setSearchResults(searchResults.getList());
		userSearchForm.setTotalRecords(searchResults.getTotalCount().intValue());

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("users"));
			request.setAttribute("userSearchForm", userSearchForm);
		}

		request.setAttribute("actionMessages", errors);//

		return mav;
	}

	@RequestMapping(value = "/userMaintenance", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=userMaint" })
	public ModelAndView userMaint(@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackSearchForm.setFormParameterMap(request);
		log.debug("***** CHARGEBACK ADMIN *****userMaint*****");
		if (request.getParameter("isformreset") != null) {
			chargebackSearchForm.reset();
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("userSearch"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackSearchForm", chargebackSearchForm);

		request.setAttribute("Roles", chargebackSearchDelegate.getAllRoles());
		return mav;

	}

	@RequestMapping(value = "/chargebackAdmin", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=create" })
	public ModelAndView create(@ModelAttribute("createNewUserForm") CreateNewUserForm createNewUserForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK ADMIN *****create*****");
		createNewUserForm.setFormParameterMap(request);
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		// Get the locations list
		List<ChargebackBO> locations = chargebackSearchDelegate.getLocationsForCreateUser();
		createNewUserForm.setLocations(locations);

		// Get the roles list
		List roles = chargebackSearchDelegate.getRoles();
		createNewUserForm.setRoles(roles);
		// Get the Menus

		List rolesByUserForMenuList = adminDelegate.getRolesByUserForMenu();
		createNewUserForm.setRolesByUserForMenuList(rolesByUserForMenuList);

		if (request.getParameter("selectedUserId") != null && request.getParameter("selectedUserId") != "") {

			String userId = (String) request.getParameter("selectedUserId");
			System.out.println("**********************userId Selected for Clone --" + userId);
			// CreateNewUserBO UserBODetails =
			// chargebackSearchDelegate.getUserDetails(userId);
			// createNewUserForm.populateFormFromObject(UserBODetails);
			ResultList searchResults = chargebackSearchDelegate.getUserRolesLocations(userId);
			/*
			 * List l = (List) searchResults.getList();// DELETE IT CreateNewUserBO cbkbo =
			 * new CreateNewUserBO(); for (int i = 0; i < l.size(); i++) { cbkbo =
			 * (CreateNewUserBO) l.get(i); }
			 */
			Map map = new HashMap();
			map = SeperateRolesFromMenuAccess((List) searchResults.getList());

			List LocationRolesList = (List) map.get("LocRole");
			createNewUserForm.setLocationRoles(LocationRolesList);

			List MenuAccessList = (List) map.get("MenuAccess");
			createNewUserForm.setMenuAccess(MenuAccessList);

		}

		// Finish with
		// return (forward);
		mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("create"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("createNewUserForm", createNewUserForm);

		return mav;

	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/chargebackAdmin", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=edit" })
	public ModelAndView edit(@ModelAttribute("createNewUserForm") CreateNewUserForm createNewUserForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		HttpSession session = request.getSession();
		createNewUserForm.setFormParameterMap(request);
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		Map createParametersFromForm = createNewUserForm.getMap();
		log.debug("***** CHARGEBACK ADMIN *****edit*****");
		// Map searchRolesFromForm = createNewUserForm.getMap();
		List locations = chargebackSearchDelegate.getLocationsForCreateUser();
		createNewUserForm.setLocations(locations);

		List roles = chargebackSearchDelegate.getRoles();
		createNewUserForm.setRoles(roles);

		String userId = (String) request.getParameter("selectedUserId");

		CreateNewUserBO UserBODetails = chargebackSearchDelegate.getUserDetails(userId);
		createNewUserForm.populateFormFromObject(UserBODetails);
		ResultList searchResults = chargebackSearchDelegate.getUserRolesLocations(userId);
		/*
		 * List l = (List) searchResults.getList();// DELETE IT CreateNewUserBO cbkbo =
		 * new CreateNewUserBO(); for (int i = 0; i < l.size(); i++) { cbkbo =
		 * (CreateNewUserBO) l.get(i); }
		 */
		Map map = new HashMap();
		map = SeperateRolesFromMenuAccess((List) searchResults.getList());

		List LocationRolesList = (List) map.get("LocRole");
		createNewUserForm.setLocationRoles(LocationRolesList);

		List MenuAccessList = (List) map.get("MenuAccess");
		createNewUserForm.setMenuAccess(MenuAccessList);

		List rolesByUserForMenuList = adminDelegate.getRolesByUserForMenu();
		createNewUserForm.setRolesByUserForMenuList(rolesByUserForMenuList);

		mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("edit"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("createNewUserForm", createNewUserForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackAdmin", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=createNewUser" })
	public ModelAndView createNewUser(@ModelAttribute("createNewUserForm") CreateNewUserForm createNewUserForm,
			UserSearchForm userSearchForm, HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		createNewUserForm.setFormParameterMap(request);
		List locRolesList = new ArrayList();
		log.debug("***** CHARGEBACK ADMIN *****createNewUser*****");
		Map searchParametersFromForm = createNewUserForm.getMap();
		searchParametersFromForm.put("userId", createNewUserForm.getUserId());
		searchParametersFromForm.put("userName", createNewUserForm.getUserName());
		searchParametersFromForm.put("useremailId", createNewUserForm.getUseremailId());
		if (createNewUserForm.getStatus() != null && createNewUserForm.getStatus().equals("A"))
			searchParametersFromForm.put("status", createNewUserForm.getStatus());
		else
			searchParametersFromForm.put("status", "I");

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		locRolesList = createNewUserForm.getLocationRolesList(); // locationRoles
		chargebackSearchDelegate.InsertUser(getAddUserList(locRolesList, createNewUserForm), searchParametersFromForm);
		chargebackSearchDelegate
				.insertMenuAccessforUser(insert(createNewUserForm.getUserId(), createNewUserForm.getMenuAccess()));
		Map searchParametersFrom = userSearchForm.getMap();
		int maxRows = 20;
		userSearchForm.setDisplayCount(maxRows);

		if (userSearchForm.isShowAll()) {
			searchParametersFrom.put("showAll", "true");
		} else {
			searchParametersFrom.put("rowStart", new Integer(userSearchForm.getCurrentRecord()));
			searchParametersFrom.put("rowEnd", new Integer(userSearchForm.getCurrentRecord() + maxRows - 1));
		}

		ResultList searchResults = userSearchResultDeligate.allUsers(searchParametersFrom);
		userSearchForm.setSearchResults(searchResults.getList());
		userSearchForm.setTotalRecords(searchResults.getTotalCount().intValue());

		mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("users"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("userSearchForm", userSearchForm);

		return mav;

	}

	@RequestMapping(value = "/chargebackAdmin", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=saveEditUser" })
	public ModelAndView saveEditUser(@ModelAttribute("createNewUserForm") CreateNewUserForm createNewUserForm,
			UserSearchForm userSearchForm, HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		createNewUserForm.setFormParameterMap(request);
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		log.debug("***** CHARGEBACK ADMIN *****saveEditUser*****");
		Map searchParametersFromForm = createNewUserForm.getMap();
		searchParametersFromForm.put("userId", createNewUserForm.getUserId());
		searchParametersFromForm.put("userName", createNewUserForm.getUserName());
		searchParametersFromForm.put("useremailId", createNewUserForm.getUseremailId());
		if (createNewUserForm.getStatus() == null)
			searchParametersFromForm.put("status", "I");
		else
			searchParametersFromForm.put("status", "A");

		List locRolesList = createNewUserForm.getLocationRolesList(); // locationRoles
		chargebackSearchDelegate.updateUser(getAddUserList(locRolesList, createNewUserForm), searchParametersFromForm);
		if (createNewUserForm.getMenuAccess() != null && createNewUserForm.getMenuAccess().size() > 0) {
			chargebackSearchDelegate
					.insertMenuAccessforUser(insert(createNewUserForm.getUserId(), createNewUserForm.getMenuAccess()));
		}

		Map searchParametersFrom = userSearchForm.getMap();
		int maxRows = 20;
		userSearchForm.setDisplayCount(maxRows);

		if (userSearchForm.isShowAll()) {
			searchParametersFrom.put("showAll", "true");
		} else {
			searchParametersFrom.put("rowStart", new Integer(userSearchForm.getCurrentRecord()));
			searchParametersFrom.put("rowEnd", new Integer(userSearchForm.getCurrentRecord() + maxRows - 1));
		}

		ResultList searchResults = userSearchResultDeligate.allUsers(searchParametersFrom);
		userSearchForm.setSearchResults(searchResults.getList());
		userSearchForm.setTotalRecords(searchResults.getTotalCount().intValue());

		mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("users"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("userSearchForm", userSearchForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackAdmin", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=deleteUser" })
	public ModelAndView deleteUser(@ModelAttribute("createNewUserForm") CreateNewUserForm createNewUserForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		createNewUserForm.setFormParameterMap(request);
		Map searchParametersFromForm = createNewUserForm.getMap();
		log.debug("***** CHARGEBACK ADMIN *****deleteUser*****");
		String userId = (String) request.getParameter("userId");

		String deleteStatus = chargebackSearchDelegate.deleteApproverReference(userId);
		if (deleteStatus == null) {
			chargebackSearchDelegate.deleteUserDetails(userId);
		} else {
			createNewUserForm.setErrorMessage("User cannot be deleted.");
			mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("deleteUser"));
			request.setAttribute("actionMessages", errors);
			request.setAttribute("createNewUserForm", searchParametersFromForm);
			return mav;
		}

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("users"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("createNewUserForm", searchParametersFromForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackAdmin", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=adminUserSearchMaint" })
	public ModelAndView adminUserSearchMaint(
			@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackSearchForm.setFormParameterMap(request);
		log.debug("***** CHARGEBACK ADMIN *****adminUserSearchMaint*****");
		if (request.getParameter("isformreset") != null) {
			chargebackSearchForm.reset();
		}

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("adminUserSearch"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackSearchForm", chargebackSearchForm);

		request.setAttribute("Roles", chargebackSearchDelegate.getAllRoles());
		return mav;

	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/adminUserSearch", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView adminUserSearch(@ModelAttribute("chargebackAdminForm") ChargebackAdminForm chargebackAdminForm,
			HttpServletRequest request) throws Exception {

		ModelAndView mav = new ModelAndView();
		boolean exclude = false;
		if (request.getParameter("isformreset") != null) {
			chargebackAdminForm.reset(request);
		}

		log.debug("***** CHARGEBACK ADMIN *****adminUserSearch***");
		Map searchParametersFrom = chargebackAdminForm.getMap();
		// Define the display parameters
		int maxRows = 20;
		chargebackAdminForm.setDisplayCount(maxRows);

		if (chargebackAdminForm.isShowAll()) {
			searchParametersFrom.put("showAll", "true");
		} else {
			searchParametersFrom.put("rowStart", new Integer(chargebackAdminForm.getCurrentRecord()));
			searchParametersFrom.put("rowEnd", new Integer(chargebackAdminForm.getCurrentRecord() + maxRows - 1));
		}
		// If a message is required, save the specified key(s) into the request.
		/*if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}*/
		String location = null;
		String roleSelText = null;
		if (chargebackAdminForm.getLocation() != null) {
			location = chargebackAdminForm.getLocation();
		}
		if (request.getParameter("location") != null) {
			location = request.getParameter("location");
		}
		if (request.getParameter("roleSelText") != null) {
			roleSelText = request.getParameter("roleSelText");
		}
		System.out.println("---roleSelText-----"+roleSelText);
		System.out.println("----chargebackAdminForm.getLocationNumber()----"+chargebackAdminForm.getLocationNumber());
		
		// Location
		if (chargebackAdminForm.getLocation() != null && chargebackAdminForm.getLocationNumber() != "") {
			if (("2").equals(chargebackAdminForm.getLocation()) && chargebackAdminForm.getLocationNumber() != "") {
				searchParametersFrom.put("location", chargebackAdminForm.getLocation());
				searchParametersFrom.put("locationNum", chargebackAdminForm.getLocationNumber().substring(0, 2));
				//searchParametersFrom.put("locNum", chargebackAdminForm.getLocationNumber());
				searchParametersFrom.put("locationNumber", chargebackAdminForm.getLocationNumber());
			}
		}
		
		/*// Roles
				if (userSearchForm.getRoles() != null) {
					if (userSearchForm.getRoles() != null && userSearchForm.getRoles().equals("1")) {
						userSearchForm.setRoleSelected("");
					}
					searchParametersFrom.put("roleSelected", userSearchForm.getRoleSelected());
				}
				*/
		// Roles
		/*if (chargebackAdminForm.getRoles() != null && chargebackAdminForm.getRoleSelected() != "") {
			if (("2").equals(chargebackAdminForm.getRoles()) && chargebackAdminForm.getRoleSelected() != "") {
				searchParametersFrom.put("roleSelected", chargebackAdminForm.getRoleSelected());
				searchParametersFrom.put("roleSel", roleSel);
			}
		}*/
		
		if (chargebackAdminForm.getRoles() != null) {
			if (chargebackAdminForm.getRoles() != null && chargebackAdminForm.getRoles().equals("1")) {
				chargebackAdminForm.setRoleSelected("");
			}
			searchParametersFrom.put("roleSelected", chargebackAdminForm.getRoleSelected());
			searchParametersFrom.put("roleSelText", roleSelText);
		
		}
	
		// userId - Originator
		if (chargebackAdminForm.getOriginator() != null && !chargebackAdminForm.getOriginator().isEmpty()) {
			searchParametersFrom.put("userId", chargebackAdminForm.getOriginator());
		}

		// Status
		searchParametersFrom.put("status", chargebackAdminForm.getStatus());
		if (chargebackAdminForm.getStatus() != null) {
			if (chargebackAdminForm.getStatus() != null && chargebackAdminForm.getStatus().equals("1")) {
				chargebackAdminForm.setStatusSelected("");
			}
			searchParametersFrom.put("statusSelected", chargebackAdminForm.getStatusSelected());
		}

		ResultList searchResults = null;
		if ((("".equals(chargebackAdminForm.getLocationNumber()) || chargebackAdminForm.getLocationNumber() == null)
				&& ("".equals(chargebackAdminForm.getRoleSelected()) || chargebackAdminForm.getRoleSelected() == null))
				&& ("".equals(chargebackAdminForm.getOriginator()) || chargebackAdminForm.getOriginator() == null)) {
			searchResults = userSearchResultDeligate.allUsers(searchParametersFrom);
		} else if (((chargebackAdminForm.getLocationNumber().isEmpty() || chargebackAdminForm.getLocationNumber() == null)
				&& (chargebackAdminForm.getRoleSelected().isEmpty() || chargebackAdminForm.getRoleSelected() == null))
				&& chargebackAdminForm.getOriginator() != null) {
			searchResults = userSearchResultDeligate.specificUserSearch(searchParametersFrom);
		} else if (((chargebackAdminForm.getLocationNumber().isEmpty() || chargebackAdminForm.getLocationNumber() == null)
				&& (chargebackAdminForm.getOriginator() == null || chargebackAdminForm.getOriginator().isEmpty()))
				&& chargebackAdminForm.getRoleSelected() != null) {
			searchResults = userSearchResultDeligate.specificRoleIdSearch(searchParametersFrom);
		} else {
			searchResults = userSearchResultDeligate.specificUserResults(searchParametersFrom);
		}
		
		chargebackAdminForm.setSearchResults(searchResults.getList());
		chargebackAdminForm.setTotalRecords(searchResults.getTotalCount().intValue());
		messages.add("searchCriteriaSummary", "messages.searchCriteriaSummary", new String[] {chargebackSearchDelegate.buildSearchCriteriaSummary(searchParametersFrom)});
		chargebackAdminForm.setRoleSelText(roleSelText);
		//saveMessages(request, messages);
		messages.saveMessages(request);
		 
		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("adminSearchResult"));
			request.setAttribute("actionMessages", messages);
			request.setAttribute("chargebackAdminForm", chargebackAdminForm);
		}

		//request.setAttribute("actionMessages", errors);//

		return mav;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/chargebackAdmin", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=adminDetail" })
	public ModelAndView adminDetail(@ModelAttribute("createNewUserForm") CreateNewUserForm createNewUserForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		HttpSession session = request.getSession();
		createNewUserForm.setFormParameterMap(request);
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		Map createParametersFromForm = createNewUserForm.getMap();
		log.debug("***** CHARGEBACK ADMIN *****edit*****");
		// Map searchRolesFromForm = createNewUserForm.getMap();
		List locations = chargebackSearchDelegate.getLocationsForCreateUser();
		createNewUserForm.setLocations(locations);

		List roles = chargebackSearchDelegate.getRoles();
		createNewUserForm.setRoles(roles);

		String userId = (String) request.getParameter("selectedUserId");

		CreateNewUserBO UserBODetails = chargebackSearchDelegate.getUserDetails(userId);
		createNewUserForm.populateFormFromObject(UserBODetails);
		ResultList searchResults = chargebackSearchDelegate.getUserRolesLocations(userId);
		/*
		 * List l = (List) searchResults.getList();// DELETE IT CreateNewUserBO cbkbo =
		 * new CreateNewUserBO(); for (int i = 0; i < l.size(); i++) { cbkbo =
		 * (CreateNewUserBO) l.get(i); }
		 */
		Map map = new HashMap();
		map = SeperateRolesFromMenuAccess((List) searchResults.getList());

		List LocationRolesList = (List) map.get("LocRole");
		createNewUserForm.setLocationRoles(LocationRolesList);

		List MenuAccessList = (List) map.get("MenuAccess");
		createNewUserForm.setMenuAccess(MenuAccessList);

		List rolesByUserForMenuList = adminDelegate.getRolesByUserForMenu();
		createNewUserForm.setRolesByUserForMenuList(rolesByUserForMenuList);

		mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("adminDetails"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("createNewUserForm", createNewUserForm);

		return mav;

	}

	public List getAddUserList(List rolesLocation, CreateNewUserForm createNewUserForm) {
		log.debug("***** CHARGEBACK ADMIN *****getAddUserList*****");
		List saveUserList = new ArrayList();

		Iterator i = rolesLocation.iterator();
		while (i.hasNext()) {
			CreateNewUserBO itemLine = (CreateNewUserBO) i.next();
			if (itemLine != null) {
				if (itemLine.getDistRoles() != null && itemLine.getDistLocNumber() != null) {
					itemLine.setUserId(createNewUserForm.getUserId());

					saveUserList.add(itemLine);
				}
			}
		}
		return saveUserList;
	}

	@SuppressWarnings("unchecked")
	public List insert(String userId, List<String> menus) {
		List saveMenuAccessList = new ArrayList();
		log.debug("***** CHARGEBACK ADMIN *****insert*****");
		if (menus.size() > 0) {
			for (int i = 0; i < menus.size(); i++) {
				Integer roleId = Integer.parseInt(menus.get(i));
				CreateNewUserBO menuAccess = new CreateNewUserBO();

				menuAccess.setUserId(userId);
				if (roleId == 90 || roleId == 95 || roleId == 92 || roleId == 96 || roleId == 91 || roleId == 93
						|| roleId == 94) {
					menuAccess.setRoleId(roleId.toString());
					menuAccess.setLocationNumber("999");
					saveMenuAccessList.add(menuAccess);
				}
				if (roleId == 97 || roleId == 98 || roleId == 99) {
					menuAccess.setRoleId(roleId.toString());
					menuAccess.setLocationNumber("888");
					saveMenuAccessList.add(menuAccess);
				}

			}

		}
		return saveMenuAccessList;
	}

	public Map SeperateRolesFromMenuAccess(List resultList) {
		Map m = new HashMap();
		List MenuAccessList = new ArrayList();
		List LocRolesList = new ArrayList();

		for (int i = 0; i < resultList.size(); i++) {
			CreateNewUserBO cbkbo = new CreateNewUserBO();
			cbkbo = (CreateNewUserBO) resultList.get(i);
			if (cbkbo.getDistLocNumber().equals("999") || cbkbo.getDistLocNumber().equals("888")) {
				MenuAccessList.add(cbkbo.getDistRoles());
			} else {
				LocRolesList.add(cbkbo);

			}
		}
		m.put("MenuAccess", MenuAccessList);
		m.put("LocRole", LocRolesList);

		return m;
	}

	@RequestMapping(value = "/chargebackAudits", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=chargeAudit" })
	public ModelAndView chargeAudit(@ModelAttribute("chargebackAdminForm") ChargebackAdminForm chargebackAdminForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackAdminForm.setFormParameterMap(request);
		log.debug("***** CHARGEBACK ADMIN *****chargeAudit*****");
		if (request.getParameter("isformreset") != null) {
			chargebackAdminForm.reset(request);
		}
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("byAudits"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackAdminForm", chargebackAdminForm);

		return mav;
	}

	@RequestMapping(value = "/chargebackAdmin", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=auditDetails" })
	public ModelAndView auditDetails(@ModelAttribute("chargebackAdminForm") ChargebackAdminForm chargebackAdminForm,
			HttpServletRequest request) throws Exception {
		String dateCriteria = request.getParameter("dateCriteria");
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK ADMIN *****auditDetails*****");
		if (request.getParameter("isformreset") != null) {
			chargebackAdminForm.reset(request);
		}
		Map searchParametersFrom = chargebackAdminForm.getMap();
		

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		String date = DateFunctions.chargebackDateConversion(chargebackAdminForm.getDate());
                List expIdList = adminDelegate.getExportId(date);
                if (expIdList.size() > 0) {
                    AdminResultsBO result = (AdminResultsBO) expIdList.get(0);

 

                    searchParametersFrom.put("exportedId", result.getExportedId());
                }
		
				
		searchParametersFrom.put("location", chargebackAdminForm.getLocation());
		if (chargebackAdminForm.getLocation().equals("2")) {
			searchParametersFrom.put("locationNumber", chargebackAdminForm.getLocationNumber());
		}
		String dt = chargebackAdminForm.getDate();
		if (messages.isEmpty()) {

			//searchParametersFrom.put("dateCriteria", dateCriteria);
			if (chargebackAdminForm.getDate() != null && !chargebackAdminForm.getDate().isEmpty()) {

				searchParametersFrom.put("date", DateFunctions.chargebackDateConversion(chargebackAdminForm.getDate()));
			}
		}
	
		
		
		
		ResultList searchResults = adminDelegate.getTypeAmount(searchParametersFrom);
		chargebackAdminForm.setSearchResults(searchResults.getList());

		/*
		 * Double locale; NumberFormat formatter = NumberFormat.getCurrencyInstance();
		 * if (formatter instanceof DecimalFormat) { DecimalFormat f = (DecimalFormat)
		 * formatter; f.setNegativePrefix("(" + f.getPositivePrefix());
		 * f.setNegativeSuffix(")"); } String output = formatter.format(
		 * chargebackAdminForm.setExportedAmount(locale));
		 * 
		 * 
		 * String ab="#,##0.00;(#,##0.00)";
		 * 
		 * DecimalFormat dft = (DecimalFormat)
		 * DecimalFormat.getInstance("#,##0.00;(#,##0.00)"); dft.applyPattern(ab);
		 * dft.format(chargebackAdminForm.setExportedAmount(ab));
		 * 
		 * 
		 * 
		 * Formatter f =new Formatter(); f.format("%d",
		 * chargebackAdminForm.getExportedAmount());
		 * 
		 * 
		 * String pattern ="#,##0.00;(#,##0.00)"; Double s1 ; DecimalFormat dft
		 * =(DecimalFormat) DecimalFormat.getInstance(); dft.applyPattern(pattern);
		 * //dft.format(chargebackAdminForm.getExportedAmount()); //pattern=
		 * pattern+String.parseDouble(chargebackAdminForm.getExportedAmount());
		 * chargebackAdminForm.setExportedAmount(dft.format(pattern));
		 */

		// Calculation of amount
		Double total = 0.00;

		DecimalFormat df = new DecimalFormat("0.00");
		if (searchResults.getList().size() > 0) {
			List l1 = (List) searchResults.getList();
			AdminResultsBO bo = new AdminResultsBO();

			for (int i = 0; i < l1.size(); i++) {
				bo = (AdminResultsBO) l1.get(i);

				total = total + Double.parseDouble(bo.getExportedAmount());

			}
		}
		chargebackAdminForm.setTotalExports(df.format(total).toString());
		chargebackAdminForm.setDate(dt);

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("byAudits"));
			// request.setAttribute("actionMessages", messages);
			request.setAttribute("chargebackAdminForm", chargebackAdminForm);
		}

		request.setAttribute("actionMessages", errors);
		return mav;

	}
	
	@RequestMapping(value = "/validateUser", method = { RequestMethod.GET,
			RequestMethod.POST }, consumes = "application/json", params = { "action=validateUserAction" })
	public @ResponseBody ResponseEntity<?> processAJAXRequest(@RequestParam("userId") String userId) {

		boolean validate = false;
		String userExist = null;
		if (userId != null) {
			// VALIDATE FROM DATABASE
			try {
				userExist = chargebackSearchDelegate.getValidateUserId(userId);
				
				if (userExist != null ) {
					validate = true;
				}

			} catch (DataAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return ResponseEntity.ok(validate);

	}

}