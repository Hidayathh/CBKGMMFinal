package com.unfi.cbk.controller.chargeback;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.CreateNewUserBO;
import com.unfi.cbk.bo.VendorBO;
import com.unfi.cbk.controller.ChargebackBaseController;
import com.unfi.cbk.controller.PageAccessResolver;
import com.unfi.cbk.delegates.ChargebackCreateDelegate;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.email.ChargebackMailer;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.forms.ChargebackCreateForm;
import com.unfi.cbk.forms.ChargebackSearchForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.util.StringFunctions;
import com.unfi.cbk.utilcore.ApplicationProperties;

/**
 * The GetResultsAction class is the struts action called when retrieving the
 * search results. The action simply determines the user type and forwards the
 * request to a secondary struts action specific to the user type.
 * <p>
 * This is to accommodate the struts Validator. Since all three versions of the
 * search form use the same ActionForm, the different validations that need to
 * be done specific to the type of form used are accomplished by having the
 * validator use the actions to determine which rules to use.<br>
 * This action, then, makes the user type transparent to the user by always
 * having the same action called when searching, regardless of user type.
 *
 * @author vpil001
 * @since 1.0
 */
@Controller("chargebackCreateAction_createChargeback")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ChargebackCreateController extends ChargebackBaseController {
	static Logger log = Logger.getLogger(ChargebackSearchResultsController.class);
	@Autowired
	private ChargebackSearchDelegate chargebackSearchDelegate;
	@Autowired
	private ChargebackCreateDelegate chargebackCreateDelegate;
	@Autowired
	private ChargebackMailer chargebackMailer;

//	
	public ChargebackCreateController(ChargebackSearchDelegate chargebackSearchDelegate,
			ChargebackCreateDelegate chargebackCreateDelegate) {
		this.chargebackSearchDelegate = chargebackSearchDelegate;
		this.chargebackCreateDelegate = chargebackCreateDelegate;
	}

	@Autowired
	ActionMessages messages;
	@Autowired
	Environment env;
	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	private static String TEST_EMAIL = ApplicationProperties.getDummyEMail();

	@RequestMapping(value = "/createChargeback", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView create(@ModelAttribute("chargebackCreateForm") ChargebackCreateForm chargebackCreateForm,
			ChargebackSearchForm chargebackSearchForm, HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK create Controller *****");
		chargebackCreateForm.setFormParameterMap(request);
		chargebackSearchForm.setFormParameterMap(request);

		String vendorId = null;
		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");
		if (request.getParameter("vendorId") != null) {
			vendorId = request.getParameter("vendorId");
		}
		String locationNumber = request.getParameter("locationNumber");

		Map<String, Comparable> createParametersFromForm = chargebackCreateForm.getMap();
		chargebackCreateForm.validate(request, messages);
		createParametersFromForm.put("locationNumber", locationNumber);
		createParametersFromForm.put("userId", SmUserId);

		if (chargebackCreateForm.getLocationNumber() != null) {

			String idPattern = "[\\s0-9,. ]*";
			boolean specialCharFlag = validateSpecialCharacters(chargebackCreateForm.getLocationNumber().toString(),
					idPattern);
			if (specialCharFlag == true) {
				messages.add("locationNumber", "errors.validateLocation", null);
			}
		}
		if (messages.isEmpty()) {
			if (locationNumber != null) {

				String location = locationNumber.substring(0, 2);
				createParametersFromForm.put("location", location);
				ResultList locationValidatorResult = chargebackSearchDelegate
						.locationNumberValidator(createParametersFromForm);
				if (locationValidatorResult.getList().size() == 0) {
					messages.add("locationNumber", "errors.InvalidLocationNumber", null);

				}
			}

		}
		if (!messages.isEmpty()) {
			// TODO return back to the same.
			List chargebackTypes = chargebackSearchDelegate.getChargebackTypesForCreate();
			chargebackSearchForm.setChargebackTypes(chargebackTypes);
			request.setAttribute("actionMessages", messages);
			messages.saveMessages(request);
			mav.setViewName(ActionUrlMapping.CHARGEBACKNEWSEARCHACTION.get(Constants.ACTION_SUCCESS));
			request.setAttribute("chargebackSearchForm", chargebackSearchForm);
			return mav;
		}

		// Define the display parameters
		int maxRows = 20;
		chargebackCreateForm.setDisplayCount(maxRows);
		createParametersFromForm.put("locationNumber", locationNumber);
		createParametersFromForm.put("vendorId", vendorId);

		if (chargebackCreateForm.isShowAll()) {
			createParametersFromForm.put("showAll", "true");
		} else {
			createParametersFromForm.put("rowStart", Integer.valueOf(chargebackCreateForm.getCurrentRecord()));
			createParametersFromForm.put("rowEnd",
					Integer.valueOf(chargebackCreateForm.getCurrentRecord() + maxRows - 1));
		}

		// initialize date to current date
		chargebackCreateForm.setInvoiceDate(DateFunctions.formatDate(new Date()));
		chargebackCreateForm.setDueDate(DateFunctions.formatDate(new Date()));
		chargebackCreateForm.setCreatorId(SmUserId);
		chargebackCreateForm.setInProcess(Integer.valueOf("0"));

		// Get the ChargebackType list
		List<ChargebackBO> chargebackTypes = chargebackSearchDelegate.getChargebackTypesForCreate();
		chargebackCreateForm.setChargebackTypes(chargebackTypes);

		// Get the Reasons list
		List<ChargebackBO> reasons = chargebackSearchDelegate.getReasons();
		chargebackCreateForm.setReasons(reasons);

		// Get the Product group list
		List<ChargebackBO> productGroup = chargebackSearchDelegate.getProductGroup();
		chargebackCreateForm.setProductGroups(productGroup);

		// Get the locations list
		List<ChargebackBO> locations = chargebackSearchDelegate.getLocations();
		chargebackCreateForm.setLocations(locations);

		// Get the sub Funds list
		// List<ChargebackBO> subFunds = chargebackCreateDelegate.getSubFunds();
		// chargebackCreateForm.setSubFunds(subFunds);

		/*
		 * // Get the vendor informaton ChargebackBO vendorInfo =
		 * chargebackSearchDelegate.getChargebackVendor(createParametersFromForm); if
		 * (vendorInfo != null) {
		 * chargebackCreateForm.populateFormFromObjectVendor(chargebackCreateForm,
		 * vendorInfo); }
		 */
		// generateAndSetNextInvoice(chargebackCreateForm, chargebackSearchDelegate);

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKCREATEACTIONS.get(Constants.ACTION_SUCCESS));
			request.setAttribute("actionMessages", messages);
			return mav;
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKCREATEACTIONS.get("other"));
		request.setAttribute("actionMessages", messages);
		request.setAttribute("chargebackCreateForm", chargebackCreateForm);
		return mav;

	}

	/**
	 * submit method
	 * 
	 * @param chargebackCreateForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/createChargeback", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=submit" })
	public ModelAndView submit(@ModelAttribute("chargebackCreateForm") ChargebackCreateForm chargebackCreateForm,
			@RequestParam("file") MultipartFile file, HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean exceptionOccurred = false;
		boolean sendNotification = false;
		boolean isInvoiceExist = false;
		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");
		log.debug("***** Chargeback create  submit *****");
		String extensionTotal = null;

		try {

			String nextInvoiceNumber = null;
			String insertType = null;

			if (request.getParameter("nextInvoiceNumber") != null) {
				nextInvoiceNumber = request.getParameter("nextInvoiceNumber");
				chargebackCreateForm.setNextInvoiceNumber(nextInvoiceNumber);
			}
			if (request.getParameter("insertType") != null) {
				insertType = request.getParameter("insertType");
				chargebackCreateForm.setInsertType(insertType);
			}
			if (request.getParameter("detailTotal") != null) {
				extensionTotal = request.getParameter("detailTotal");
			}

			Map<String, Comparable> createParametersFromForm = chargebackCreateForm.getMap();
			createParametersFromForm.put("invoiceNumber", chargebackCreateForm.getInvoiceNumber());
			createParametersFromForm.put("vendorId", chargebackCreateForm.getVendorId());
			createParametersFromForm.put("locationNumber", chargebackCreateForm.getLocationNumber());
			chargebackCreateForm.setCreatorId(SmUserId);
			chargebackCreateForm.setInProcess(Integer.valueOf("0"));
			createParametersFromForm.put("attachmentType", chargebackCreateForm.getAttachmentType());

			// START OF SUBMIT CODE

			// DISTRIBUTION LNES VALIDATION START
			List<ChargebackBO> distributionList = chargebackCreateForm.getSlItemList(); // DistributionList

			Iterator<ChargebackBO> i = distributionList.iterator();

			chargebackCreateForm.setAccountErorMessage("");
			// Integer j=0;

			chargebackCreateForm.setValidatorMessages(messages.toString());
			chargebackCreateForm.validate(request, messages);
			// messages.saveMessages(request);

			// Get the Company code
			String companyCode = null;
			companyCode = chargebackSearchDelegate.getCompanyCode(chargebackCreateForm.getLocationNumber());
			chargebackCreateForm.setCompanyCode(companyCode);
			createParametersFromForm.put("companyCode", companyCode);

			if (!file.isEmpty()) {
				generateAndSetNextBarcode(chargebackCreateForm, chargebackSearchDelegate);
			}

			// Insert Data in to Chargeback details
			chargebackSearchDelegate.updateChargeback(populateObjectFromForm(chargebackCreateForm), true);

			// Code for file Attachment
			ChargebackBO chargebackBO = new ChargebackBO();
			if (!file.isEmpty()) {
				byte[] bytes = file.getBytes();
				String fileExtention = file.getOriginalFilename();
				int lastIndexOf = fileExtention.lastIndexOf(".");
				if (lastIndexOf != -1) {
					fileExtention = fileExtention.substring(lastIndexOf);
				} else {
					fileExtention = "";
				}
				String fileName = StringFunctions.fileNameGenerationCreate(chargebackCreateForm, fileExtention);
				chargebackBO.setInvoiceNumber(chargebackCreateForm.getInvoiceNumber());
				chargebackBO.setLocationNumber(chargebackCreateForm.getLocationNumber());
				chargebackBO.setAttachmentType(chargebackCreateForm.getAttachmentType());
				chargebackBO.setAttachmentDate(new Date());
				chargebackBO.setFilename(fileName);
				chargebackBO.setAttachmentFile(bytes);
				chargebackSearchDelegate.createAttachment(chargebackBO);
			}

			String generatedInvoice = getNextInvoice(chargebackCreateForm, chargebackSearchDelegate);

			// Insert or update generated invoice number to database
//			if(generatedInvoice!=null && generatedInvoice.equals(chargebackCreateForm.getInvoiceNumber()))
//			{
			updateGeneratedInvoice(chargebackCreateForm, chargebackSearchDelegate, nextInvoiceNumber, insertType);
			// }
			List<ChargebackBO> detailList = chargebackCreateForm.getGlItemList(); // DetailList
			chargebackSearchDelegate.createCbkItem(getItemDetailList(detailList, chargebackCreateForm));
			// List<ChargebackBO> distributionList = chargebackCreateForm.getSlItemList();
			// //DistributionList
			chargebackSearchDelegate.createCbkDistribution(getDistributionList(distributionList, chargebackCreateForm));

			// Get the Email address of the Approver

			if (!chargebackCreateForm.getApprover().equals("") && chargebackCreateForm.getApprover() != null) {
				// CreateNewUserBO UserBODetails =
				// chargebackSearchDelegate.getUserDetails(chargebackCreateForm.getApprover());
				// Send email only when user finally confirmed on the approver and notification
				/*
				 * if (UserBODetails != null && UserBODetails.getUseremailId() != null) {
				 * UserBODetails.setUseremailId(TEST_EMAIL); // need to remove this line when we
				 * are at actual // environment.
				 * chargebackMailer.createSendEmail(chargebackCreateForm,
				 * UserBODetails.getUseremailId(), SmUserId);
				 * 
				 * }
				 */
				chargebackMailer.createSendEmail(chargebackCreateForm, TEST_EMAIL, SmUserId);
			} else {
				CreateNewUserBO UserBODetails = chargebackSearchDelegate.getUserDetails(SmUserId);
				// Send email only when user finally confirmed on the approver and notification
				if (UserBODetails != null && UserBODetails.getUseremailId() != null) {
					UserBODetails.setUseremailId(TEST_EMAIL); //// need to remove this line when we are at actual
																//// environment.
					chargebackMailer.createSendEmail(chargebackCreateForm, UserBODetails.getUseremailId(), SmUserId);
				}
			}

			// Aproving the chargeback when user has Role Id 1 with approver limit <=5000

			String userApprovalWith5KLimit = chargebackSearchDelegate.getApprovalWith5KLimit(SmUserId,
					chargebackCreateForm.getLocationNumber());

			if (userApprovalWith5KLimit != null && extensionTotal != null
					&& Double.parseDouble(extensionTotal) <= 5000) {

				ChargebackBO cbkBo = new ChargebackBO();
				// Call the common method to return the list
				cbkBo.setInvoiceNumber(chargebackCreateForm.getInvoiceNumber());
				cbkBo.setLocationNumber(chargebackCreateForm.getLocationNumber());
				cbkBo.setApproverId(SmUserId);
				cbkBo.setStepNumber(
						chargebackSearchDelegate.getMinStepNumber(chargebackCreateForm.getTypeId().toString()));
				cbkBo.setApprovalDate(new Date());
				cbkBo.setNextAproverId("No further approvals");
				chargebackSearchDelegate.updateChargebackApprover(cbkBo);

				// Insert in to Approvals
				chargebackSearchDelegate.approveChargebacks(cbkBo);
			}

			// END OF SUBMIT CODE

			generateAndSetNextInvoice(chargebackCreateForm, chargebackSearchDelegate);

			chargebackCreateForm.reset();
			// Get the ChargebackType list
			List<ChargebackBO> chargebackTypes = chargebackSearchDelegate.getChargebackTypesForCreate();
			chargebackCreateForm.setChargebackTypes(chargebackTypes);

			// Get the Reasons list
			List<ChargebackBO> reasons = chargebackSearchDelegate.getReasons();
			chargebackCreateForm.setReasons(reasons);

			// Get the Product group list
			List<ChargebackBO> productGroup = chargebackSearchDelegate.getProductGroup();
			chargebackCreateForm.setProductGroups(productGroup);

			// Get the locations list
			List<ChargebackBO> locations = chargebackSearchDelegate.getLocations();
			chargebackCreateForm.setLocations(locations);

			// Get the sub Funds list
			List<ChargebackBO> subFunds = chargebackCreateDelegate.getSubFunds();
			chargebackCreateForm.setSubFunds(subFunds);

			// Get the vendor informaton
			//ChargebackBO vendorInfo = chargebackSearchDelegate.getChargebackVendor(createParametersFromForm);
			///if (vendorInfo != null) {
			//	chargebackCreateForm.populateFormFromObjectVendor(chargebackCreateForm, vendorInfo);
			//}
			chargebackCreateForm.setInvoiceDate(DateFunctions.formatDate(new Date()));

		} catch (Exception e) {
			// Determine the error, log it, and put an error message in ActionErrors
			exceptionOccurred = true;
			e.printStackTrace();
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);

		}

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess() && !exceptionOccurred) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKCREATEACTIONS.get(Constants.ACTION_SUCCESS));
			request.setAttribute("actionMessages", messages);
			chargebackCreateForm.reset();
			chargebackCreateForm.resetForm(chargebackCreateForm);
			return mav;
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKCREATEACTIONS.get("other"));
		request.setAttribute("actionMessages", messages);
		request.setAttribute("chargebackCreateForm", chargebackCreateForm);
		return mav;

	}

	/**
	 * save method
	 * 
	 * @param chargebackCreateForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/createChargeback", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=save" })
	public ModelAndView save(@ModelAttribute("chargebackCreateForm") ChargebackCreateForm chargebackCreateForm,
			@RequestParam("file") MultipartFile file, HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean exceptionOccurred = false;
		boolean sendNotification = false;
		boolean isInvoiceExist = false;
		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");
		log.debug("***** Chargeback create  Save Method *****");
		String extensionTotal = null;

		try {

			String nextInvoiceNumber = null;
			String insertType = null;

			if (request.getParameter("nextInvoiceNumber") != null) {
				nextInvoiceNumber = request.getParameter("nextInvoiceNumber");
				chargebackCreateForm.setNextInvoiceNumber(nextInvoiceNumber);
			}
			if (request.getParameter("insertType") != null) {
				insertType = request.getParameter("insertType");
				chargebackCreateForm.setInsertType(insertType);
			}
			if (request.getParameter("detailTotal") != null) {
				extensionTotal = request.getParameter("detailTotal");
			}

			Map<String, Comparable> createParametersFromForm = chargebackCreateForm.getMap();
			createParametersFromForm.put("invoiceNumber", chargebackCreateForm.getInvoiceNumber());
			createParametersFromForm.put("vendorId", chargebackCreateForm.getVendorId());
			createParametersFromForm.put("locationNumber", chargebackCreateForm.getLocationNumber());
			chargebackCreateForm.setCreatorId(SmUserId);
			chargebackCreateForm.setInProcess(Integer.valueOf("0"));
			createParametersFromForm.put("attachmentType", chargebackCreateForm.getAttachmentType());

			// START OF SUBMIT CODE

			// DISTRIBUTION LNES VALIDATION START
			List<ChargebackBO> distributionList = chargebackCreateForm.getSlItemList(); // DistributionList

			Iterator<ChargebackBO> i = distributionList.iterator();

			chargebackCreateForm.setAccountErorMessage("");
			// Integer j=0;

			chargebackCreateForm.setValidatorMessages(messages.toString());
			chargebackCreateForm.validate(request, messages);
			// messages.saveMessages(request);

			// Get the Company code
			String companyCode = null;
			companyCode = chargebackSearchDelegate.getCompanyCode(chargebackCreateForm.getLocationNumber());
			chargebackCreateForm.setCompanyCode(companyCode);
			createParametersFromForm.put("companyCode", companyCode);

			if (!file.isEmpty()) {
				generateAndSetNextBarcode(chargebackCreateForm, chargebackSearchDelegate);
			}

			// Insert Data in to Chargeback details
			chargebackSearchDelegate.updateChargeback(populateObjectFromForm(chargebackCreateForm), true);

			// Code for file Attachment
			ChargebackBO chargebackBO = new ChargebackBO();
			if (!file.isEmpty()) {
				byte[] bytes = file.getBytes();
				String fileExtention = file.getOriginalFilename();
				int lastIndexOf = fileExtention.lastIndexOf(".");
				if (lastIndexOf != -1) {
					fileExtention = fileExtention.substring(lastIndexOf);
				} else {
					fileExtention = "";
				}
				String fileName = StringFunctions.fileNameGenerationCreate(chargebackCreateForm, fileExtention);
				chargebackBO.setInvoiceNumber(chargebackCreateForm.getInvoiceNumber());
				chargebackBO.setLocationNumber(chargebackCreateForm.getLocationNumber());
				chargebackBO.setAttachmentType(chargebackCreateForm.getAttachmentType());
				chargebackBO.setAttachmentDate(new Date());
				chargebackBO.setFilename(fileName);
				chargebackBO.setAttachmentFile(bytes);
				chargebackSearchDelegate.createAttachment(chargebackBO);
			}

			String generatedInvoice = getNextInvoice(chargebackCreateForm, chargebackSearchDelegate);

			// Insert or update generated invoice number to database
			/*
			 * if(generatedInvoice!=null &&
			 * generatedInvoice.equals(chargebackCreateForm.getInvoiceNumber())) {
			 */
			updateGeneratedInvoice(chargebackCreateForm, chargebackSearchDelegate, nextInvoiceNumber, insertType);
			// }
			List<ChargebackBO> detailList = chargebackCreateForm.getGlItemList(); // DetailList

			// Inserting the data in Item table only when list is not empty
			if (detailList != null && detailList.size() > 0) {
				chargebackSearchDelegate.createCbkItem(getItemDetailList(detailList, chargebackCreateForm));
			}

			if (distributionList != null && distributionList.size() > 0) {
				chargebackSearchDelegate
						.createCbkDistribution(getDistributionList(distributionList, chargebackCreateForm));
			}

			// END OF SUBMIT CODE

			//generateAndSetNextInvoice(chargebackCreateForm, chargebackSearchDelegate);

			chargebackCreateForm.reset();

		} catch (Exception e) {
			// Determine the error, log it, and put an error message in ActionErrors
			exceptionOccurred = true;
			e.printStackTrace();
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);

		}

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess() && !exceptionOccurred) {
			//mav.setViewName(ActionUrlMapping.CHARGEBACKCREATEACTIONS.get(Constants.ACTION_SUCCESS));
			mav.setViewName(ActionUrlMapping.CHARGEBACKCREATEACTIONS.get("save"));
			request.setAttribute("actionMessages", messages);
			chargebackCreateForm.reset();
			chargebackCreateForm.resetForm(chargebackCreateForm);
			return mav;
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKCREATEACTIONS.get("other"));
		request.setAttribute("actionMessages", messages);
		request.setAttribute("chargebackCreateForm", chargebackCreateForm);
		return mav;

	}

	public void generateAndSetNextInvoice(ChargebackCreateForm chargebackCreateForm,
			ChargebackSearchDelegate chargebackSearchDelegate) {
		ChargebackBO invoiceBO = null;
		String twoDigitlocationNumber = chargebackCreateForm.getLocationNumber().substring(0, 2);
		try {

			invoiceBO = chargebackSearchDelegate.getNextInvoceNumberOrBarcode(twoDigitlocationNumber);

			if (invoiceBO != null && invoiceBO.getLocationNumber() != null) {

				// location found and invoice reached to 0000000
				if (Integer.parseInt(invoiceBO.getInvoiceNumber()) == (Constants.MAX_INVOICE)) {
					chargebackCreateForm.setNextInvoiceNumber(twoDigitlocationNumber + "0");
					chargebackCreateForm.setInvoiceNumber(String.valueOf(Constants.MAX_INVOICE));
					chargebackCreateForm.setInsertType("1");
				} else // location found and invoice not reached to 0000000
				{
					Integer nextInvoice = Integer.parseInt(invoiceBO.getInvoiceNumber());
					chargebackCreateForm.setNextInvoiceNumber(String.valueOf(nextInvoice + 1));
					chargebackCreateForm.setInvoiceNumber(twoDigitlocationNumber + invoiceBO.getInvoiceNumber());
					chargebackCreateForm.setInsertType("2");
				}

			} else // location not available
			{
				chargebackCreateForm.setInvoiceNumber(twoDigitlocationNumber + "1");
				chargebackCreateForm.setNextInvoiceNumber(twoDigitlocationNumber + "2");
				chargebackCreateForm.setInsertType("3");
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in execute:" + e);

		}
	}

	public String getNextInvoice(ChargebackCreateForm chargebackCreateForm,
			ChargebackSearchDelegate chargebackSearchDelegate) {
		ChargebackBO invoiceBO = null;
		String invoiceNum = null;
		String twoDigitlocationNumber = chargebackCreateForm.getLocationNumber().substring(0, 2);
		try {

			invoiceBO = chargebackSearchDelegate.getNextInvoceNumberOrBarcode(twoDigitlocationNumber);

			if (invoiceBO != null && invoiceBO.getLocationNumber() != null) {

				// location found and invoice reached to 0000000
				if (Integer.parseInt(invoiceBO.getInvoiceNumber()) == (Constants.MAX_INVOICE)) {
					// chargebackCreateForm.setNextInvoiceNumber(twoDigitlocationNumber + "0");
					// chargebackCreateForm.setInvoiceNumber(String.valueOf(Constants.MAX_INVOICE));
					// chargebackCreateForm.setInsertType("1");
					invoiceNum = String.valueOf(Constants.MAX_INVOICE);
				} else // location found and invoice not reached to 0000000
				{
					Integer nextInvoice = Integer.parseInt(invoiceBO.getInvoiceNumber());
					// chargebackCreateForm.setNextInvoiceNumber(String.valueOf(nextInvoice + 1));
					// chargebackCreateForm.setInvoiceNumber(twoDigitlocationNumber +
					// invoiceBO.getInvoiceNumber());
					// chargebackCreateForm.setInsertType("2");
					invoiceNum = twoDigitlocationNumber + invoiceBO.getInvoiceNumber();
				}

			} else // location not available
			{
				// chargebackCreateForm.setInvoiceNumber(twoDigitlocationNumber + "1");
				// chargebackCreateForm.setNextInvoiceNumber(twoDigitlocationNumber + "2");
				// chargebackCreateForm.setInsertType("3");
				invoiceNum = twoDigitlocationNumber + "1";
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in execute:" + e);

		}
		return invoiceNum;
	}

	public void updateGeneratedInvoice(ChargebackCreateForm chargebackCreateForm,
			ChargebackSearchDelegate chargebackSearchDelegate, String nextInvoice, String insertType) {

		String twoDigitlocationNumber = chargebackCreateForm.getLocationNumber().substring(0, 2);

		try {
			if (insertType.equals("1") || insertType.equals("2")) {
				ChargebackBO newInvoiceBO = new ChargebackBO();
				newInvoiceBO.setInvoiceNumber(nextInvoice);
				newInvoiceBO.setLocationNumber(twoDigitlocationNumber);
				chargebackSearchDelegate.updateInvoice(newInvoiceBO);

			} else if (insertType.equals("3")) {
				ChargebackBO newInvoiceBO = new ChargebackBO();
				newInvoiceBO.setInvoiceNumber(nextInvoice);
				newInvoiceBO.setLocationNumber(twoDigitlocationNumber);
				chargebackSearchDelegate.insertInvoice(newInvoiceBO);
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in execute:" + e);

		}
	}

	public void generateAndSetNextBarcode(ChargebackCreateForm chargebackCreateForm,
			ChargebackSearchDelegate chargebackSearchDelegate) {
		ChargebackBO barCodeBO = null;
		ChargebackBO newBarCodeBO = null;
		try {
			// Get the next invoice from database
			if (chargebackCreateForm.getBarCode() == null) {
				barCodeBO = chargebackSearchDelegate.getNextInvoceNumberOrBarcode("-1");

				if (barCodeBO != null && barCodeBO.getLocationNumber() != null) {

					// location found and barcode reached to maximum
					if (Integer.parseInt(barCodeBO.getInvoiceNumber()) == (Constants.MAX_BARCODE)) {
						newBarCodeBO = new ChargebackBO();
						newBarCodeBO.setInvoiceNumber(String.valueOf(Constants.MIN_BARCODE + 2));
						newBarCodeBO.setLocationNumber(Constants.BARCODE_LOCATION_NO);
						chargebackCreateForm.setBarCode(Constants.MIN_BARCODE + 1);

						chargebackSearchDelegate.updateInvoice(newBarCodeBO);

					} else // location found and barcode not reached to 0000000
					{
						Integer nextBarCode = Integer.parseInt(barCodeBO.getInvoiceNumber());
						newBarCodeBO = new ChargebackBO();
						newBarCodeBO.setInvoiceNumber(String.valueOf(nextBarCode + 1));
						newBarCodeBO.setLocationNumber(Constants.BARCODE_LOCATION_NO);
						chargebackSearchDelegate.updateInvoice(newBarCodeBO);
						chargebackCreateForm.setBarCode(Integer.parseInt(barCodeBO.getInvoiceNumber()));
					}

				} else // location not available
				{
					newBarCodeBO = new ChargebackBO();
					newBarCodeBO.setInvoiceNumber(String.valueOf(Constants.MIN_BARCODE + 2));
					newBarCodeBO.setLocationNumber(Constants.BARCODE_LOCATION_NO);
					chargebackSearchDelegate.insertInvoice(newBarCodeBO);
					chargebackCreateForm.setBarCode(Constants.MIN_BARCODE + 1);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in execute:" + e);

		}
	}

	/**
	 * 
	 * @param detailList
	 * @param chargebackCreateForm
	 * @return
	 */

	public List<ChargebackBO> getItemDetailList(List<ChargebackBO> detailList,
			ChargebackCreateForm chargebackCreateForm) {

		List<ChargebackBO> saveDetailList = new ArrayList<ChargebackBO>();
		// List updateList = new ArrayList();
		String itemPrice = "";
		String newitemPrice = "";

		Iterator<ChargebackBO> i = detailList.iterator();
		Integer j = 1;
		while (i.hasNext()) {
			ChargebackBO itemLine = i.next();

			if (itemLine != null) {
				if (itemLine.getItemDesc() != null && itemLine.getItemPriceFormat() != null
						&& !itemLine.getItemPriceFormat().equals("")) {
					if (itemLine.getItemPriceFormat().contains(",")) {
						itemPrice = itemLine.getItemPriceFormat();
						newitemPrice = itemPrice.replaceAll(",", "");
						itemLine.setItemPriceFormat(newitemPrice);
					}
					itemLine.setLineNumber(j++);
					itemLine.setLocationNumber(chargebackCreateForm.getLocationNumber());
					itemLine.setInvoiceNumber(chargebackCreateForm.getInvoiceNumber());
					saveDetailList.add(itemLine);
				}
			}
		}
		return saveDetailList;

	}

	/**
	 * 
	 * @param distributionList
	 * @param chargebackCreateForm
	 * @return
	 */
	public List<ChargebackBO> getDistributionList(List<ChargebackBO> distributionList,
			ChargebackCreateForm chargebackCreateForm) {

		// Get Item Details

		List<ChargebackBO> saveDistributionList = new ArrayList<ChargebackBO>();
		Iterator<ChargebackBO> i = distributionList.iterator();
		Integer j = 1;
		while (i.hasNext()) {
			ChargebackBO distributionLine = i.next();

			if (distributionLine != null) {
				if (distributionLine.getDistLocNumber() != null && !distributionLine.getDistLocNumber().isEmpty()
						&& distributionLine.getAccountNumber() != null && !distributionLine.getAccountNumber().isEmpty()
						&& distributionLine.getProductGrp() != null && !distributionLine.getProductGrp().isEmpty()
						&& distributionLine.getDistributionAmt() != null) {

					distributionLine.setLineNumber(j++);
					distributionLine.setLocationNumber(chargebackCreateForm.getLocationNumber());
					distributionLine.setInvoiceNumber(chargebackCreateForm.getInvoiceNumber());
					distributionLine.setCompanyCode(chargebackCreateForm.getCompanyCode());

					saveDistributionList.add(distributionLine);
				}
			}
		}

		return saveDistributionList;

	}

	/**
	 * populate the Chargeback information from form
	 * 
	 * @param cbk
	 */
	public ChargebackBO populateObjectFromForm(ChargebackCreateForm createForm) {
		ChargebackBO cbk = new ChargebackBO();
		cbk.setLocationNumber(createForm.getLocationNumber());
		cbk.setInvoiceNumber(createForm.getInvoiceNumber());
		cbk.setDueDate(DateFunctions.stringToDate(createForm.getDueDate()));
		cbk.setInvoiceDate(new Date());
		cbk.setVendorId(createForm.getVendorId());
		cbk.setVendorInvoice(createForm.getVendorInvoice());
		cbk.setAttachment(createForm.getAttachment());
		cbk.setTypeId(createForm.getTypeId());
		cbk.setCreatorId(createForm.getCreatorId());
		cbk.setBarCode(createForm.getBarCode());
		cbk.setShortDesc(createForm.getShortDesc());
		cbk.setExported(createForm.getExported());
		cbk.setCancelled(createForm.getCancelled());
		cbk.setApprover(createForm.getApprover());
		cbk.setInterInstr(createForm.getInterInstr());
		cbk.setReasonCode(createForm.getReasonCode());
		cbk.setInProcess(createForm.getInProcess());
		cbk.setReferenceNumber(createForm.getReferenceNumber());
		cbk.setPrdGrpCode(createForm.getPrdGrpCode());
		cbk.setCompanyCode(createForm.getCompanyCode());
		cbk.setAccountNumber(createForm.getAccountNumber());
		cbk.setDistributionAmt(createForm.getDistributionAmt());
		cbk.setDistLocNumber(createForm.getDistLocNumber());
		cbk.setProductGrp(createForm.getProductGrp());
		cbk.setLineNumber(createForm.getLineNumber());
		cbk.setItemNumber(createForm.getItemNumber());
		cbk.setItemPack(createForm.getItemPack());
		cbk.setItemSize(createForm.getItemSize());
		cbk.setItemDesc(createForm.getItemDesc());
		cbk.setItemUpc(createForm.getItemUpc());
		cbk.setItemSlot(createForm.getItemSlot());
		cbk.setItemQuantity(createForm.getItemQuantity());
		cbk.setItemPriceFormat(createForm.getItemPriceFormat());
		cbk.setProductCode(createForm.getProductCode());
		cbk.setDcNumber(createForm.getDcNumber());
		cbk.setRegion(createForm.getRegion());
		cbk.setDivision(createForm.getDivision());
		cbk.setSubFund(createForm.getSubFund());
		cbk.setAttachmentType(createForm.getAttachmentType());
		return cbk;
	}

	public void getInsertedDataAfterSave(
			@ModelAttribute("chargebackCreateForm") ChargebackCreateForm chargebackCreateForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK -  *****");
		chargebackCreateForm.setFormParameterMap(request);
		boolean exceptionOccurred = false;
		String invoiceNumber = null;
		String vendorId = null;

		try {
			Map<String, Comparable> updateParametersFromForm = chargebackCreateForm.getMap();
			updateParametersFromForm.put("locationNumber", chargebackCreateForm.getLocationNumber());
			updateParametersFromForm.put("vendorId", chargebackCreateForm.getVendorId());
			updateParametersFromForm.put("invoiceNumber", chargebackCreateForm.getInvoiceNumber());

			// Get the ChargebackType list
			List<ChargebackBO> chargebackTypes = chargebackSearchDelegate.getChargebackTypesForCreate();
			chargebackCreateForm.setChargebackTypes(chargebackTypes);

			// Get the Reasons list
			List<ChargebackBO> reasons = chargebackSearchDelegate.getReasons();
			chargebackCreateForm.setReasons(reasons);

			// Get the Product group list
			List<ChargebackBO> productGroup = chargebackSearchDelegate.getProductGroup();
			chargebackCreateForm.setProductGroups(productGroup);

			// Get the locations list
			List<ChargebackBO> locations = chargebackSearchDelegate.getLocations();
			chargebackCreateForm.setLocations(locations);

			// Get the sub Funds list
			List<ChargebackBO> subFunds = chargebackCreateDelegate.getSubFunds();
			chargebackCreateForm.setSubFunds(subFunds);

			// Get the vendor informaton
			//ChargebackBO vendorInfo = chargebackSearchDelegate.getChargebackVendor(updateParametersFromForm);
			//if (vendorInfo != null) {
			//	chargebackCreateForm.populateFormFromObjectVendor(chargebackCreateForm, vendorInfo);
			//}

			ChargebackBO cbkBo = chargebackSearchDelegate.getChargebackInfo(updateParametersFromForm);
			chargebackCreateForm.populateFormFromObject(cbkBo);
			updateParametersFromForm.put("locationNumber", cbkBo.getLocationNumber());
			// Get the search results based on the parameters in the form
			ResultList searchResults = chargebackSearchDelegate.getCbkDetTable(updateParametersFromForm);
			// Populate the 'searchResults' property in the ActionForm
			// chargebackCreateForm.setDetailResults(searchResults.getList());
			chargebackCreateForm.setGlItems(searchResults.getList());
			// Get the search results based on the parameters in the form
			ResultList distibutionResults = chargebackSearchDelegate
					.getChargebackDistribution(updateParametersFromForm);
			chargebackCreateForm.setSlItems(distibutionResults.getList());

		} catch (Exception e) {
			exceptionOccurred = true;
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
		}

	}

	/**
	 * validateAccount method
	 * 
	 * @param chargebackCreateForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/validateAccount", method = { RequestMethod.GET,
			RequestMethod.POST }, consumes = "application/json", params = { "action=submitAccount" })
	public @ResponseBody ResponseEntity<?> processAJAXRequest(@RequestParam("distLocNumb") String locNum,
			@RequestParam("prodGrp") String prodGrp, @RequestParam("accNum") String accNum) {

		boolean validate = false;
		if (locNum != null && prodGrp != null && accNum != null) {
			Map<String, String> m = new HashMap<>();

			m.put("acctUnit", "0" + locNum + prodGrp);
			m.put("accountNumber", accNum);

			// VALIDATE FROM DATABASE
			ResultList prodAcctValidator;
			try {
				prodAcctValidator = chargebackSearchDelegate.getAccountProductCodes(m);
				if (prodAcctValidator.getList().size() == 0) {

					validate = true;
				}

			} catch (DataAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return ResponseEntity.ok(validate);
	}

	/**
	 * validate Item Number
	 * 
	 * @param chargebackCreateForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = "/validateItemNumber", method = { RequestMethod.GET,
			RequestMethod.POST }, consumes = "application/json", params = { "action=validateItem" })
	public @ResponseBody ResponseEntity<?> processAJAXRequest(@RequestParam("itemNum") String itemNum,
			@RequestParam("dcNumber") String dcNumber) {

		List validate = new ArrayList();
		// List<ChargebackBO> itemDetailsList = new ArrayList<ChargebackBO>();
		if (itemNum != null && dcNumber != null) {
			Map<String, String> m = new HashMap<>();

			m.put("itemNum", itemNum);
			m.put("dcNumber", dcNumber);
			// VALIDATE FROM DATABASE

			List<ChargebackBO> itemValidatorDetails = new ArrayList<ChargebackBO>();
			try {
				itemValidatorDetails = chargebackCreateDelegate.getItemInfo(m);
				if (itemValidatorDetails.size() > 0) {

					// PI_ITM_PCK_QTY itemPack, PI_SIZE_TXT itemSize, PI_ITM_DESC itemDesc,
					// PI_POS_MFG_ID itemUpc, PI_PROD_GRP_CD prdGrpCode, PI_SLT_ID itemSlot

					ChargebackBO cbkBO = new ChargebackBO();
					for (int i = 0; i < itemValidatorDetails.size(); i++) {
						cbkBO = (ChargebackBO) itemValidatorDetails.get(i);
						validate.add(cbkBO.getItemPack());
						validate.add(cbkBO.getItemSize());
						validate.add(cbkBO.getItemDesc());
						validate.add(cbkBO.getItemUpc());
						String prdCode = cbkBO.getPrdGrpCode();
						if (cbkBO.getPrdGrpCode().length() == 1)
							prdCode = "00" + prdCode;
						else if (cbkBO.getPrdGrpCode().length() == 2)
							prdCode = "0" + prdCode;

						validate.add(prdCode);
						validate.add(cbkBO.getItemSlot());
					}
				}

			} catch (DataAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return ResponseEntity.ok(validate);
	}

	/**
	 * validate REGION/SUBFUNDS
	 * 
	 * @param chargebackCreateForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = "/validateSubFunds", method = { RequestMethod.GET,
			RequestMethod.POST }, consumes = "application/json", params = { "action=validateSubFund" })
	public @ResponseBody ResponseEntity<?> processAJAXRequestforSubFund(@RequestParam("region") String region,
			@RequestParam("vendor") String vendor, @RequestParam("division") String division) {

		List validate = new ArrayList();
		if (region != null && vendor != null) {
			Integer reg = Integer.parseInt(region);
			System.out.println("------reg----"+reg);
			String regionVal = reg.toString();
			Map<String, String> m = new HashMap<>();

			m.put("region", regionVal);
			m.put("vendorId", vendor);
			m.put("division", division);

			// VALIDATE FROM DATABASE
			List<ChargebackBO> subfundValidationResult = new ArrayList<ChargebackBO>();
			try {
				if (division.equals("")) {
					subfundValidationResult = chargebackCreateDelegate.validateRegionWithoutDivision(m);
					if (subfundValidationResult.size() > 0) {
						ChargebackBO cbkBO = new ChargebackBO();
						for (int i = 0; i < subfundValidationResult.size(); i++) {
							cbkBO = (ChargebackBO) subfundValidationResult.get(i);

							String subFund = cbkBO.getSubFundNumber();
							if (cbkBO.getSubFundNumber().length() == 1)
								subFund = "00" + subFund;
							else if (cbkBO.getSubFundNumber().length() == 2)
								subFund = "0" + subFund;
							System.out
									.println("----validateRegionWithoutDivision--cbkBO.getSubFundNumber()--" + subFund);
							validate.add(subFund);
						}
					}
				} else if (!("").equals(division) && division != null) {
					subfundValidationResult = chargebackCreateDelegate.validateRegionWithDivision(m);
					if (subfundValidationResult.size() > 0) {
						ChargebackBO cbkBO = new ChargebackBO();
						for (int i = 0; i < subfundValidationResult.size(); i++) {
							cbkBO = (ChargebackBO) subfundValidationResult.get(i);
							String subFund = cbkBO.getSubFundNumber();
							System.out.println("----validateRegionWithDivision--cbkBO.getSubFundNumber().length()--"
									+ cbkBO.getSubFundNumber().length());
							if (cbkBO.getSubFundNumber().length() == 1)
								subFund = "00" + subFund;
							else if (cbkBO.getSubFundNumber().length() == 2)
								subFund = "0" + subFund;
							System.out.println("----validateRegionWithDivision--cbkBO.getSubFundNumber()--" + subFund);
							validate.add(subFund);
						}
					}
				}
				// System.out.println("validate------"+validate.get(0));

			} catch (DataAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return ResponseEntity.ok(validate);

	}

	/**
	 * validate Invoice Number
	 * 
	 * @param chargebackCreateForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = "/validateInvoiceNumber", method = { RequestMethod.GET,
			RequestMethod.POST }, consumes = "application/json", params = { "action=validateInvoice" })
	public @ResponseBody ResponseEntity<?> processAJAXRequestValidateInvoice(@RequestParam("invoice") String invoice,
			@RequestParam("location") String location) {

		boolean validate = false;
		if (invoice != null && location != null) {
			// VALIDATE FROM DATABASE
			ResultList availableInvoiceNumber;
			try {
				availableInvoiceNumber = chargebackSearchDelegate.getAvailableInvoiceNumber(invoice, location);
				if (availableInvoiceNumber.getList().size() > 0) {
					validate = true;
				}

			} catch (DataAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return ResponseEntity.ok(validate);

	}

	@RequestMapping(value = "/generatedInvoice", method = { RequestMethod.GET,
			RequestMethod.POST }, consumes = "application/json", params = { "action=generatedInvoiceNumber" })
	public @ResponseBody ResponseEntity<?> processAJAXRequestforGeneratedInvoice(@RequestParam("locNo") String locNo,
			String creatorId, String typeSel, ChargebackCreateForm chargebackCreateForm) throws DataAccessException {

		log.debug("--location number in ajax--" + locNo);
		log.debug("-- creatorId--" + creatorId);

		List validate = new ArrayList();
		if (locNo != null) {

			// VALIDATE FROM DATABASE

			chargebackCreateForm.setLocationNumber(locNo);
			chargebackCreateForm.setCreatorId(creatorId);

			if (locNo != null) {
				HashMap m = new HashMap();
				String location = locNo.substring(0, 2);
				m.put("location", location);
				m.put("userId", creatorId);
				ResultList locationValidatorResult = chargebackSearchDelegate.locationNumberValidator(m);
				System.out.println("---in generateInvoice-locationValidatorResult.getList().size()---"
						+ locationValidatorResult.getList().size());
				System.out.println("---typeSel---" + typeSel);
				if (locationValidatorResult.getList().size() > 0) {

					generateAndSetNextInvoice(chargebackCreateForm, chargebackSearchDelegate);
					validate.add(0, chargebackCreateForm.getInvoiceNumber());
					validate.add(1, chargebackCreateForm.getNextInvoiceNumber());
					validate.add(2, chargebackCreateForm.getInsertType());
				}
			}
		}
		return ResponseEntity.ok(validate);
	}

	@RequestMapping(value = "/generatedVendor", method = { RequestMethod.GET,
			RequestMethod.POST }, consumes = "application/json", params = { "action=generatedVendorAddress" })
	public @ResponseBody ResponseEntity<?> processAJAXRequestforGeneratedVendor(@RequestParam("vendor") String vendor,
			ChargebackCreateForm chargebackCreateForm) throws DataAccessException {

		System.out.println("-vendor id in ajax--" + vendor);
		List validate = new ArrayList();
		List vendorValidatorResult = null;
		
			if (!vendor.isEmpty() && vendor != null) {

				String removeLeadingZeroVendorId = StringFunctions.removeLeadingZeroIfNumber(vendor);
				System.out.println("--removeLeadingZeroVendorId---"+removeLeadingZeroVendorId);
				String spaceFillLeftVendorId = StringFunctions.spaceFillLeft(vendor,9,true);
				System.out.println("----VENDOR  SEARCH---spaceFillLeftVendorId---"+spaceFillLeftVendorId);
				String vendorName="";
				vendorValidatorResult = chargebackSearchDelegate.doVendorIdSearch(removeLeadingZeroVendorId, spaceFillLeftVendorId, vendorName);
				
				
				
				
				//ResultList vendorValidatorResult = chargebackSearchDelegate.vendorNumberValidator(vendorId);
				if (vendorValidatorResult.size() > 0) {
					System.out.println("---in generatedVendor-vendorValidatorResult.getList().size()---"
							+ vendorValidatorResult.size());
					// Get the vendor informaton
					VendorBO vendorInfo = (VendorBO)vendorValidatorResult.get(0);
					//vendorInfo = chargebackSearchDelegate.getVendorInfoByVendorId(vendorId);
					if (vendorInfo != null) {
						chargebackCreateForm.populateFormFromObjectVendor(chargebackCreateForm, vendorInfo);
						// System.out.println("-vendor address inside
						// ajax--"+chargebackCreateForm.getVendorAddress());
					}
							
					validate.add(0, chargebackCreateForm.getVendorAddress());
					validate.add(1, chargebackCreateForm.getVendorName());
					
				}
			}
		
		System.out.println("-vendor address ajax--" + chargebackCreateForm.getVendorAddress());
		return ResponseEntity.ok(validate);
	}

	/**
	 * validate Invoice Number
	 * 
	 * @param chargebackCreateForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = "/validateInvoiceNumberRepay", method = { RequestMethod.GET,
			RequestMethod.POST }, consumes = "application/json", params = { "action=validateInvoiceRepay" })
	public @ResponseBody ResponseEntity<?> processAJAXRequestRepay(@RequestParam("invoice") String invoice,
			@RequestParam("location") String location) {
//  String invoiceNumer=12345C
		List validate = new ArrayList();
		String nextInvoiceValidation = "C";
		String finalInvoice = "";

		boolean flag = true;
		if (invoice != null) {
			// VALIDATE FROM DATABASE
			ResultList availableInvoiceNumber;
			try {
				finalInvoice = invoice + nextInvoiceValidation;
				do {
					availableInvoiceNumber = chargebackSearchDelegate.getAvailableInvoiceNumber(finalInvoice, location);
					System.out.println("----availableInvoiceNumber----" + availableInvoiceNumber);
					if (availableInvoiceNumber != null && availableInvoiceNumber.getList().size() > 0) {
						finalInvoice = finalInvoice + nextInvoiceValidation; // 12345CC
						System.out.println("--if--finalInvoice----" + finalInvoice);
					} else {
						flag = false;
						System.out.println("--else--finalInvoice----" + finalInvoice);
					}

				} while (flag);

				validate.add(0, finalInvoice);
			} catch (DataAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return ResponseEntity.ok(validate);
	}

	/**
	 * 
	 * @param string
	 * @param idNamePattern
	 * @return
	 */

	private boolean validateSpecialCharacters(String string, String idNamePattern) {
		Pattern pattern = Pattern.compile(idNamePattern);

		Matcher matcher = pattern.matcher(string);

		boolean patternFlag = false;

		if (!matcher.matches()) {

			patternFlag = true;
		}

		return patternFlag;
	}

}