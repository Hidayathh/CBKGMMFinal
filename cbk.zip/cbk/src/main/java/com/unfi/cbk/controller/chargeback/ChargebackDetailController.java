package com.unfi.cbk.controller.chargeback;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.VendorBO;
import com.unfi.cbk.controller.PageAccessResolver;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.forms.ChargebackSearchForm;
import com.unfi.cbk.forms.ChargebackUpdateForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.util.StringFunctions;

/**
 * The GetResultsAction class is the struts action called when retrieving the
 * search results. The action simply determines the user type and forwards the
 * request to a secondary struts action specific to the user type.
 * <p>
 * This is to accommodate the struts Validator. Since all three versions of the
 * search form use the same ActionForm, the different validations that need to
 * be done specific to the type of form used are accomplished by having the
 * validator use the actions to determine which rules to use.<br>
 * This action, then, makes the user type transparent to the user by always
 * having the same action called when searching, regardless of user type.
 *
 * @author vpil001
 * @since 1.0
 */
@Controller("getCbkAvailableAction_chargeback")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ChargebackDetailController {// extends Action {
	static Logger log = Logger.getLogger(ChargebackSearchResultsController.class);
	@Autowired
	private ChargebackSearchDelegate chargebackSearchDelegate;

	public ChargebackDetailController(ChargebackSearchDelegate chargebackSearchDelegate) {
		this.chargebackSearchDelegate = chargebackSearchDelegate;
	}

	@Autowired
	ActionMessages messages;
	@Autowired
	Environment env;
	@Autowired
	ActionMessages errors;
	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	@RequestMapping(value = "/getChargebackDetails", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView details(@ModelAttribute("chargebackUpdateForm") ChargebackUpdateForm chargebackUpdateForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK DETAIL-  *****");
		chargebackUpdateForm.setFormParameterMap(request);
		boolean exceptionOccurred = false;
		String invoiceNumber = null;
		String vendorId = null;
		List<ChargebackBO> fileNames = null;
		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");
		boolean isEditable = false;
		String editableInvoiceStatus = null;
		String maxStepForInvoice = null;
		String typeId = null;
		String roleIdNextApprover = null;
		String stepNumber = null;
		String originalApprover = null;
		String ca = null;
		String src = null;
		try {

			if (request.getParameter("invoiceNbr") != null) {
				invoiceNumber = request.getParameter("invoiceNbr");
			}

			if (request.getParameter("vendorId") != null) {
				vendorId = request.getParameter("vendorId");
			}

			if (request.getParameter("approver") != null) {
				originalApprover = request.getParameter("approver");
			}
			
			
			chargebackUpdateForm.setOriginalApprover(originalApprover);
			chargebackUpdateForm.setMaxStepForInvoice(chargebackSearchDelegate.getMaxStepNumberForInvoice(invoiceNumber));

			String locationNumber = request.getParameter("locationNumber");
			Map<String, Comparable> updateParametersFromForm = chargebackUpdateForm.getMap();
			updateParametersFromForm.put("locationNumber", locationNumber);
			updateParametersFromForm.put("vendorId", vendorId);
			updateParametersFromForm.put("invoiceNumber", invoiceNumber);
			updateParametersFromForm.put("user", SmUserId);
			

			if (request.getParameter("ca") != null) {
				ca = request.getParameter("ca");
			}
			updateParametersFromForm.put("ca", ca);
			System.out.println("--------ca-----"+ca);
			
			System.out.println("---details()-----src-----"+request.getParameter("src"));
			if (request.getParameter("src") != null) {
				updateParametersFromForm.put("src", request.getParameter("src"));
				src = request.getParameter("src");
			}
			
			chargebackUpdateForm.setSrc(src);

			// Get the ChargebackType list
			List<ChargebackBO> chargebackTypes = chargebackSearchDelegate.getChargebackTypes();
			chargebackUpdateForm.setChargebackTypes(chargebackTypes);

			// Get the Reasons list
			List<ChargebackBO> reasons = chargebackSearchDelegate.getReasons();
			chargebackUpdateForm.setReasons(reasons);

			// Get the Product group list
			List<ChargebackBO> productGroup = chargebackSearchDelegate.getProductGroup();
			chargebackUpdateForm.setProductGroups(productGroup);
			// Get the vendor informaton
			/*
			 * ChargebackBO vendorInfo =
			 * chargebackSearchDelegate.getChargebackVendor(updateParametersFromForm); if
			 * (vendorInfo != null) {
			 * chargebackUpdateForm.populateFormFromObjectVendor(chargebackUpdateForm,
			 * vendorInfo); }
			 */
			
			List vendorValidatorResult = null;
			if (!vendorId.isEmpty() && vendorId != null) {

				String removeLeadingZeroVendorId = StringFunctions.removeLeadingZeroIfNumber(vendorId);
				System.out.println("--removeLeadingZeroVendorId---"+removeLeadingZeroVendorId);
				String spaceFillLeftVendorId = StringFunctions.spaceFillLeft(vendorId,9,true);
				System.out.println("----VENDOR  SEARCH---spaceFillLeftVendorId---"+spaceFillLeftVendorId);
				String vendorName="";
				 vendorValidatorResult = chargebackSearchDelegate.doVendorIdSearch(removeLeadingZeroVendorId, spaceFillLeftVendorId, vendorName);
				
				//ResultList vendorValidatorResult = chargebackSearchDelegate.vendorNumberValidator(vendorId);
				if (vendorValidatorResult.size() > 0) {
					System.out.println("---in generatedVendor-vendorValidatorResult.getList().size()---"
							+ vendorValidatorResult.size());
					// Get the vendor informaton
					VendorBO vendorInfo = (VendorBO)vendorValidatorResult.get(0);
					//vendorInfo = chargebackSearchDelegate.getVendorInfoByVendorId(vendorId);
					if (vendorInfo != null) {
						chargebackUpdateForm.populateFormFromObjectVendor(chargebackUpdateForm, vendorInfo);
						// System.out.println("-vendor address inside
						// ajax--"+chargebackCreateForm.getVendorAddress());
					}
							
					//validate.add(0, chargebackCreateForm.getVendorAddress());
					//validate.add(1, chargebackCreateForm.getVendorName());
					
				}
			}
			
			
			ChargebackBO cbkBo = chargebackSearchDelegate.getChargebackDetailInfo(updateParametersFromForm);
			chargebackUpdateForm.populateFormFromObject(cbkBo);
			updateParametersFromForm.put("locationNumber", cbkBo.getLocationNumber());
			// Get the search results based on the parameters in the form
			ResultList searchResults = chargebackSearchDelegate.getCbkDetTableInfo(updateParametersFromForm);
			// Populate the 'searchResults' property in the ActionForm
			// chargebackUpdateForm.setDetailResults(searchResults.getList());
			chargebackUpdateForm.setGlItems(searchResults.getList());
			// Get the search results based on the parameters in the form
			ResultList distibutionResults = chargebackSearchDelegate
					.getChargebackDistribution(updateParametersFromForm);
			chargebackUpdateForm.setSlItems(distibutionResults.getList());

			stepNumber = chargebackSearchDelegate.getMinStepNumberWithInvoiceAmount(invoiceNumber,
					cbkBo.getLocationNumber(), cbkBo.getTypeId().toString());

			chargebackUpdateForm.setStepNumber(stepNumber);


			// showing approval history
			ResultList approvalHistory = chargebackSearchDelegate.getApprovalHistory(invoiceNumber);

			chargebackUpdateForm.setApprovalHistoryList(approvalHistory.getList());

			// Attachement code

			fileNames = chargebackSearchDelegate.getAttachmentName(chargebackUpdateForm.getInvoiceNumber());
			for (ChargebackBO fileName : fileNames) {

				chargebackUpdateForm.setAttachmentName(String.valueOf(fileName.getAttachmentName()));
				chargebackUpdateForm.setAttachmentType(fileName.getAttachmentType());
			}
			
			editableInvoiceStatus = chargebackSearchDelegate.getInvoiceEditableStatus(invoiceNumber);

			// Check the eligibilit of approver
			if (SmUserId != null && cbkBo.getTypeId() != null) {
				roleIdNextApprover = chargebackSearchDelegate.getRoleIdForNextApprover(invoiceNumber,
						cbkBo.getTypeId().toString(), cbkBo.getLocationNumber(), SmUserId);
				log.debug("role id of next approver" + roleIdNextApprover);
			}
			
			if(!(editableInvoiceStatus != null)) {
				chargebackUpdateForm.setNotAnApprover("notAnApprover");
				log.debug("******User is not an approver*******");
			}else
			if ((cbkBo.getApprover() != null && !cbkBo.getApprover().equals(SmUserId) && roleIdNextApprover == null )) {
				chargebackUpdateForm.setNotAnApprover("notAnApprover");
				log.debug("******User is not an approver*******");
			} else {
				chargebackUpdateForm.setNotAnApprover("");

				log.debug("******User is approver*******");
			}

			// Check the eligiblity of edit option

			// Get the user roles based on decide he is admin or not
			String adminUser = chargebackSearchDelegate.getAdminUser(SmUserId, "-5");

			// Get approval status
			ResultList approverStatusResults = chargebackSearchDelegate.getChargebackApprovalStatus(invoiceNumber,
					SmUserId);
			List approverStatusList = (List) approverStatusResults.getList();// DELETE IT
			ChargebackBO cbkApproverStatusBO = new ChargebackBO();
			// DELETE IT
			for (int i = 0; i < approverStatusList.size(); i++) {
				cbkApproverStatusBO = (ChargebackBO) approverStatusList.get(i);
			}

			boolean isApproved;

			if (approverStatusList.size() == 0) {
				// not received any approval as of now
				isApproved = false;

			} else {
				// has at least one approval
				isApproved = true;

			}


			// Role ID -1 is admin
			if (adminUser != null) {
				isEditable = true;
				log.debug("--********Admin Editable*******--");
			}
			// Creator of the Chargeback
			else if (cbkBo.getCreatorId().equals(SmUserId)) {

				if (isApproved) {
					isEditable = false;
					log.debug("--********Creator not Editable*******--" + cbkBo.getCreatorId()
							+ " default user id" + SmUserId);
				} else {
					isEditable = true;
					log.debug("--********Creator Editable*******--");
				}

			} // Approver of the Chargeback
			else if (cbkBo.getApprover() != null && cbkBo.getApprover().equals(SmUserId)) {
				isEditable = true;
				log.debug("--********Approver Editable*******--");
			} //Another user has same role logged in user 
			else if (roleIdNextApprover != null) {
				isEditable = true;
				log.debug("--******User has same role******--");
	
			}else {
				isEditable = false;
				log.debug("--********others not Editable*******--");
			}
			
			
			
			

			if (!(isEditable && editableInvoiceStatus != null)) {
				chargebackUpdateForm.setNotEditable("notEditable");
			} else {
				chargebackUpdateForm.setNotEditable("");
			}

		} catch (Exception e) {
			exceptionOccurred = true;
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
		}

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess() && !exceptionOccurred) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKDETAILSACTIONS.get(Constants.ACTION_SUCCESS));
			request.setAttribute("actionMessages", messages);
			request.setAttribute("chargebackUpdateForm", chargebackUpdateForm);
			// return mapping.findForward("success");
			return mav;
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKDETAILSACTIONS.get("other"));
		// return mapping.findForward("other");
		request.setAttribute("actionMessages", messages);
		request.setAttribute("chargebackUpdateForm", chargebackUpdateForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackDetailsPrint", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView chargebackDetailsPrint(
			@ModelAttribute("chargebackUpdateForm") ChargebackUpdateForm chargebackUpdateForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK PRINT-  *****");
		chargebackUpdateForm.setFormParameterMap(request);
		boolean exceptionOccurred = false;
		String invoiceNumber = null;
		String vendorId = null;
		
		try {

			if (request.getParameter("invoiceNbr") != null) {
				invoiceNumber = request.getParameter("invoiceNbr");
			}

			if (request.getParameter("vendorId") != null) {
				vendorId = request.getParameter("vendorId");
			}

			String locationNumber = request.getParameter("locationNumber");
			Map<String, Comparable> updateParametersFromForm = chargebackUpdateForm.getMap();
			updateParametersFromForm.put("locationNumber", locationNumber);
			updateParametersFromForm.put("vendorId", vendorId);
			updateParametersFromForm.put("invoiceNumber", invoiceNumber);

			// Get the ChargebackType list
			//List<ChargebackBO> chargebackTypes = chargebackSearchDelegate.getChargebackTypes();
			//chargebackUpdateForm.setChargebackTypes(chargebackTypes);
			
			// Get the Reasons list
			//List<ChargebackBO> reasons = chargebackSearchDelegate.getReasons();
			//chargebackUpdateForm.setReasons(reasons);

			// Get the Product group list
			//List<ChargebackBO> productGroup = chargebackSearchDelegate.getProductGroup();
			//chargebackUpdateForm.setProductGroups(productGroup);

			// Get the vendor informaton
			/*
			 * ChargebackBO vendorInfo =
			 * chargebackSearchDelegate.getChargebackVendor(updateParametersFromForm); if
			 * (vendorInfo != null) {
			 * chargebackUpdateForm.populateFormFromObjectVendor(chargebackUpdateForm,
			 * vendorInfo); }
			 */
			List vendorValidatorResult = null;
			if (!vendorId.isEmpty() && vendorId != null) {

				String removeLeadingZeroVendorId = StringFunctions.removeLeadingZeroIfNumber(vendorId);
				System.out.println("--removeLeadingZeroVendorId---"+removeLeadingZeroVendorId);
				String spaceFillLeftVendorId = StringFunctions.spaceFillLeft(vendorId,9,true);
				System.out.println("----VENDOR  SEARCH---spaceFillLeftVendorId---"+spaceFillLeftVendorId);
				String vendorName="";
				 vendorValidatorResult = chargebackSearchDelegate.doVendorIdSearch(removeLeadingZeroVendorId, spaceFillLeftVendorId, vendorName);
				
				//ResultList vendorValidatorResult = chargebackSearchDelegate.vendorNumberValidator(vendorId);
				if (vendorValidatorResult.size() > 0) {
					System.out.println("---in generatedVendor-vendorValidatorResult.getList().size()---"
							+ vendorValidatorResult.size());
					// Get the vendor informaton
					VendorBO vendorInfo = (VendorBO)vendorValidatorResult.get(0);
					//vendorInfo = chargebackSearchDelegate.getVendorInfoByVendorId(vendorId);
					if (vendorInfo != null) {
						chargebackUpdateForm.populateFormFromObjectVendor(chargebackUpdateForm, vendorInfo);
						// System.out.println("-vendor address inside
						// ajax--"+chargebackCreateForm.getVendorAddress());
					}
							
					//validate.add(0, chargebackCreateForm.getVendorAddress());
					//validate.add(1, chargebackCreateForm.getVendorName());
					
				}
			}
			ChargebackBO cbkBo = chargebackSearchDelegate.getChargebackDetailInfo(updateParametersFromForm);
			chargebackUpdateForm.populateFormFromObject(cbkBo);
			updateParametersFromForm.put("locationNumber", cbkBo.getLocationNumber());
			// Get the search results based on the parameters in the form
			ResultList searchResults = chargebackSearchDelegate.getCbkDetTable(updateParametersFromForm);
			// Populate the 'searchResults' property in the ActionForm
			// chargebackUpdateForm.setDetailResults(searchResults.getList());
			chargebackUpdateForm.setGlItems(searchResults.getList());
			// Get the search results based on the parameters in the form
			ResultList distibutionResults = chargebackSearchDelegate
					.getChargebackDistribution(updateParametersFromForm);
			chargebackUpdateForm.setSlItems(distibutionResults.getList());

			ResultList approvalHistory = chargebackSearchDelegate.getApprovalHistory(invoiceNumber);
			chargebackUpdateForm.setApprovalHistoryList(approvalHistory.getList());

		} catch (Exception e) {
			exceptionOccurred = true;
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
		}

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess() && !exceptionOccurred) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKDETAILSPRINT.get(Constants.ACTION_SUCCESS));
			request.setAttribute("chargebackUpdateForm", chargebackUpdateForm);
			request.setAttribute("actionMessages", messages);
			// return mapping.findForward("success");
			return mav;
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKDETAILSPRINT.get("other"));
		// return mapping.findForward("other");
		request.setAttribute("actionMessages", messages);
		request.setAttribute("chargebackUpdateForm", chargebackUpdateForm);
		return mav;

	}

	@RequestMapping(value = "/downloadAttachment", method = { RequestMethod.GET, RequestMethod.POST })
	public ResponseEntity<Resource> downloadFile(HttpServletRequest request) throws IOException {
		ChargebackBO chargebackBO = new ChargebackBO();
		String attachmentName = null;
		String invoiceNumber = null;
		String contentType = null;
		ChargebackBO bytes = null;
		InputStreamResource resource = null;
		if (request.getParameter("invoiceNbr") != null) {
			invoiceNumber = request.getParameter("invoiceNbr");
		}
		if (request.getParameter("attachmentName") != null) {
			attachmentName = request.getParameter("attachmentName");
		}

		chargebackBO.setInvoiceNumber(invoiceNumber);
		try {
			bytes = chargebackSearchDelegate.findByAttachmentName(chargebackBO);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		if (bytes != null) {
			byte[] fileData = bytes.getFileData();
			resource = new InputStreamResource(new ByteArrayInputStream(fileData));
		}

		if (contentType == null) {
			contentType = "application/octet-stream";
		}
		return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + attachmentName + "\"")
				.body(resource);

	}

	/**
	 * 
	 * @param chargebackSearchForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = "/approveChargebackDetail", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=approveDetail" })
	public ModelAndView approveDetail(@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		chargebackSearchForm.setFormParameterMap(request);
		ModelAndView mav = new ModelAndView();
		log.debug("***** SELECTED CHARGEBACKS APPROVE *****");

		try {
			String invoiceNumber = request.getParameter("invoiceNumber");
			String locationNumber = request.getParameter("locationNumber");
			String originalApprover = request.getParameter("originalApprover");

			HttpSession session = request.getSession();
			String SmUserId = (String) session.getAttribute("SmUserId");

			String maxStepNumber = null;
			// String currentStepNumber = null;
			String stepNumber = null;
			String netAmount = null;
			String actionType = null;
			String typeId = null;
			boolean reachedMaxStep = true;
			String approved = "false";
			String approver = null;

			String creatorId = null;
			if (request.getParameter("creatorId") != null) {
				creatorId = request.getParameter("creatorId");
			}
			String app = null;
			if (request.getParameter("app") != null) {
				app = request.getParameter("app");

			}

	
			if (request.getParameter("typeId") != null) {
				typeId = request.getParameter("typeId");
			}

			if (request.getParameter("netAmount") != null) {
				netAmount = request.getParameter("netAmount");
			}

			stepNumber = chargebackSearchDelegate.getMinStepNumberWithInvoiceAmount(invoiceNumber, locationNumber,
					typeId);

			maxStepNumber = chargebackSearchDelegate.getMaxStepNumberWithInvoiceAmount(invoiceNumber, locationNumber,
					typeId);

			if (request.getParameter("originalApprover") != null) {
				approver = request.getParameter("originalApprover");
			}

			
			if (maxStepNumber != null && maxStepNumber.equals(stepNumber)) {
				log.debug("---Reached Max StepNumber-----");
				// reachedMaxStep=true;
				approved = "true";
				chargebackSearchForm.setApproved(approved);
				approver = "No further approvals";
			}

			ChargebackBO cbkBo = new ChargebackBO();
			// Call the common method to return the list
			cbkBo.setInvoiceNumber(invoiceNumber);
			cbkBo.setLocationNumber(locationNumber);
			cbkBo.setApproverId(SmUserId);
			cbkBo.setStepNumber(stepNumber);
			//cbkBo.setApprovalDate(new Date());
			cbkBo.setApprovalDate(DateFunctions.adjustCurrentDateByDaysNoFormat(0));

			cbkBo.setNextAproverId(approver);
			chargebackSearchDelegate.updateChargebackApprover(cbkBo);

			// Perform the APPROVE (INSERT)

			chargebackSearchDelegate.approveChargebacks(cbkBo);

			// AFTER APPROVE PULL THE AVAILABLE CHARGEBACKS

			Map<String, Comparable> searchParametersFromForm = chargebackSearchForm.getMap();
			searchParametersFromForm.put("userId", SmUserId);

			// Define the display parameters
			int maxRows = 20;
			chargebackSearchForm.setDisplayCount(maxRows);

			if (chargebackSearchForm.isShowAll()) {
				searchParametersFromForm.put("showAll", "true");
			} else {
				searchParametersFromForm.put("rowStart", new Integer(chargebackSearchForm.getCurrentRecord()));
				searchParametersFromForm.put("rowEnd",
						new Integer(chargebackSearchForm.getCurrentRecord() + maxRows - 1));
			}
			ResultList searchResults = chargebackSearchDelegate.getAvailableChargebacks(searchParametersFromForm);

			// Populate the 'searchResults' property in the ActionForm
			chargebackSearchForm.setSearchResults(searchResults.getList());
			chargebackSearchForm.setTotalRecords(searchResults.getTotalCount().intValue());
			// email code
			/*
			 * if (stepNumber.equals(maxStepNumber)){ CreateNewUserBO UserBODetails =
			 * chargebackSearchDelegate.getUserDetails(creatorId); // Send email only when
			 * user finally confirmed on the approver and notification if
			 * (UserBODetails.getUseremailId() != null) {
			 * UserBODetails.setUseremailId(TEST_EMAIL); //// need to remove this line when
			 * we are at actual environment. chargebackMailer.finalApproverSendEmail(cbkBo,
			 * UserBODetails.getUseremailId(), SmUserId); } } else if
			 * (!cbkBo.getNextApprover().equals("") && cbkBo.getNextApprover() != null) {
			 * CreateNewUserBO UserBODetails =
			 * chargebackSearchDelegate.getUserDetails(cbkBo.getNextApprover()); // Send
			 * email only when user finally confirmed on the approver and notification if
			 * (UserBODetails.getUseremailId() != null) {
			 * UserBODetails.setUseremailId(TEST_EMAIL); // need to remove this line when we
			 * are at actual environment. chargebackMailer.nextApproverSendEmail(cbkBo,
			 * UserBODetails.getUseremailId(), SmUserId);
			 * 
			 * } }
			 */

		} catch (Exception e) {
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKGETRESULTSACTION.get(Constants.ACTION_SUCCESS));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackSearchForm", chargebackSearchForm);
		return mav;

	}

	/**
	 * 
	 * @param chargebackSearchForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = "/denyChargebackDetail", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=denyDetail" })
	public ModelAndView denyDetail(@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		chargebackSearchForm.setFormParameterMap(request);
		ModelAndView mav = new ModelAndView();
		log.debug("***** SELECTED CHARGEBACKS DENY *****");
		String invoiceNumber = request.getParameter("invoiceNumber");
		String locationNumber = request.getParameter("locationNumber");
		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");

		try {
			String denyReason = null;
			if (request.getParameter("denyReason") != null) {
				denyReason = request.getParameter("denyReason");

			}

			ChargebackBO cbkBo = new ChargebackBO();
			// Call the common method to return the list
			cbkBo.setInvoiceNumber(invoiceNumber);
			cbkBo.setLocationNumber(locationNumber);
			//cbkBo.setInterInstr(denyReason);
			cbkBo.setNextAproverId(null);
			//cbkBo.setCancelled(-1);

			chargebackSearchDelegate.updateChargebackDenyReason(cbkBo);
	
			Map<String, Comparable> searchParametersFromForm = chargebackSearchForm.getMap();
			searchParametersFromForm.put("userId", SmUserId);

			// Define the display parameters
			int maxRows = 20;
			chargebackSearchForm.setDisplayCount(maxRows);

			if (chargebackSearchForm.isShowAll()) {
				searchParametersFromForm.put("showAll", "true");
			} else {
				searchParametersFromForm.put("rowStart", new Integer(chargebackSearchForm.getCurrentRecord()));
				searchParametersFromForm.put("rowEnd",
						new Integer(chargebackSearchForm.getCurrentRecord() + maxRows - 1));
			}
			ResultList searchResults = chargebackSearchDelegate.getAvailableChargebacks(searchParametersFromForm);

			// Populate the 'searchResults' property in the ActionForm
			chargebackSearchForm.setSearchResults(searchResults.getList());
			chargebackSearchForm.setTotalRecords(searchResults.getTotalCount().intValue());

		} catch (Exception e) {
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
		}
		// Finish with
		mav.setViewName(ActionUrlMapping.CHARGEBACKGETRESULTSACTION.get(Constants.ACTION_SUCCESS));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackSearchForm", chargebackSearchForm);
		return mav;
	}
	
	
	
	
}