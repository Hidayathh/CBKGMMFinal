package com.unfi.cbk.controller.chargeback;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.ChargebackExportBO;
import com.unfi.cbk.bo.ExportResultsBO;
import com.unfi.cbk.controller.PageAccessResolver;
import com.unfi.cbk.delegates.ChargebackExportDelegate;
import com.unfi.cbk.forms.ChargebackExportForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.DateFunctions;

@Controller("chargebackExport")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ChargebackExportController {
	static Logger log = Logger.getLogger(ChargebackExportController.class);
	@Autowired
	ActionMessages errors;

	@Autowired
	ActionMessages messages;
	@Autowired
	Environment env;

	@Autowired
	private ChargebackExportDelegate chargebackExportDelegate;

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	@RequestMapping(value = "/chargebackExport", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=exportHome" })
	public ModelAndView exportHome(@ModelAttribute("chargebackExportForm") ChargebackExportForm chargebackExportForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackExportForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackExportForm.reset(request);
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKEXPORTACTION.get("exportMenu"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackExportForm", chargebackExportForm);

		return mav;

	}

	@RequestMapping(value = "/chargebackAuditLog", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=chargeAuditLog" })
	public ModelAndView chargeAuditLog(
			@ModelAttribute("chargebackExportForm") ChargebackExportForm chargebackExportForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackExportForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackExportForm.reset(request);
		}

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKEXPORTACTION.get("byAuditLog"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackExportForm", chargebackExportForm);

		return mav;
	}

	@RequestMapping(value = "/chargebackExport", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=auditDetails" })
	public ModelAndView auditDetails(@ModelAttribute("chargebackExportForm") ChargebackExportForm chargebackExportForm,
			HttpServletRequest request) throws Exception {
		String dateCriteria = request.getParameter("dateCriteria");
		ModelAndView mav = new ModelAndView();

		if (request.getParameter("isformreset") != null) {
			chargebackExportForm.reset(request);
		}

		Map searchParametersFrom = chargebackExportForm.getMap();
		
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}
		//For ID Selector.
		String date = DateFunctions.chargebackDateConversion(chargebackExportForm.getDate());
		List expIdList = chargebackExportDelegate.getExportId(date);
		if(expIdList.size()>0) {
			ExportResultsBO result=(ExportResultsBO)expIdList.get(0);
		
		searchParametersFrom.put("exportedId", result.getExportedId());
		}

		// Location
		searchParametersFrom.put("location", chargebackExportForm.getLocation());
		if (chargebackExportForm.getLocation().equals("2")) {
			searchParametersFrom.put("locationNumber", chargebackExportForm.getLocationNumber());
		}

		// Date
		String dt = chargebackExportForm.getDate();
		if (messages.isEmpty()) {

			searchParametersFrom.put("dateCriteria", dateCriteria);
			if (chargebackExportForm.getDate() != null && !chargebackExportForm.getDate().isEmpty()) {

				searchParametersFrom.put("date",
						DateFunctions.chargebackDateConversion(chargebackExportForm.getDate()));
			}
		}

		ResultList searchResults = chargebackExportDelegate.getTypeAmount(searchParametersFrom);
		chargebackExportForm.setSearchResults(searchResults.getList());

		// Calculation of amount
		Double total = 0.00;
		DecimalFormat df = new DecimalFormat("0.00");
		if (searchResults.getList().size() > 0) {
			List l1 = (List) searchResults.getList();
			ExportResultsBO bo = new ExportResultsBO();

			for (int i = 0; i < l1.size(); i++) {
				bo = (ExportResultsBO) l1.get(i);

				total = total + Double.parseDouble(bo.getExportedAmount());
			}
		}
		chargebackExportForm.setTotalExports(df.format(total).toString());
		chargebackExportForm.setDate(dt);

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKEXPORTACTION.get("byAuditLog"));
			// request.setAttribute("actionMessages", messages);
			request.setAttribute("chargebackExportForm", chargebackExportForm);
		}

		request.setAttribute("actionMessages", errors);
		return mav;

	}

	@RequestMapping(value = "/previewExport", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=previewExportResults" })
	public ModelAndView previewExportResults(
			@ModelAttribute("chargebackExportForm") ChargebackExportForm chargebackExportForm,
			HttpServletRequest request) throws Exception {

		ModelAndView mav = new ModelAndView();

		if (request.getParameter("isformreset") != null) {
			chargebackExportForm.reset(request);
		}

		Map searchParametersFrom = chargebackExportForm.getMap();
		int maxRows = 20;
		chargebackExportForm.setDisplayCount(maxRows);

		if (chargebackExportForm.isShowAll()) {
			searchParametersFrom.put("showAll", "true");
		} else {
			searchParametersFrom.put("rowStart", new Integer(chargebackExportForm.getCurrentRecord()));
			searchParametersFrom.put("rowEnd", new Integer(chargebackExportForm.getCurrentRecord() + maxRows - 1));
		}
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		ResultList searchResults = chargebackExportDelegate.previewExportResults();
		chargebackExportForm.setSearchResults(searchResults.getList());
		// chargebackExportForm.setTotalRecords(searchResults.getTotalCount().intValue());

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKEXPORTACTION.get("previewExportResult"));
			request.setAttribute("chargebackExportForm", chargebackExportForm);
		}
		request.setAttribute("actionMessages", errors);
		return mav;

	}

	@RequestMapping(value = "/updateDueDate", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=updateDueDateResults" })
	public ModelAndView updateDueDateResults(
			@ModelAttribute("chargebackExportForm") ChargebackExportForm chargebackExportForm,
			HttpServletRequest request) throws Exception {

		ModelAndView mav = new ModelAndView();

		if (request.getParameter("isformreset") != null) {
			chargebackExportForm.reset(request);
		}

		Map searchParametersFrom = chargebackExportForm.getMap();
		int maxRows = 20;
		chargebackExportForm.setDisplayCount(maxRows);

		if (chargebackExportForm.isShowAll()) {
			searchParametersFrom.put("showAll", "true");
		} else {
			searchParametersFrom.put("rowStart", new Integer(chargebackExportForm.getCurrentRecord()));
			searchParametersFrom.put("rowEnd", new Integer(chargebackExportForm.getCurrentRecord() + maxRows - 1));
		}
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		ResultList searchResults = chargebackExportDelegate.updateDuedate();
		chargebackExportForm.setSearchResults(searchResults.getList());
		
		
		//update the due date in table
		List finalUpdatedList = searchResults.getList();
		
		
		for (int i = 0; i < finalUpdatedList.size(); i++) {
			ChargebackExportBO exportedBO = new ChargebackExportBO();
			exportedBO = (ChargebackExportBO) finalUpdatedList.get(i);
			ChargebackBO cbkBO = new ChargebackBO();
			cbkBO.setInvoiceNumber(exportedBO.getInvoiceNumber());
			cbkBO.setLastApprovalDate(exportedBO.getLastApprovalDate());
			cbkBO.setDaysToAdd(StringUtils.right(exportedBO.getUpdateDetailValue(), 4).trim());
			chargebackExportDelegate.updateChargebackDueDate(cbkBO);
		}

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKEXPORTACTION.get("updateDueDateResults"));
			request.setAttribute("chargebackExportForm", chargebackExportForm);
		}
		request.setAttribute("actionMessages", errors);
		return mav;

	}
	@RequestMapping(value = "/agedChargebackExport", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=agedChargebackReport" })
	public ModelAndView agedChargebackReport(
			@ModelAttribute("chargebackExportForm") ChargebackExportForm chargebackExportForm,
			HttpServletRequest request) throws Exception {

		ModelAndView mav = new ModelAndView();
		if (request.getParameter("isformreset") != null) {
			chargebackExportForm.reset(request);
		}
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("auditLog"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackExportForm", chargebackExportForm);

		return mav;

	}

	@RequestMapping(value = "/agedChargebackExportReport", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView execute(
			@ModelAttribute("chargebackExportForm") ChargebackExportForm chargebackExportForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
			if (request.getParameter("isformreset") != null) {
			chargebackExportForm.reset(request);
		}

		Map searchParametersFrom = chargebackExportForm.getMap();
		if (!errors.isEmpty()) {
			log.debug("FAILED"); // saveMessages(request, errors);
			errors.saveMessages(request);
		}
		
		int maxRows = 20;
		chargebackExportForm.setDisplayCount(maxRows);

		if (chargebackExportForm.isShowAll()) {
			searchParametersFrom.put("showAll", "true");
		} else {
			searchParametersFrom.put("rowStart", new Integer(chargebackExportForm.getCurrentRecord()));
			searchParametersFrom.put("rowEnd", new Integer(chargebackExportForm.getCurrentRecord() + maxRows - 1));
		}

		String dateCriteria = request.getParameter("dateCriteria");
		// Date
				String dt = chargebackExportForm.getDate();
				if (messages.isEmpty()) {

					searchParametersFrom.put("dateCriteria", dateCriteria);
					if (chargebackExportForm.getDate_a() != null && !chargebackExportForm.getDate_a().isEmpty() && chargebackExportForm.getDate_b() != null && !chargebackExportForm.getDate_b().isEmpty()) {

						searchParametersFrom.put("fromDate",
								DateFunctions.chargebackDateConversion(chargebackExportForm.getDate_a()));
						searchParametersFrom.put("toDate",
								DateFunctions.chargebackDateConversion(chargebackExportForm.getDate_b()));
						
						ResultList searchResults = chargebackExportDelegate.agedChargebackReportSearch(searchParametersFrom);
						chargebackExportForm.setSearchResults(searchResults.getList());
						
						
						//chargebackExportForm.setSearchResults(searchResults.getList());
						chargebackExportForm.setTotalRecords(searchResults.getTotalCount().intValue());
						
						// Calculation of amount
						List l1 = (List) searchResults.getList();
						ChargebackExportBO bo = new ChargebackExportBO();
						Double total = 0.00;
						String exporterName = null;
						for (int i = 0; i < l1.size(); i++) {
							bo = (ChargebackExportBO) l1.get(i);

							total = total + Double.parseDouble(bo.getExportedAmount());
							exporterName = bo.getExportedId();

						}

						chargebackExportForm.setTotalExportedAmount(total.toString());
						chargebackExportForm.setExporterName(exporterName);
					}
				}
		
		
		
				
	
		

		

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKEXPORTACTION.get("agedChargebackReport"));
			request.setAttribute("chargebackExportForm", chargebackExportForm);

		}

		request.setAttribute("actionMessages", errors);
		return mav;

	}

}
