package com.unfi.cbk.controller.chargeback;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.opencsv.CSVWriter;
import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.ChargebackInterfaceBO;
import com.unfi.cbk.bo.CreateNewUserBO;
import com.unfi.cbk.delegates.ChargebackManagerDelegate;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.email.ChargebackMailer;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.forms.ChargebackInterfaceForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.utilcore.ApplicationProperties;

@Controller("chargebackInterfaceController_chargeback")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ChargebackInterfaceController {
	static Logger log = Logger.getLogger(ChargebackInterfaceController.class);

	@Autowired
	ActionMessages errors;

	@Autowired
	ActionMessages messages;
	@Autowired
	Environment env;
	@Autowired
	private ChargebackSearchDelegate chargebackSearchDelegate;

	@Autowired
	private ChargebackManagerDelegate chargebackManagerDelegate;

	@Autowired
	private ChargebackMailer chargebackMailer;

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	private static String SUB_FUNDS_DIR_PATH = ApplicationProperties.getFundsMgntFolder();
	private static String SUB_FUNDS_BACKUP_DIR_PATH = ApplicationProperties.getFundsMgntBackUpFolder();
	private static String FUNDS_IMPORT_LOG = ApplicationProperties.getFundsImportLog();
	private static String NEXT_APPROVER = ApplicationProperties.getNextApprover();
	private static String TEST_EMAIL = ApplicationProperties.getDummyEMail();

	@RequestMapping(value = "/chargebackInterface", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=confirm" })
	public ModelAndView Confirm(
			@ModelAttribute("chargebackInterfaceForm") ChargebackInterfaceForm chargebackInterfaceForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKINTERFACEACTION.get("confirm"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackInterfaceForm", chargebackInterfaceForm);
		return mav;
	}

	@RequestMapping(value = "/chargebackInterface", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=read" })
	public ModelAndView Read(@ModelAttribute("chargebackInterfaceForm") ChargebackInterfaceForm chargebackInterfaceForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackInterfaceForm.setFormParameterMap(request);
		DateFormat dateFormatter = new SimpleDateFormat("yyyyMMddhhmmss");
		String currentDateTime = dateFormatter.format(new Date());
		boolean exceptionOccurred = false;

		String accNum = null;
		String companyCode = null;
		String location = null;
		String prod_code = null;
		String acct_unit = null;
		String invoiceNum = null;
		String referenceNum = null;
		String vendorId = null;
		Double itemTotalAmt = 0.00;
		Double distAmt = 0.00;
		List list = new ArrayList();
		Double distAmount = 0.00;
		int successCount = 0;
		int failCount = 0;
		int rowCount = 0;
		String nextInvoiceValidation = "I";
		boolean vendorValidate = false;
		boolean accountValidate = false;
		boolean inBalValidate = false;
		String fileName = null;
		try {
			File folder = new File(SUB_FUNDS_DIR_PATH);
			if (folder.exists()) {
				File[] listOfFiles = folder.listFiles();
				if (listOfFiles.length > 0) {
					for (int i = 0; i < listOfFiles.length; i++) {

						if (listOfFiles[i] != null) {
							fileName = listOfFiles[i].getName();
							list = Files.readAllLines(listOfFiles[i].toPath(), Charset.defaultCharset());
							ChargebackBO cbkBO = new ChargebackBO();
							ChargebackInterfaceBO intBO = new ChargebackInterfaceBO();
							for (int j = 0; j < list.size(); j++) {
								String[] eachRow = list.get(j).toString().split(",");
								if (!eachRow[0].isEmpty() && !eachRow[0].isBlank()) {
									rowCount = Integer.parseInt(eachRow[0].substring(0, 1).trim());
									if (rowCount == 1) {
										// substring = eachRow[0];
										intBO.setRecordType(eachRow[0].substring(0, 1).trim());
										referenceNum = eachRow[0].substring(2, 21).trim();
										cbkBO.setReferenceNumber(referenceNum);
										cbkBO.setLocationNumber(eachRow[0].substring(21, 26).trim());

										boolean flag = true;
										// Create Invoices
										// 99332954FI,99341622FI
										if (referenceNum != null) {
											ResultList availableInvoiceNumber;
											try {
												invoiceNum = referenceNum + nextInvoiceValidation;
												do {
													availableInvoiceNumber = chargebackSearchDelegate
															.getAvailableInvoiceNumber(invoiceNum,
																	cbkBO.getLocationNumber());
													if (availableInvoiceNumber != null
															&& availableInvoiceNumber.getList().size() > 0) {
														invoiceNum = invoiceNum + nextInvoiceValidation; // 12345CC
													} else {
														flag = false;
													}

												} while (flag);
												if (invoiceNum.length() < 16) {
													cbkBO.setInvoiceNumber(invoiceNum);
												} else {
													exceptionOccurred = true;
													messages.add("noRecords", "Reference Number :" + referenceNum
															+ " has breached Maximum limit to genrate Invoice Number :"
															+ invoiceNum + ".  ", null);
													mav.setViewName(
															ActionUrlMapping.CHARGEBACKINTERFACEACTION.get("other"));
													request.setAttribute("actionMessages", messages);
													request.setAttribute("chargebackInterfaceForm",
															chargebackInterfaceForm);
													return mav;
												}
											} catch (DataAccessException e) {
												exceptionOccurred = true;
												messages.add("noRecords", "Unable to retrieve Invoice NUmber.  ", null);
												mav.setViewName(
														ActionUrlMapping.CHARGEBACKINTERFACEACTION.get("other"));
												request.setAttribute("actionMessages", messages);
												request.setAttribute("chargebackInterfaceForm",
														chargebackInterfaceForm);
												return mav;
											}
										}
										cbkBO.setDueDate(
												DateFunctions.stringToDate(eachRow[0].substring(26, 34).trim()));
										cbkBO.setInvoiceDate(
												DateFunctions.stringToDate(eachRow[0].substring(26, 34).trim()));
										// cbkBO.setApprovalDate(DateFunctions.stringToDate(eachRow[0].substring(26,
										// 34).trim()));
										cbkBO.setApprovalDate(new Date());
										cbkBO.setTypeId(Integer.parseInt(eachRow[0].substring(43, 44).trim()));
										cbkBO.setCreatorId(eachRow[0].substring(44, 50).trim());
										cbkBO.setShortDesc(eachRow[0].substring(50, 154).trim());
										cbkBO.setReasonCode(eachRow[0].substring(154, 170).trim());
										vendorId = eachRow[0].substring(34, 43).trim();

										// vendorId = "8072637";
										if (vendorId != null) {
											// VALIDATE FROM DATABASE
											try {
												String vendorStatus = chargebackSearchDelegate
														.getValidVendorNumber(vendorId);
												if (vendorStatus != null) {
													vendorValidate = true;
													cbkBO.setVendorId(vendorId);
												}

											} catch (DataAccessException e) {
												e.printStackTrace();
												log.error(e);
											}
										}
									} else if (rowCount == 2) {

										// cbkBO.setReferenceNumber(eachRow[0].substring(2, 21).trim());
										cbkBO.setLineNumber(Integer.parseInt(eachRow[0].substring(21, 23).trim()));
										cbkBO.setItemNumber(Integer.parseInt(eachRow[0].substring(23, 30).trim()));
										cbkBO.setItemPack(Integer.parseInt(eachRow[0].substring(30, 33).trim()));
										cbkBO.setItemSize(eachRow[0].substring(33, 40).trim());
										cbkBO.setItemDesc(eachRow[0].substring(40, 71).trim());
										cbkBO.setItemUpc(eachRow[0].substring(71, 83).trim());
										cbkBO.setItemQuantity(Integer.parseInt(eachRow[0].substring(90, 94).trim()));

										String leftNum = eachRow[0].substring(95, 100).trim();
										String rightNum = eachRow[0].substring(100, 102).trim();
										String itemPrice = leftNum + "." + rightNum;
										cbkBO.setItemPrice(Double.parseDouble(itemPrice));
										cbkBO.setItemPriceFormat(cbkBO.getItemPrice().toString());

										cbkBO.setPrdGrpCode(eachRow[0].substring(102, 105).trim());
										cbkBO.setProductCode(eachRow[0].substring(102, 105).trim());
										cbkBO.setDcNumber(eachRow[0].substring(105, 108).trim());
										// cbkBO.setRegion(eachRow[0].substring(105, 108).trim());
									} else if (rowCount == 3) {
										intBO.setRecordType(eachRow[0].substring(0, 1).trim());

										// cbkBO.setReferenceNumber(eachRow[0].substring(2, 21).trim());
										cbkBO.setCompanyCode(eachRow[0].substring(21, 25).trim());
										cbkBO.setLocationNumber(eachRow[0].substring(25, 30).trim());
										cbkBO.setDistLocNumber(eachRow[0].substring(25, 30).trim());
										cbkBO.setAttachmentType("0");
										cbkBO.setProductGrp(eachRow[0].substring(30, 33).trim());
										// cbkBO.setAccountNumber(eachRow[0].substring(33, 39).trim());
										// cbkBO.setDistributionAmt(Double.parseDouble(eachRow[0].substring(39,
										// 49).trim()));

										// AMOUNT VALIDATE

										itemTotalAmt = cbkBO.getItemPrice() * cbkBO.getItemQuantity();
										String leftNum = eachRow[0].substring(40, 47).trim();
										String rightNum = eachRow[0].substring(47, 49).trim();
										distAmt = Double.parseDouble(leftNum + "." + rightNum);
								
										if (distAmt.equals(itemTotalAmt)) {
											inBalValidate = true;
											cbkBO.setDistributionAmt(distAmt);
										}
										accNum = eachRow[0].substring(33, 39).trim();
										companyCode = eachRow[0].substring(21, 25).trim();
										location = eachRow[0].substring(25, 30).trim();

										prod_code = eachRow[0].substring(30, 33).trim();
										acct_unit = 0 + location + prod_code;
										if (accNum != null) {
											// VALIDATE FROM DATABASE
											try {
												String accountStatus = chargebackSearchDelegate
														.getValidAccountNumber(companyCode, accNum, acct_unit);
												if (accountStatus != null) {
													accountValidate = true;
													cbkBO.setAccountNumber(eachRow[0].substring(33, 39).trim());
												}

											} catch (DataAccessException e) {
												e.printStackTrace();
											}
										}
									} else if (rowCount == 4) {
										cbkBO.setStepNumber(eachRow[0].substring(21, 23).trim());
										cbkBO.setApproverId(eachRow[0].substring(23).trim());

										if (vendorValidate == true && accountValidate == true && inBalValidate == true) {
											chargebackSearchDelegate.updateChargeback(cbkBO, true);
											chargebackSearchDelegate.createCbkItemSingleRecord(cbkBO);
											chargebackSearchDelegate.createCbkDistributionSingleRecord(cbkBO);
											// CREATOR APPROVE HIMSELF
											double amountFromInv = cbkBO.getDistributionAmt();
											String maxAmount = chargebackSearchDelegate
													.getValidMaxAmount(cbkBO.getCreatorId(), cbkBO.getTypeId());
											double amount = Double.parseDouble(maxAmount);

											HashMap<Object, Object> map = new HashMap<>();
											map.put("routeId", 1);
											map.put("amountFromInv", amountFromInv);
											map.put("stepNumber", cbkBO.getStepNumber());
											String amountFloor = chargebackSearchDelegate.getAmountFloor(map);
											if (amountFromInv < amount) {
												cbkBO.setNextAproverId(NEXT_APPROVER.trim());
												chargebackSearchDelegate.updateChargebackFundsNextApprover(cbkBO);
											} else if (amountFloor != null) {
												CreateNewUserBO UserBODetails = chargebackSearchDelegate
														.getUserDetails(cbkBO.getCreatorId());
												if (UserBODetails != null && UserBODetails.getUseremailId() != null) {
													chargebackMailer.fundsMgntEmail(cbkBO, TEST_EMAIL);
												}
											} else {
												cbkBO.setNextAproverId(NEXT_APPROVER.trim());
												chargebackSearchDelegate.updateChargebackFundsNextApprover(cbkBO);
											}
											chargebackSearchDelegate.approveChargebacks(cbkBO);
											distAmount = distAmount + cbkBO.getDistributionAmt();
											successCount++;
											vendorValidate = false;
											accountValidate = false;
											inBalValidate = false;
										} else if (vendorValidate == false || accountValidate == false || inBalValidate == false) {
											String invoiceNumber = cbkBO.getInvoiceNumber();

											List<String[]> csvData = createCsvDataSpecial(vendorValidate,
													accountValidate, inBalValidate, invoiceNumber);
											int index = fileName.lastIndexOf('.');
											try (CSVWriter writer = new CSVWriter(new FileWriter(FUNDS_IMPORT_LOG
													+ fileName.substring(0, index) + "-" + currentDateTime + ".csv"))) {
												writer.writeAll(csvData);
											}
											failCount++;
											vendorValidate = false;
											accountValidate = false;
											inBalValidate = false;
										}
									} // 4th ROW
								} // each row validation in a file
							} // end of for loop for each file
						}
						// file move code
						try {
							if (fileName != null) {
								File file = new File(SUB_FUNDS_DIR_PATH + fileName);
								int index = fileName.lastIndexOf('.');
								if (index > 0) {
									String extension = fileName.substring(index + 1);
									fileName = fileName.substring(0, index) + "-" + currentDateTime + "." + extension;
									if (file.renameTo(new File(SUB_FUNDS_BACKUP_DIR_PATH + fileName))) {
										// if file copied successfully then delete the original file
										file.delete();
										log.debug("*****File moved successfully *****");
									}

								}
							}
						} catch (Exception e) {
							e.printStackTrace();
							log.error("Error in file Move:" + e);
						}

					} // for
				} else {
					exceptionOccurred = true;
					messages.add("empty folder", "No files are there in source folder to import.  ", null);
				}
			} else {
				exceptionOccurred = true;
				messages.add("Incorrect folder", "Specified Directory Location Is In-Correct.  ", null);
			}
			// delete method for aged files.
			deleteFilesOlderThanNdays(1, FUNDS_IMPORT_LOG, SUB_FUNDS_BACKUP_DIR_PATH);

			chargebackInterfaceForm.setDistributionAmt(Double.parseDouble(String.format("%.2f", distAmount)));
			chargebackInterfaceForm.setSuccessCount(successCount);
			chargebackInterfaceForm.setFailCount(failCount);
		} catch (IOException e) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKINTERFACEACTION.get("other"));
			request.setAttribute("actionMessages", messages);
			request.setAttribute("chargebackInterfaceForm", chargebackInterfaceForm);
			return mav;
		}
		log.debug("*****CHARGEBACK INTERFACE *****Read()");

		if (exceptionOccurred) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKINTERFACEACTION.get("other"));
			request.setAttribute("actionMessages", messages);
			request.setAttribute("chargebackInterfaceForm", chargebackInterfaceForm);
			return mav;
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKINTERFACEACTION.get("success"));
		request.setAttribute("actionMessages", messages);
		request.setAttribute("chargebackInterfaceForm", chargebackInterfaceForm);
		return mav;

	}

	private static List<String[]> createCsvDataSpecial(boolean vendor, boolean account, boolean finalDistAmount,
			String invoiceNumber) {

		String[] header = { "VendorValid", "AccountValid", "BalanceValid", "InvoiceNumber" };
		String[] record1 = { Boolean.toString(vendor), Boolean.toString(account), Boolean.toString(finalDistAmount),
				invoiceNumber };

		List<String[]> list = new ArrayList<>();
		list.add(header);
		list.add(record1);

		return list;
	}

	public static void deleteFilesOlderThanNdays(int daysBack, String importLogDir, String backupDir) {

		File logDir = new File(importLogDir);
		File bakupDir = new File(backupDir);
		if (logDir.exists()) {

			File[] listFiles = logDir.listFiles();
			long purgeTime = System.currentTimeMillis() - (daysBack * 24 * 60 * 60 * 1000);
			for (File listFile : listFiles) {
				if (listFile.lastModified() < purgeTime) {
					if (!listFile.delete()) {
						log.debug("*****Unable to delete file: *****" + listFile);
					}
				}
			}
		}
		if (bakupDir.exists()) {

			File[] listFiles = bakupDir.listFiles();
			long purgeTime = System.currentTimeMillis() - (daysBack * 24 * 60 * 60 * 1000);
			for (File listFile : listFiles) {
				if (listFile.lastModified() < purgeTime) {
					if (!listFile.delete()) {
						System.err.println("Unable to delete file: " + listFile);
					}
				}
			}
		}
	}
}
