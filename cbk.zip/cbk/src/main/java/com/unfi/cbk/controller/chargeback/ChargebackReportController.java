package com.unfi.cbk.controller.chargeback;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.bo.ChargebackReportBO;
import com.unfi.cbk.delegates.ChargebackReportDelegate;
import com.unfi.cbk.forms.ChargebackReportForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.DateFunctions;

@Controller("chargebackReport_Chargeback")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ChargebackReportController {
	static Logger log = Logger.getLogger(ChargebackReportController.class);
	@Autowired
	ActionMessages errors;

	@Autowired
	ActionMessages messages;
	@Autowired
	Environment env;

	@Autowired
	private ChargebackReportDelegate chargebackReportDelegate;

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	@RequestMapping(value = "/chargebackReport", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=chargeReport" })
	public ModelAndView chargeReport(@ModelAttribute("chargebackReportForm") ChargebackReportForm chargebackReportForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackReportForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackReportForm.reset(request);
		}

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKREPORTACTION.get("byChargeReport"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackReportForm", chargebackReportForm);
		request.setAttribute("reasons", chargebackReportDelegate.getReasonCode());

		return mav;
	}

	@RequestMapping(value = "/cbkReportResults", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView execute(@ModelAttribute("chargebackReportForm") ChargebackReportForm chargebackReportForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		chargebackReportForm.setFormParameterMap(request);
		ServletOutputStream out = null;

		try {
			log.debug("***** CHARGEBACK REPORT- RESULTS ****execute*");
			// HttpSession session=request.getSession();

			Map<String, Comparable> searchParametersFromForm = chargebackReportForm.getMap();

			boolean exceptionOccurred = false;
			Map searchParametersFrom = chargebackReportForm.getMap();

			String fromDate = null;
			String toDate = null;

			if (request.getParameter("datefrom") != null) {
				fromDate = request.getParameter("datefrom");
			}
			if (request.getParameter("dateTo") != null) {
				toDate = request.getParameter("dateTo");
			}

			System.out.println("---from:::" + fromDate + "to date" + toDate);

			searchParametersFrom.put("showAll", "true");
			searchParametersFrom.put("fromDate", DateFunctions.chargebackDateConversion(fromDate));
			searchParametersFrom.put("toDate", DateFunctions.chargebackDateConversion(toDate));

			// userId - Originator
			if (chargebackReportForm.getVendorId() != null && !chargebackReportForm.getVendorId().isEmpty()) {
				searchParametersFrom.put("vendorId", chargebackReportForm.getVendorId());
			}
			// searchParametersFrom.put("vendorId", chargebackReportForm.getVendorId());
			if (chargebackReportForm.getReasonCode() != null && !chargebackReportForm.getReasonCode().isEmpty()) {
				searchParametersFrom.put("reasonCode", chargebackReportForm.getReasonCode());
			}
			System.out.println("Date-----" + DateFunctions.chargebackDateConversion(fromDate));
			System.out.println("Date Two----" + DateFunctions.chargebackDateConversion(toDate));
			System.out.println("VendorId-----" + chargebackReportForm.getVendorId());
			System.out.println("Reason-----" + chargebackReportForm.getReasonCode());

			List searchResults = chargebackReportDelegate.getChargebackReportList(searchParametersFrom);
			//chargebackReportForm.setSearchResults(searchResults.getList());

			System.out.println("----AFTER QEURY---in EXPORT---searchResults--size----"
					+ searchResults.size());

			//List ResulstList = (List) chargebackReportForm.getSearchResults();

			//createExcel(searchResults);
			out = response.getOutputStream();
			
			response.setHeader("Content-disposition", "attachment; filename=CBK_Report.xlsx");
			response.setContentType("text/comma-separated-values");
			response.setHeader("Pragma", "public");
			response.setHeader("Cache-control", "must-revalidate");
			
			//input date: "2020-12-21 00:00:00.0"
		    DateFormat inf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.S");
			DateFormat of = new SimpleDateFormat ("dd/MM/yyyy");
			Date date = new Date();
			
			 XSSFWorkbook wb = new XSSFWorkbook(); 
			 	System.out.println("----createEexcel LIst Size-------"+searchResults.size());
			 	
			 	 //FileOutputStream outputStream = new FileOutputStream("C:/Users/vpil001.UNFI/Documents/CBK_Report.xlsx");
			 	
			 	 final String[] sheetNames= { "Coded_Chbk", "Return_Merch","Repay_Coded_Cbk","Repay_Prompt_Cb","Funds_Mgmt","Repay_Funds", 
			 			 "Imported_Chbk","VendorCompRepay","VendorComp"};
			 	// Create a blank sheet with sheet name 'My First ExcelSheet
			 	/*1	Coded Chbk
			 	2	Return Merch
			 	3	Repay Coded Cbk
			 	4	Repay Prompt Cb
			 	5	Funds Mgmt
			 	6	Repay Funds
			 	7	Imported Chbk
			 	9	VendorCompRepay
			 	8	VendorComp
			 	*/
			 	 
			 	XSSFCellStyle titleStyle = wb.createCellStyle();
			 	  titleStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			 	 XSSFCellStyle titleStyle1 = wb.createCellStyle();
			 	 titleStyle1.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
			 	 // titleStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			 	 // Font titleFont = wb.createFont();
			 	  //titleFont.setFontName("simsun");
			 	  //titleFont.setBoldweight((short) 3);
			 	  //titleFont.setColor(IndexedColors.BLACK.getIndex());
			 	  
			 	 // Row titleRow = sheet.createRow(rowIndex);
			 	  // titleRow.setHeightInPoints(25);
			 	 
			 	 final String[] header= { "DOCUMENT", "LOCATION","DOCUMENT_DATE","VENDOR_NUMBER","VENDOR_NAME","TYPE_DESCRIPTION","CREATOR", 
			 			 "BRIEF_DESCRIPTION","REASON_CODE","PRODUCT_GROUP_CODE","AMOUNT","DIST_LOCATION_NUMBER","PROD/STATE","ACCOUNT_NUMBER","DISTRIBUTION_AMOUNT","DUE_DATE"};

			 	for(int i= 0; i< searchResults.size(); i++)
			 	{
			 	 List  list = (List)searchResults.get(i);
			 	 
			 	 XSSFSheet sheet = wb.createSheet(sheetNames[i]); 
			 	 Row rowhead = sheet.createRow((short)0);
			 	 int colIndex = 0;
			 	 
			 	 for (String field : header) {
				 	    Cell cell = rowhead.createCell(colIndex);
				 	    cell.setCellValue(field);
				 	    cell.setCellStyle(titleStyle);
				 	    colIndex++;
				 	    
			 	 }
			 	 /*
			 	 rowhead.createCell((short)0).setCellValue("DOCUMENT");
			 	 rowhead.createCell((short)1).setCellValue("LOCATION");
			 	 rowhead.createCell((short)2).setCellValue("DOCUMENT_DATE");
			 	 rowhead.createCell((short)3).setCellValue("VENDOR_NUMBER");
			 	 rowhead.createCell((short)4).setCellValue("VENDOR_NAME");
			 	 rowhead.createCell((short)5).setCellValue("TYPE_DESCRIPTION");
			 	 rowhead.createCell((short)6).setCellValue("CREATOR");
			 	 rowhead.createCell((short)7).setCellValue("BRIEF_DESCRIPTION");
			 	 rowhead.createCell((short)8).setCellValue("REASON_CODE");
			 	 rowhead.createCell((short)9).setCellValue("PRODUCT_GROUP_CODE");
			 	 rowhead.createCell((short)10).setCellValue("AMOUNT");
			 	 rowhead.createCell((short)11).setCellValue("DIST_LOCATION_NUMBER");
			 	 rowhead.createCell((short)12).setCellValue("PROD/STATE");
			 	 rowhead.createCell((short)13).setCellValue("ACCOUNT_NUMBER");
			 	 rowhead.createCell((short)14).setCellValue("DISTRIBUTION_AMOUNT");
			 	 rowhead.createCell((short)15).setCellValue("DUE_DATE");
*/
			 	 ChargebackReportBO reportBO = null;
			 	 
			 	 int index=1;
			 	 
		 			for(int j=0; j< list.size(); j++) {
						
		 				reportBO = (ChargebackReportBO) list.get(j);
		 				
		 				
		 				// Row rowhead = sheet.createRow((short)0);
		 				
		 				
		 				 String s0 = (String)reportBO.getDocumentNumber();
		 				 String s1 = (String)reportBO.getLocationNumber();
		 				 String s2 = (String)reportBO.getDocumentDate();
		 				 String s3 = (String)reportBO.getVendorNumber();
		 				 String s4 = (String)reportBO.getVendorName();
		 				 String s5 = (String)reportBO.getTypeDescription();
		 				 String s6 = (String)reportBO.getCreator();
		 				 String s7 = (String)reportBO.getBriefDecription();
		 				 String s8 = (String)reportBO.getReasonCode();
		 				 String s9 = (String)reportBO.getProductGroupCode();
		 				 String s10 = (String)reportBO.getAmount();
		 				 String s11 = (String)reportBO.getDistLocNumber();
		 				 String s12 = (String)reportBO.getState();
		 				 String s13 = (String)reportBO.getAccNumber();
		 				 String s14 = (String)reportBO.getDistributionAmount();
		 				 String s15 = (String)reportBO.getDueDate();
		 				 
		 				 
		 				Row row = sheet.createRow((short)index);
		 				// int colIndexRows = 0;
					 	/* 
					 	 for (int k=0; k<=15; k++ ) {
						 	    Cell cell = row.createCell(colIndexRows);
						 	    //Object String;
						 	    String amt =null; 
						 	    String dt = null;
								if(k == 2) {
									//dt = "s"+k;
						 	    	  date = inf.parse(s2);
						 	    	  cell.setCellValue(of.format(date));
						 	    }
						 	    else if(k == 10 || k == 14) {
						 	    	 amt ="s"+k;
						 	    	 if(amt == null)
					 					 cell.setCellValue("0.00");
						 	    	 else
						 	    		 cell.setCellValue("$  "+amt);
						 	    	cell.setCellStyle(titleStyle1);
						 	    }	
					 	 		else if(k == 15) {
					 	 				//dt = "s"+k;
						 	    	  date = inf.parse(s15);
						 	    	  cell.setCellValue(of.format(date));
						 	    }
					 	 		else
					 	 		{
					 	 			String str = "s"+k;
					 	 			cell.setCellValue("s"+k);
					 	 		}
						 	   colIndexRows++;
						 	    
					 	 }
		 				*/
		 				 row.createCell((short)0).setCellValue(s0);
		 				 row.createCell((short)1).setCellValue(s1);
		 				  date = inf.parse(s2); //date: "2020-12-21 00:00:00.0"
		 				 row.createCell((short)2).setCellValue(of.format(date));
		 				 row.createCell((short)3).setCellValue(s3);
		 				 row.createCell((short)4).setCellValue(s4);
		 				 row.createCell((short)5).setCellValue(s5);
		 				 row.createCell((short)6).setCellValue(s6);
		 				 row.createCell((short)7).setCellValue(s7);
		 				 row.createCell((short)8).setCellValue(s8);
		 				 row.createCell((short)9).setCellValue(s9);
		 				 if(s10 == null)
		 				 {
		 					 s10 = "0.00";
		 				 }
		 				 row.createCell((short)10).setCellValue("$  "+s10);
		 				
		 				 row.createCell((short)11).setCellValue(s11);
		 				 row.createCell((short)12).setCellValue(s12);
		 				 row.createCell((short)13).setCellValue(s13);
		 				 if(s14 == null)
		 				 {
		 					 s14 = "0.00";
		 				 }
		 				 row.createCell((short)14).setCellValue("$  "+s14);
		 				  date = inf.parse(s15);
		 				 row.createCell((short)15).setCellValue(of.format(date));
		 				
		 				 index++;
		 				 
		 			}
			}
		 			
		 			wb.write(out);
		            out.flush();
			
			

		} catch (Exception e) {
			e.printStackTrace();
			// Report the error using the appropriate name and ID.
			log.error("Exception in execute():" + e);
		} finally {
			if (out != null) {
				out.close();
			}
			response.flushBuffer();
		}

		// No mappings or forwards for this action...
		return null;
	}

	private void createExcel(List<ChargebackReportBO> list) throws IOException  {
		
		 XSSFWorkbook wb = new XSSFWorkbook(); 
		 	System.out.println("----createEexcel LIst Size-------"+list.size());
		 	
		 	 FileOutputStream outputStream = new FileOutputStream("C:/Users/vpil001.UNFI/Documents/CBK_Report.xlsx");
		 	
		 	 // final String[] header= { "DOCUMENT", "Location","DOCUMENT_DATE","VENDOR_NUMBER","VENDOR_NAME","TYPE_DESCRIPTION",  "CREATOR","BRIEF_DESCRIPTION",
				  		//"REASON_CODE", "PRODUCT_GROUP_CODE","AMOUNT","DIST_LOCATION_NUMBAR","STATE","ACCOUNT_NUMBER" ,"DISTRIBUTION_AMOUNT","DUE_DATE"};
		 	// Create a blank sheet with sheet name 'My First ExcelSheet
		 	 XSSFSheet sheet = wb.createSheet("sheet1"); 
		 	 Row rowhead = sheet.createRow((short)0);
		 	 rowhead.createCell((short)0).setCellValue("DOCUMENT");
		 	 rowhead.createCell((short)1).setCellValue("LOCATION");
		 	ChargebackReportBO reportBO = null;
		 	 
		 	 int index=1;
		 	 
	 			for(int i=0; i< list.size(); i++) {
					 
					
	 				reportBO = (ChargebackReportBO) list.get(i);
	 				Row row = sheet.createRow((short)index);
	 				
	 				 String s1 = (String)reportBO.getDocumentNumber();
	 				 String s2 = (String)reportBO.getLocationNumber();
	 				 row.createCell((short)0).setCellValue(Integer.parseInt(s1));
	 				 row.createCell((short)1).setCellValue(s2);
	 				 index++;
	 				 
	 			}
	 			
	 			wb.write(outputStream);
	            outputStream.flush();
	            
	            
				/*
				 * String cnt="application/vnd.ms-excel"; cnt=cnt.replaceAll("\\n\\r","");
				 * response.setContentType(cnt); response.setHeader("Content-Disposition",
				 * "attachment; filename="+filenamea); //hwb.write(os); wb.write(outputStream);
				 * wb.flush();
				 */
	 				 
	 				 
					// Create an array object and initialize the data. 
		 			//int rowNum = 0;
		 			//Row row = sheet.createRow(0);
		 			
					/*
					 * for(int j = 0; j < header.length; j++) { Cell cell = row.createCell(j);
					 * cell.setCellValue(header[j]);
					 * 
					 * }
					 */

		 			/*List rL = list.get(i);
				    for (int k = 0; k < 1; k++) {
				    	int colCount=0;
						ChargebackReportBO reportBO = (ChargebackReportBO) rL.getList().get(k);
		 		      
		 		        // create new row
		 		        row = sheet.createRow(++rowNum);
		 		    //  for(int l=0;l<15;l++) {
		 		        
		 		      Cell cell = row.createCell(++colCount); 
		 		      
		 		      
		 		      cell.setCellValue(reportBO.getDocumentNumber());
		 			  cell.setCellValue(reportBO.getLocationNumber());
		 			  cell.setCellValue(reportBO.getVendorNumber());
		 			  cell.setCellValue(reportBO.getVendorName());
		 			  cell.setCellValue(reportBO.getTypeDescription());
		 			  cell.setCellValue(reportBO.getCreator());
		 			  cell.setCellValue(reportBO.getBriefDecription());
		 			  cell.setCellValue(reportBO.getReasonCode());
		 			  cell.setCellValue(reportBO.getProductGroupCode());
		 			  cell.setCellValue(reportBO.getAmount());
		 			  cell.setCellValue(reportBO.getDistLocNumber());
		 			  cell.setCellValue(reportBO.getState());
		 			  cell.setCellValue(reportBO.getAccNumber()); 
		 			  cell.setCellValue(reportBO.getDistributionAmount());
		 			  cell.setCellValue(reportBO.getDueDate());
		 		      }*/
		 		      // Writing sheet data
				   // }
						
				    
						
						// FileOutputStream outputStream = new FileOutputStream("C://System//test.xlsx");
						
						// wb.write(outputStream);
						// wb.wri
						 
						/*
						 * if(!outputStream.canRead()){ outputStream.setReadable(true); }
						 */
						 
		// Create rows and iterate them. 
		   
		  
		    
		// Create cells in each row, iterate them and set the cell value. 
		    
		 			//}
	}

}
