package com.unfi.cbk.controller.chargeback;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackExportBO;
import com.unfi.cbk.delegates.ChargebackExportDelegate;
import com.unfi.cbk.forms.ChargebackExportForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.util.ESAPIUtil;
import com.unfi.cbk.util.StringFunctions;

/**
 * The ExportUserSearchResultsAction class is the struts action called to export
 * the search results to a CSV file. The action makes the call to the database
 * for the results, parses through each row, and creates a CSV with one line per
 * result row.
 * <p>
 * The resulting text file is sent to the requesing page as the response with
 * the appropriate mime type and response headers set.
 *
 * @author vpil001
 * @since 1.0
 */
@Controller("exportingAgedChargebackAction_chargeback")
public class ExportingAgedChargebackController {// extends Action {
	static Logger log = Logger.getLogger(ExportingAgedChargebackController.class);

	
	
	@Autowired
	private ChargebackExportDelegate chargebackExportDelegate;

	public ExportingAgedChargebackController(ChargebackExportDelegate chargebackExportDelegate) {
		this.chargebackExportDelegate = chargebackExportDelegate;
	}

	@Autowired
	ActionMessages error;
	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	public ExportingAgedChargebackController() {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.Action#execute(org.apache.struts.action.
	 * ActionMapping, org.apache.struts.action.ActionForm,
	 * javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@RequestMapping(value = "/agedChargebackResults", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView execute(@ModelAttribute("chargebackExportForm") ChargebackExportForm chargebackExportForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		chargebackExportForm.setFormParameterMap(request);
		ServletOutputStream out = null;

		try {
			log.debug("*****AGED CHARGEBACK REPORT- EXPORT *****");

			Map<String, Comparable> searchParametersFromForm = chargebackExportForm.getMap();


			log.debug("***** AGED CHARGEBACK REPORT *****");
			Map searchParametersFrom = chargebackExportForm.getMap();
			
			String fromDate = null;
			String toDate = null;

			if (request.getParameter("datefrom") != null) {
				fromDate = request.getParameter("datefrom");
			}
			if (request.getParameter("dateTo") != null) {
				toDate = request.getParameter("dateTo");
			}


			searchParametersFrom.put("showAll", "true");
			

				searchParametersFrom.put("fromDate",
						DateFunctions.chargebackDateConversion(fromDate));
				searchParametersFrom.put("toDate",
						DateFunctions.chargebackDateConversion(toDate));
			
			
			ResultList searchResults = chargebackExportDelegate.agedChargebackReportSearch(searchParametersFrom);
			chargebackExportForm.setSearchResults(searchResults.getList());
			

			List ResulstList = (List) chargebackExportForm.getSearchResults();

			out = response.getOutputStream();

			// The response headers must be set in the following order, or else IE
			// won't handle things properly.
			// response.setHeader("Content-length", ""+file.getFile().length());
			response.setHeader("Content-disposition", "attachment; filename=AgedChargebackReport.csv");
			response.setContentType("text/comma-separated-values");
			response.setHeader("Pragma", "public");
			response.setHeader("Cache-control", "must-revalidate");

			// out.println("Document Results (" + searchCriteriaSummary + ")");
			out.println(",,,,,,,AgedChargeback List  ");
			out.println(",,,,,Aged Chargeback List  pulled: " + DateFunctions.getTodayTime());
			/*
			 * if (!dateRangeUsed.equals("")) { out.println("Deduction extract date range: "
			 * + dateRangeUsed); }
			 */
			out.println();
			out.println(",Invoice,, Location,,Cbk Type,,Invoice Date,,vendor,,Creator,,Next Approver,, Amount");
			out.println("");
			for (int i = 0; i < ResulstList.size(); i++) {
				ChargebackExportBO exportBO = (ChargebackExportBO) ResulstList.get(i);

				// Put a '=' and quotes around the document number to avoid
				// Excel dropping any leading zeros in the value.
				out.print(",");
				out.print("=\"" + ESAPIUtil.encodeforXSS(StringFunctions.convertNull(exportBO.getInvoiceNumber())) + "\"");
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(exportBO.getLocationNumber())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(exportBO.getTypeName())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(exportBO.getInvoiceDateString())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(exportBO.getVendorId())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(exportBO.getOriginator())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(exportBO.getNextApprover())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(exportBO.getExportedAmount())));
				out.print(",,");
				
				out.print("\n");
			}

		} catch (Exception e) {
			e.printStackTrace();
			// Report the error using the appropriate name and ID.
			log.error("Exception in execute():" + e);
		} finally {
			if (out != null) {
				out.close();
			}
			response.flushBuffer();
		}

		// No mappings or forwards for this action...
		return null;
	}

}