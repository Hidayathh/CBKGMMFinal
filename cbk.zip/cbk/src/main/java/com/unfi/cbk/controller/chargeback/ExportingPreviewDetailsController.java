package com.unfi.cbk.controller.chargeback;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackExportBO;
import com.unfi.cbk.delegates.ChargebackExportDelegate;
import com.unfi.cbk.forms.ChargebackExportForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.util.ESAPIUtil;
import com.unfi.cbk.util.StringFunctions;

/**
 * The ExportUserSearchResultsAction class is the struts action called to export
 * the search results to a CSV file. The action makes the call to the database
 * for the results, parses through each row, and creates a CSV with one line per
 * result row.
 * <p>
 * The resulting text file is sent to the requesing page as the response with
 * the appropriate mime type and response headers set.
 *
 * @author vpil001
 * @since 1.0
 */
@Controller("exportingPreviewDetailsAction_chargeback")
public class ExportingPreviewDetailsController {// extends Action {
	static Logger log = Logger.getLogger(ExportingPreviewDetailsController.class);

	@Autowired
	private ChargebackExportDelegate chargebackExportDelegate;

	public ExportingPreviewDetailsController(ChargebackExportDelegate chargebackExportDelegate) {
		this.chargebackExportDelegate = chargebackExportDelegate;
	}

	@Autowired
	ActionMessages error;
	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	public ExportingPreviewDetailsController() {

	}

	@RequestMapping(value = "/exportPreviewResults", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView execute(@ModelAttribute("chargebackExportForm") ChargebackExportForm chargebackExportForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		chargebackExportForm.setFormParameterMap(request);
		ServletOutputStream out = null;

		try {

			Map<String, Comparable> searchParametersFromForm = chargebackExportForm.getMap();

			Map searchParametersFrom = chargebackExportForm.getMap();

			ResultList searchResults = chargebackExportDelegate.previewExportResults();
			chargebackExportForm.setSearchResults(searchResults.getList());

			List ResulstList = (List) chargebackExportForm.getSearchResults();

			out = response.getOutputStream();

			// The response headers must be set in the following order, or else IE
			// won't handle things properly.
			// response.setHeader("Content-length", ""+file.getFile().length());
			response.setHeader("Content-disposition", "attachment; filename=ChargebackExportPreviewResults.csv");
			response.setContentType("text/comma-separated-values");
			response.setHeader("Pragma", "public");
			response.setHeader("Cache-control", "must-revalidate");

			// out.println("Document Results (" + searchCriteriaSummary + ")");
			out.println(",,,Preview List  ");
			out.println(",Export Preview information  pulled: " + DateFunctions.getTodayTime());
			/*
			 * if (!dateRangeUsed.equals("")) { out.println("Deduction extract date range: "
			 * + dateRangeUsed); }
			 */
			out.println();
			out.println(",Invoice,, Location,, Amount");

			for (int i = 0; i < ResulstList.size(); i++) {
				ChargebackExportBO exportBO = (ChargebackExportBO) ResulstList.get(i);

				// Put a '=' and quotes around the document number to avoid
				// Excel dropping any leading zeros in the value.
				out.print(",");
				out.print("=\"" + ESAPIUtil.encodeforXSS(StringFunctions.convertNull(exportBO.getInvoiceNumber()))
						+ "\"");
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(exportBO.getLocationNumber())));
				out.print(",,");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(exportBO.getExportedAmount())));
				out.print(",");

				out.print("\n");
			}

		} catch (Exception e) {
			e.printStackTrace();
			// Report the error using the appropriate name and ID.
			log.error("Exception in execute():" + e);
		} finally {
			if (out != null) {
				out.close();
			}
			response.flushBuffer();
		}

		// No mappings or forwards for this action...
		return null;
	}

}