package com.unfi.cbk.controller.chargeback;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.delegates.ChargebackExportDelegate;
import com.unfi.cbk.forms.LawsonExportForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.DateFunctions;

@Controller("lawsonExportAction")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class LawsonExportController {
	static Logger log = Logger.getLogger(LawsonExportController.class);
	@Autowired
	ActionMessages errors;

	@Autowired
	ActionMessages messages;
	@Autowired
	Environment env;
	
	@Autowired
	private ChargebackExportDelegate chargebackExportDelegate;

	public LawsonExportController(ChargebackExportDelegate chargebackExportDelegate) {
		this.chargebackExportDelegate = chargebackExportDelegate;
	}


	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	@RequestMapping(value = "/lawsonExport", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=lawsonExportHome" })
	public ModelAndView lawsonExportHome(@ModelAttribute("lawsonExportForm") LawsonExportForm lawsonExportForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		System.out.println("-----You are at Start of the Lawson Export process-----------------");
		
		//need to get date from tblLastExport table
		Date lastExportedDate = null;
		boolean isExportFailed = false;
		
		lastExportedDate = chargebackExportDelegate.getLastExportedDate();
		
		
		  if (lastExportedDate !=null && new Date() != lastExportedDate){
		  		  lastExportedDate = new Date(); 
		  }
		 
			
		//Step 4: Clear all 16 the temporary export tables
		  
		  chargebackExportDelegate.deleteAllExportTables();
		  
		  
		  
		  
		
		/*  step 5: Load export tables
		 *  Now, we are loading the currently exporting data to the tables.
		 * failed = LoadExportTables("qryAppendType", "qryAppendTempReasons",
		 * "qryAppendAvailableExports", "qryAppendChargeback", "qryAppendDistribution",
		 * "qryAppendItem", "qryAppendApprovals", "qryAppendTempDistributions",
		 * "qryAppendTempDetailLawson", "qryAppendNotExportedLawson")
		 * 
		 * 
		 */
		  chargebackExportDelegate.loadLawsonExportTables();
		
		
		//step 6: if the export tables are not loaded then it will   terminate the exporting procedure.
		
		
		
		//step 7: If the export tables are loaded then the invoices are marked as exported.
		
		if(isExportFailed) {
			
			//UPDATE CBK_CHARGEBACK INNER JOIN tblTempNotExported ON (CBK_CHARGEBACK.INVOICE_NUMBER=tblTempNotExported.INVOICE_NUMBER) AND (CBK_CHARGEBACK.LOCATION_NUMBER=tblTempNotExported.LOCATION_NUMBER) SET CBK_CHARGEBACK.EXPORTED = -1;
			
		}
		
		//step 8: Now, whatever the marked invoices will send to "LawsonAP" from there  the invoices are  send to "FUNDS" and from here the invoices will be sent to "DAN".
		
		//Step 8a: Send To AP (Functionality):
		
		
		

		//Step 8b: Send to Funds (Functionality):
		
		
		
		
		
		
		//Step 8c: Send to Dan(Functionality):
		
		
		
		
		
		
		
		//step 9: If invoices are not sent to "AP" then in the CBK_CHARGEBACK table the exported field value gets updated to "mark the invoices as not exported".
		//db.Execute "qryUpdateNotExported" 
		//UPDATE CBK_CHARGEBACK INNER JOIN tblTempNotExported ON (CBK_CHARGEBACK.LOCATION_NUMBER=tblTempNotExported.LOCATION_NUMBER) AND (CBK_CHARGEBACK.INVOICE_NUMBER=tblTempNotExported.INVOICE_NUMBER) 
		//SET CBK_CHARGEBACK.EXPORTED = "mark the invoices as not exported";
		
		
		//step 10: If invoices are not sent to "FUNDS" then in the CBK_CHARGEBACK table the exported field value gets updated to "mark the invoices as not exported".
		//UPDATE CBK_CHARGEBACK INNER JOIN tblTempNotExported ON (CBK_CHARGEBACK.LOCATION_NUMBER=tblTempNotExported.LOCATION_NUMBER) AND (CBK_CHARGEBACK.INVOICE_NUMBER=tblTempNotExported.INVOICE_NUMBER) 
		//SET CBK_CHARGEBACK.EXPORTED = "mark the invoices as not exported";
		
		//step 11: If it not sent to "DAN" then it will show error message as "Export of files to 'Vendor Notification' failed.  Please contact support."
				
		

		
		

		
		

		mav.setViewName(ActionUrlMapping.CHARGEBACKEXPORTACTION.get("exportMenu"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackExportForm", lawsonExportForm);

		return mav;

	}


}
