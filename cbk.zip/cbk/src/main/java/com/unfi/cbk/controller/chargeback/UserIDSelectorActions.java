package com.unfi.cbk.controller.chargeback;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.dao.UserIDSelectorDao;
import com.unfi.cbk.forms.UserIDSelectorForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;

/**
 * The action method that will be called is automatically determined based upon
 * the value of the parameter (specified in struts-config.xml) that is passed
 * in.
 * <p>
 * The action method will then sets the user data in the request, sets any
 * values needed, and forwards to the appropriate action mapping.
 *
 * @author
 * @version 1.0
 */
@Controller
public class UserIDSelectorActions {
	static Logger log = Logger.getLogger(UserIDSelectorActions.class);
	private UserIDSelectorDao userIDSelectorDao;

	public UserIDSelectorActions(@Autowired UserIDSelectorDao dao) {
		this.userIDSelectorDao = dao;
	}

	@Autowired
	ActionMessages errors;

	/**
	 * The open() method displays the Vendor Selector pop up.
	 * 
	 * @param mapping  The ActionMapping used to select this instance
	 * @param form     The ActionForm bean for this request
	 * @param request  The HTTP request we are processing
	 * @param response The HTTP response we are creating
	 * @return an ActionForward instance describing where and how control should be
	 *         forwarded, or null if the response has already been completed.
	 * @throws Exception if an exception occurs
	 */
	@RequestMapping(value = "/userIDSelector", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=open" })

	public ModelAndView open(@ModelAttribute UserIDSelectorForm UserIDSelectorForm, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean exceptionOccurred = false;

		try {
			log.debug("***** USERID SELECTOR OPEN *****");

		} catch (Exception e) {
			// Determine the error, log it, and put an error message in ActionErrors
			exceptionOccurred = true;
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);

			// Only add the general error if no other errors are present
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			mav.setViewName(ActionUrlMapping.USERIDSELECTORACTIONS.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		request.setAttribute("actionMessages", errors);
		request.setAttribute("UserIDSelectorForm", UserIDSelectorForm);
		return mav;
	}

	/**
	 * The search() method get the values from the database.
	 * 
	 * @param mapping  The ActionMapping used to select this instance
	 * @param form     The ActionForm bean for this request
	 * @param request  The HTTP request we are processing
	 * @param response The HTTP response we are creating
	 * @return an ActionForward instance describing where and how control should be
	 *         forwarded, or null if the response has already been completed.
	 * @throws Exception if an exception occurs
	 */
	@RequestMapping(value = "/userIDSelector", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=search" })
	public ModelAndView search(@ModelAttribute UserIDSelectorForm userIDSelectorForm, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView mav = new ModelAndView();
		ActionMessages errors = new ActionMessages();

		boolean exceptionOccurred = false;

		try {
			log.debug("***** USER ID SELECTOR SEARCH *****");

			// Get the list of vendors and put them into the bean for the JSP page
			List searchResults = userIDSelectorDao.doUserIDSearch(userIDSelectorForm.getUserID(),
					userIDSelectorForm.getUserName());
			userIDSelectorForm.setSearchResults(searchResults);
			userIDSelectorForm.setResults(new Integer(searchResults.size()));

		} catch (Exception e) {
			// Determine the error, log it, and put an error message in ActionErrors
			exceptionOccurred = true;
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));

			log.error("Exception in execute:" + e);

			// Only add the general error if no other errors are present
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			// forward = mapping.findForward("open");
			mav.setViewName(ActionUrlMapping.USERIDSELECTORACTIONS.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		// Finish with
		// return (forward);
		request.setAttribute("actionMessages", errors);
		request.setAttribute("userIDSelectorForm", userIDSelectorForm);
		return mav;
	}
}
