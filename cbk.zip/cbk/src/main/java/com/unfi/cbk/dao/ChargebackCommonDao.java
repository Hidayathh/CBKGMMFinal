package com.unfi.cbk.dao;

import java.util.List;

import com.unfi.cbk.exceptions.CbkServiceException;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * @author vpil001
 * @version 1.0
 */

public interface ChargebackCommonDao {

	// public VendorControl getVendorPageAccessCtrl(String vendorId, String
	// screenName) throws EPassServiceException;

	// public VendorControl getVendorAccess(String vendorId) throws
	// EPassServiceException;

	public List doVendorSearch(String vendorNumber, String vendorName) throws CbkServiceException;

	public List doLocationSearch(String locationNumber, String locationName) throws CbkServiceException;

	public List doOriginatorSearch(String userId, String userName) throws CbkServiceException;
	public List doNextApproverSearch(String userId,String userName)throws CbkServiceException;
	public List doParentSearch(String parentNumber, String parentName) throws CbkServiceException;
	
	public List doVendorIdSearch(String removeLeadingZeroVendorId, String spaceFillLeftVendorId, String vendorName ) throws DataAccessException;

}