package com.unfi.cbk.dao;

import java.util.List;
import java.util.Map;

import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * @author yhp6y2l
 *
 */

public interface ChargebackCreateDao {

	public List<ChargebackBO> getSubFunds() throws DataAccessException;
	
	 
    public List<ChargebackBO> getItemInfo(Map formSearchValuesMap) throws DataAccessException;
    
    public List<ChargebackBO> validateRegionWithoutDivision(Map formSearchValuesMap) throws DataAccessException;
    
    public List<ChargebackBO> validateRegionWithDivision(Map formSearchValuesMap) throws DataAccessException;

}
