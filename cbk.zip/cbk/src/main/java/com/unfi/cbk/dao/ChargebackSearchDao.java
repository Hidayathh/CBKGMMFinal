package com.unfi.cbk.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.CreateNewUserBO;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The ChargebackSearchDao interface creates the bridge between the caller and
 * the actual work in retrieving the data.
 *
 * @author yhp6y2l
 * @since 1.0
 */
public interface ChargebackSearchDao {

	/**
	 * Gets the search results from the database. This method takes the search
	 * values provided on the form and creates a database query. The list of
	 * documents that match the criteria are the results that are returned to the
	 * caller.
	 * 
	 * @return the list of chargebacks from the index table
	 * @param formSearchValuesMap the Map for the search page
	 * @since 1.0
	 */
	public ResultList getChargebacks(Map formSearchValuesMap) throws DataAccessException;

	public ResultList getAvailableChargebacks(Map formSearchValuesMap) throws DataAccessException;

	public void approveChargebacks(ChargebackBO cbkBo) throws DataAccessException;

	public void denyChargebacks(ChargebackBO cbkBo) throws DataAccessException;

	public ResultList locationNumberValidator(Map formSearchValuesMap) throws DataAccessException;

	public ResultList invoiceNumberValidator(Map formSearchValuesMap) throws DataAccessException;

	public ResultList vendorNumberValidator(String vendorId) throws DataAccessException;

	public ResultList originatorValidator(Map formSearchValuesMap) throws DataAccessException;

	public ResultList nextApproverValidator(Map formSearchValuesMap) throws DataAccessException;

	public List getChargebackTypes() throws DataAccessException;

	public List getReasons() throws DataAccessException;

	public List getProductGroup() throws DataAccessException;

	public ChargebackBO getChargebackDetail(Map formSearchValuesMap) throws DataAccessException;

	public ResultList getCbkDetTable(Map formSearchValuesMap) throws DataAccessException;
	
	public ResultList getCbkDetTableInfo(Map formSearchValuesMap) throws DataAccessException;

	public ResultList getChargebackDistribution(Map formSearchValuesMap) throws DataAccessException;

	public ChargebackBO getChargebackInfo(Map formSearchValuesMap) throws DataAccessException;
	
	public ChargebackBO getChargebackDetailInfo(Map formSearchValuesMap) throws DataAccessException;	

	public ChargebackBO getChargeback(Map formSearchValuesMap) throws DataAccessException;

	public ResultList getApproverRoles(Map formSearchValuesMap) throws DataAccessException;

	public void createChargeback(ChargebackBO chargeBack) throws DataAccessException;

	public void updateChargeback(ChargebackBO chargeBack) throws DataAccessException;

	public void createCbkDistribution(List distributionList) throws DataAccessException;

	public void deleteCbkDistribution(Map formSearchValuesMap) throws DataAccessException;

	public void createCbkItem(List itemList) throws DataAccessException;

	public void updateCbkItem(List itemList) throws DataAccessException;

	public void deleteCbkItem(Map formSearchValuesMap) throws DataAccessException;

	public void insertMenuAccessforUser(List selectedAccessRole) throws DataAccessException;

	public void InsertUser(List selectedRoleLocationList, Map formSearchValuesMap) throws DataAccessException;

	public List getLocations() throws DataAccessException;
	
	public List getLocationsForCreateUser() throws DataAccessException;

	public List getRoles() throws DataAccessException;

	public List getAllRoles() throws DataAccessException;

	public void updateUser(List selectedRoleLocationList, Map formSearchValuesMap) throws DataAccessException;
	// public void updateUserRolesLocations(List selectedUpdateRoleLocationList)
	// throws DataAccessException;

	// public List getUserDetails(String userId) throws DataAccessException;
	public CreateNewUserBO getUserDetails(String userId) throws DataAccessException;

	public ResultList getUserAssignedRoles(String userId) throws  DataAccessException;
	
	public ResultList getUserRolesLocations(String userId) throws DataAccessException;

	public void EditUser(Map formSearchValuesMap) throws DataAccessException;

	public void deleteUserDetails(String userId) throws DataAccessException;

	public List doChargebackApproverSearch(String SmUserId, String locationNumber, String roleId,String typeId)
			throws DataAccessException;

	public String getApproverStepsUp(String typeId,String stepNumber) throws DataAccessException;

	public String getApproverStepsDown(String typeId,String stepNumber)
			throws DataAccessException;

	public ChargebackBO getChargebackVendor(Map formSearchValuesMap) throws DataAccessException;

	public String getCompanyCode(String locationNumber) throws DataAccessException;

	
	public String getStepNumberForMassApproval(String typeId, String roleId) throws DataAccessException;
	
	public String getMaxStepNumber(String typeId) throws DataAccessException;
	
	public String getMinStepNumber(String typeId) throws DataAccessException;
	
	public String getRoleIdByStepAndType(String typeId,String stepNumber) throws DataAccessException;
	/*
	 * public void fillCheckDetails(Chargeback doc) throws CbkServiceException;
	 * 
	 * public List getChargebackAttachments(Chargeback document) throws
	 * DataAccessException;
	 */

	// public ResultList getCbks(Map params, List filterParams, boolean exclude);
	public HashMap getRolesByUserForMenu(Map formSearchValuesMap) throws DataAccessException;

	public ChargebackBO getNextInvoceNumberOrBarcode(String locationNumber) throws DataAccessException;

	public void updateInvoice(ChargebackBO cbkBo) throws DataAccessException;

	public void insertInvoice(ChargebackBO cbkBo) throws DataAccessException;

	public void updateChargebackApprover(ChargebackBO chargeBack) throws DataAccessException;

	public void updateAttachment(ChargebackBO chargebackBO) throws DataAccessException;

	public void createAttachment(ChargebackBO chargebackBO) throws DataAccessException;

	public void updateChargebackDenyReason(ChargebackBO chargeBack) throws DataAccessException;

	public ChargebackBO findByAttachmentName(ChargebackBO chargebackBO) throws DataAccessException;

	public void deleteAttachment(String invoiceNumber) throws DataAccessException;

	public List<ChargebackBO> getAttachmentName(String invoiceNumber) throws DataAccessException;

	public ResultList getAccountProductCodes(Map params) throws DataAccessException;

	public List getLocationsByUser(String approverId) throws DataAccessException;

	public ResultList getAvailableInvoiceNumber(String invoice, String location) throws DataAccessException;

	public ResultList getApprovalHistory(String invoice) throws DataAccessException;

	public void deleteApprovals(String invoiceNumber, String locationNumber) throws DataAccessException;

	public ResultList getChargebackApprovalStatus(String inviceNumber, String approverId) throws DataAccessException;

	public String getAdminUser(String userId, String roleId) throws DataAccessException;

	public ResultList getMassApprovalsList(Map formSearchValuesMap) throws DataAccessException;

	public String getValidVendorNumber(String vendorId) throws DataAccessException;
	
	public ResultList getRoleIdRouteIdForUser(Map params) throws DataAccessException;
	
	public String getApprovalLimitForUser(Map params) throws DataAccessException;
	
	  public String deleteApproverReference(String userId) throws DataAccessException;
	  
	  public void massUpdateChargebackApprover(List massApprovalList) throws DataAccessException;
      
     // public void massApproveChargebacks(List massApprovalList) throws DataAccessException;
      
      public String getValidAccountNumber(String companyCode, String accNum, String acct_unit) throws DataAccessException;
      
      public void createCbkItemSingleRecord(ChargebackBO chargeBack) throws DataAccessException;
      
      public void createCbkDistributionSingleRecord(ChargebackBO chargeBack) throws DataAccessException;
      
      public String getInvoiceEditableStatus(String invoiceNumber) throws DataAccessException;
      
      
      public String getApprovalWith5KLimit(String userId, String locationNumber) throws DataAccessException;
      
      public String getMaxStepNumberForInvoice(String invoiceNumber) throws DataAccessException;
      
      public String getInvoiceEligibleForApprove(String userId, String invoiceNumber) throws DataAccessException;
      
      public String getMaxStepNumberWithInvoiceAmount(String invoiceNumber,String locationNumber,String typeId) throws DataAccessException;
      
      public String getMinStepNumberWithInvoiceAmount(String invoiceNumber,String locationNumber,String typeId) throws DataAccessException;
      
      public String getApproverStepsUpWithInvoiceAmount(String invoiceNumber,String locationNumber,String typeId,String stepNumber)	throws DataAccessException;
      
      public String getApproverStepsDownWithInvoiceAmount(String invoiceNumber,String locationNumber,String typeId,String stepNumber) 	throws DataAccessException;
      
      public String getMaxStepNumberWithAmount(String typeId,String chargebackTotal) throws DataAccessException;
      
      public String getMinStepNumberWithAmount(String typeId,String chargebackTotal) throws DataAccessException;
      
      public String getApproverStepsUpWithmount(String typeId,String chargebackTotal,String stepNumber)	throws DataAccessException;
      
      public String getApproverStepsDownWithmount(String typeId,String chargebackTotal,String stepNumber)	throws DataAccessException;
      

  	public String getRoleIdForNextApprover(String invoiceNumber,String typeId,String locationNumber,String userId) throws DataAccessException;
  	public void createCbkFundsRecord(ChargebackBO cbkBO) throws DataAccessException;

	public void createCbkItemFundsRecord(ChargebackBO cbkBO) throws DataAccessException;

	public void createCbkDistributionFundsRecord(ChargebackBO cbkBO) throws DataAccessException;

	public void createCbkApprFundsRecord(ChargebackBO cbkBO) throws DataAccessException;

	public String getStepNumberForApproverByRoleid(String approverId) throws DataAccessException;
	
	public String getValidateUserId(String userId) throws DataAccessException;
	
	
	public void getCancelChargeback(String invoiceNumber) throws DataAccessException;
	
	public CreateNewUserBO getActiveUserDetails(String userId) throws DataAccessException;
	
	public List getChargebackTypesForCreate() throws DataAccessException;
	
	public ChargebackBO getVendorInfoByVendorId(String vendorId) throws DataAccessException;
	
	public String getValidMaxAmount(String creatorId, Integer typeId) throws DataAccessException;
	
	public String getAmountFloor(Map map)  throws DataAccessException;
	
	   public void updateChargebackFundsNextApprover(ChargebackBO cbkBO) throws DataAccessException;


}