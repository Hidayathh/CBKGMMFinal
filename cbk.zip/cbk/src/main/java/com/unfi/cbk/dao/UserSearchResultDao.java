package com.unfi.cbk.dao;

import java.util.Map;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The UserSearchResultDao interface creates the bridge between the caller and
 * the actual work in retrieving the data.
 */
public interface UserSearchResultDao {

	public ResultList allUsers(Map map) throws DataAccessException;
	
	public ResultList specificUserResults(Map map) throws DataAccessException;
	
	public ResultList specificUserSearch(Map map) throws DataAccessException;	
	
	public ResultList specificRoleIdSearch(Map map) throws DataAccessException;
	
	public ResultList userResultsByRole(Map map) throws DataAccessException;

	public ResultList userResultsByUser(Map map) throws DataAccessException;

	public ResultList userResultsByLocation(Map map) throws DataAccessException;


}