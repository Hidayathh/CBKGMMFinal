package com.unfi.cbk.dao.ibImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.unfi.cbk.bo.ChargebackReportBO;
import com.unfi.cbk.bo.VendorBO;
import com.unfi.cbk.dao.ChargebackCommonDao;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.util.StringFunctions;

/**
 * The ChargebackCommonDaoImpl class implements the generic ChargebackCommonDao
 * interface.
 * 
 * @author vpil001
 * @version 1.0
 */

public class ChargebackCommonDaoImpl extends SqlMapClientDaoSupport implements ChargebackCommonDao {

	static Logger log = Logger.getLogger(ChargebackCommonDaoImpl.class);

	/**
	 * @param sqlMapTemplate
	 */
	public ChargebackCommonDaoImpl(SqlMapClientTemplate sqlMapTemplate) {
		this.setSqlMapClientTemplate(sqlMapTemplate);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.unfi.cbk.dao.ChargebackCommonDao#doVendorSearch(java.lang.String,
	 * java.lang.String)
	 */
	public List doVendorSearch(String vendorNumber, String vendorName) throws DataAccessException {
		//List<VendorBO> finalList = new ArrayList<VendorBO>();
		List finalList = new ArrayList();
		List<VendorBO> l = new ArrayList<VendorBO>();
		VendorBO vbo = null;
		try {
			System.out.println("--------ChargebackCommomDaoImpl.java-------doVendorSearch()---");
			HashMap map = new HashMap();
			map.put("vendorNumber", vendorNumber.replace('*', '%'));
			map.put("vendorName", vendorName.replace('*', '%').toUpperCase());

			List vendorList = getSqlMapClientTemplate().queryForList("ChargebackCommon.doVendorSearch", map);
			System.out.println("-------vendorList.size()----"+vendorList.size());
			
			
			for(int i=0; i<vendorList.size(); i++)
			{
				 vbo = (VendorBO)vendorList.get(i);
				 VendorBO bo = new VendorBO();
				 List  result = null;
				if(vbo.getVendorId()!="") 
				{
					String removeLeadingZeroVendorId = StringFunctions.removeLeadingZeroIfNumber(vbo.getVendorId());
					System.out.println("--removeLeadingZeroVendorId---"+removeLeadingZeroVendorId);
					String spaceFillLeftVendorId = StringFunctions.spaceFillLeft(vbo.getVendorId(),9,true);
					System.out.println("----VENDOR SELECTOR SEARCH---spaceFillLeftVendorId---"+spaceFillLeftVendorId);
					HashMap m = new HashMap();
					//map.put("vendorNumber", vendorNumber.replace('*', '%'));
					m.put("Vend", removeLeadingZeroVendorId);
					m.put("vendor", spaceFillLeftVendorId);
					m.put("vendorName", vendorName.replace('*', '%').toUpperCase());
					
					 result = getSqlMapClientTemplate().queryForList("ChargebackCommon.doVendorIdSearch", m);
					System.out.println("result size ----"+result.size());
					
					if(result.size()>0)
					{
						VendorBO v = (VendorBO)result.get(0);
							
						if(v.getCorrLock().equals("Y"))
						{
							m.put("locCode", " ");
							bo = (VendorBO)getSqlMapClientTemplate().queryForObject("ChargebackCommon.getVendorInfoByCorr", m);
						}
						else if(v.getCorrLock().equals("N"))
						{
							m.put("locCode", " 099");
							bo = (VendorBO)getSqlMapClientTemplate().queryForObject("ChargebackCommon.getVendorInfoByCorr", m);
						}
						l.add(bo);
						
						System.out.println("----doVendorIdSearch--l Size---"+l.size());
					}
				}
			}
		}
		 catch (Exception e) {
			throw new DataAccessException(e);
		}

		return l;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.unfi.cbk.dao.ChargebackCommonDao#doVendorIdSearch(java.lang.String,
	 * java.lang.String)
	 */
	public List doVendorIdSearch(String removeLeadingZeroVendorId, String spaceFillLeftVendorId, String vendorName) throws DataAccessException {
		List  result = null;
		List l = new ArrayList();
		try {
			System.out.println("--------ChargebackCommomDaoImpl.java-------doVendorIdSearch()---");
			HashMap map = new HashMap();
			//map.put("vendorNumber", vendorNumber.replace('*', '%'));
			map.put("Vend", removeLeadingZeroVendorId);
			map.put("vendor", spaceFillLeftVendorId);
			map.put("vendorName", vendorName.replace('*', '%').toUpperCase());
			
			result = getSqlMapClientTemplate().queryForList("ChargebackCommon.doVendorIdSearch", map);
			System.out.println("result -size---"+result.size());
			if(result.size()>0)
			{
				VendorBO v = (VendorBO)result.get(0);
					
				if(v.getCorrLock().equals("Y"))
				{
					map.put("locCode", " ");
					l = (List)getSqlMapClientTemplate().queryForList("ChargebackCommon.getVendorInfoByCorr", map);
				}
				else if(v.getCorrLock().equals("N"))
				{
					map.put("locCode", " 099");
					l = (List)getSqlMapClientTemplate().queryForList("ChargebackCommon.getVendorInfoByCorr", map);
				}
			}
			/*
			if(result != null || !result.isEmpty())
			{
				l = (List)getSqlMapClientTemplate().queryForList("ChargebackCommon.getVendorInfoByCorr", map);
			}
			if( !result.equals(null)) {
				l = (List)getSqlMapClientTemplate().queryForList("ChargebackCommon.getVendorInfoByCorr", map);
			}
			System.out.println("----doVendorIdSearch--l Size---"+l.size());
			
			*/
		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return l;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.unfi.cbk.dao.ChargebackCommonDao#doLocationSearch(java.lang.String,
	 * java.lang.String)
	 */
	public List doLocationSearch(String locationNumber, String locationName) throws DataAccessException {
		List l = null;

		try {
			System.out.println("--------ChargebackCommomDaoImpl.java-------doLocationSearch()---");
			HashMap map = new HashMap();
			map.put("locationNumber", locationNumber.replace('*', '%'));
			map.put("locationName", locationName.replace('*', '%').toUpperCase());

			l = getSqlMapClientTemplate().queryForList("ChargebackCommon.doLocationSearch", map);
		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return l;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.unfi.cbk.dao.ChargebackCommonDao#doOriginatorSearch(java.lang.String,
	 * java.lang.String)
	 */
	public List doOriginatorSearch(String userId, String userName) throws DataAccessException {
		List l = null;

		try {
			System.out.println(
					"--------ChargebackCommomDaoImpl.java-------doOriginatorSearch()---" + userId + ":::" + userName);
			HashMap map = new HashMap();
			map.put("userId", userId.replace('*', '%'));
			map.put("userName", userName.replace('*', '%').toUpperCase());

			l = getSqlMapClientTemplate().queryForList("ChargebackCommon.doOriginatorSearch", map);
		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return l;
	}

	/* (non-Javadoc)
     * @see com.unfi.cbk.dao.ChargebackCommonDao#doNextApproverSearch(java.lang.String, java.lang.String)
     */
    public List doNextApproverSearch(String userId, String userName) throws DataAccessException {
        List l = null;
        
        try {
        	System.out.println("--------ChargebackCommomDaoImpl.java-------doNextApproverSearch()---"+userId+":::"+userName);
            HashMap map = new HashMap();
            map.put("userId", userId.replace('*', '%'));
            map.put("userName", userName.replace('*', '%').toUpperCase());
        
            l = getSqlMapClientTemplate().queryForList("ChargebackCommon.doNextApproverSearch", map);
        }
        catch (Exception e) {
            throw new DataAccessException(e);
        }
        
        return l;         
	}
    
	@Override
	public List doParentSearch(String parentNumber, String parentName) throws DataAccessException {
		List l = null;

		try {
			System.out.println("--------ChargebackCommomDaoImpl.java-------doParentSearch()---");
			HashMap map = new HashMap();
			map.put("parentNumber", parentNumber.replace('*', '%'));
			map.put("parentName", parentName.replace('*', '%').toUpperCase());

			l = getSqlMapClientTemplate().queryForList("ChargebackCommon.doParentSearch", map);
		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return l;
	}


}