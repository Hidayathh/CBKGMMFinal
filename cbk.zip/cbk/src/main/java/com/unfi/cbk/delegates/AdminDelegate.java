package com.unfi.cbk.delegates;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.CreateNewUserBO;
import com.unfi.cbk.dao.AdminDao;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.util.DateFunctions;

/**
 * @author yhp6y2l
 * @version 3.3
 */

public class AdminDelegate {

	private AdminDao adminDao;

	public AdminDelegate(AdminDao adminDao) {
		this.adminDao = adminDao;
	}

	public ResultList getChargebacks(Map params) throws DataAccessException {

		// Set up the date range of the search
		this.calculateSearchDates(params);
		ResultList rL = adminDao.getChargebacks(params);

		// Only keep the fromDate and toDate parameters in the map if the user
		// entered a manual date selection.
		String dateCriteria = (String) params.get("dateCriteria");
		if (dateCriteria != null && !dateCriteria.equals("manual")) {
			params.remove("fromDate");
			params.remove("toDate");
		}

		return rL;
	}

	public List<CreateNewUserBO> getRolesByUserForMenu() throws DataAccessException {
		List<CreateNewUserBO> l = adminDao.getRolesByUserForMenu();
		return l;
	}

	public ResultList getAvailableChargebacks(Map params) throws DataAccessException {
		ResultList rL = adminDao.getAvailableChargebacks(params);
		return rL;
	}

	public ResultList adminResults(Map map) throws DataAccessException {
		ResultList rL = adminDao.adminResults(map);
		return rL;
	}

	public ResultList userDetails(Map map) throws DataAccessException {
		ResultList rL = adminDao.userDetails(map);
		return rL;
	}

	private void calculateSearchDates(Map params) {
		// Determine the dates to use
		String dateCriteria = (String) params.get("dateCriteria");
		String fromDate = (String) params.get("fromDate");
		String toDate = (String) params.get("toDate");
		String from = "";
		String to = "";

		if ((dateCriteria != null) && (!dateCriteria.equals(""))) {
			if (dateCriteria.equals("3")) {
				// Use the dates provided
				from = DateFunctions.formatYear(fromDate);
				params.put("fromDate", from);
				params.put("searchFromDate", DateFunctions.formatDate(from));
				to = DateFunctions.formatYear(toDate);
				params.put("toDate", to);
				params.put("searchToDate", DateFunctions.formatDate(to));
			} else {
				String dateCriteriaDays = null;

				if (dateCriteria.equalsIgnoreCase("1")) {
					dateCriteriaDays = "30";
				} else if (dateCriteria.equalsIgnoreCase("2")) {
					dateCriteriaDays = "60";
				}

				from = DateFunctions.adjustCurrentDate(-(Integer.parseInt(dateCriteriaDays)));
				to = DateFunctions.getToday();

				params.put("fromDate", from);
				params.put("searchFromDate", DateFunctions.formatDate(from));
				params.put("toDate", to);
				params.put("searchToDate", DateFunctions.formatDate(to));
			}
		}
	}

	/* For AuditDetails */

	public ResultList getTypeAmount(Map params) throws DataAccessException {
		ResultList rL = adminDao.getTypeAmount(params);
		return rL;
	}
	/* For AdminDetails */

	public List getLocations() throws DataAccessException {
		List<ChargebackBO> l = adminDao.getLocations();

		return l;
	}

	public List getRoles() throws DataAccessException {
		List l = adminDao.getRoles();

		return l;
	}

	public HashMap getRolesByUserForMenu(Map params) throws DataAccessException {
		HashMap menuMap = adminDao.getRolesByUserForMenu(params);
		return menuMap;
	}

	public CreateNewUserBO getUserDetails(String userId) throws DataAccessException {
		return adminDao.getUserDetails(userId);

	}

	public ResultList getUserRolesLocations(String userId) throws DataAccessException {
		return adminDao.getUserRolesLocations(userId);

	}

	public void createImportChargeback(ChargebackBO chargeBack) throws DataAccessException {

		adminDao.createChargeback(chargeBack);

	}

	public void createCbkItem(ChargebackBO cbkBo) throws DataAccessException {
		adminDao.createCbkItem(cbkBo);
	}
	
	public void updateInvoice(ChargebackBO newInvoiceBO) throws DataAccessException { // TODO Auto-generated method stub
		adminDao.updateInvoice(newInvoiceBO);

	}

	public void createAttachment(ChargebackBO chargebackBO) throws DataAccessException { // TODO Auto-generated method
																							// stub
		adminDao.createAttachment(chargebackBO);

	}

	public List balanceAccrual(Map map) throws DataAccessException {
		return  adminDao.balanceAccrual(map);
		
	}

	public List getAccrualsList(Map map) throws DataAccessException {

		return adminDao.getAccrualsList(map);
	}

	public List getExportId(String date) throws DataAccessException {
		
		return adminDao.getExportId(date);
	}

}
