package com.unfi.cbk.delegates;

import java.util.List;
import java.util.Map;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.dao.ChargebackReportDao;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * @author yhp6y2l
 * @version 3.3
 */

public class ChargebackReportDelegate {

	private ChargebackReportDao chargebackReportDao;

	public ChargebackReportDelegate(ChargebackReportDao chargebackReportDao) {
		this.chargebackReportDao = chargebackReportDao;
	}

	public List getReasonCode() throws DataAccessException {
		List l = chargebackReportDao.getReasonCode();

		return l;
	}

	public List getChargebackReportList(Map searchParametersFrom) throws DataAccessException {
		List l = chargebackReportDao.getChargebackReportList(searchParametersFrom);
		return l;
	}

}
