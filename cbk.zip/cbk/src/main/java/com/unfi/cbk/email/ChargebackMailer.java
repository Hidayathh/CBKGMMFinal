package com.unfi.cbk.email;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.exceptions.CbkServiceException;
import com.unfi.cbk.forms.ChargebackCreateForm;
import com.unfi.cbk.forms.ChargebackUpdateForm;
import com.unfi.cbk.utilcore.ApplicationProperties;

/**
 * @author yhp6y2l
 */
@Configuration
public class ChargebackMailer {

	@Autowired
	private JavaMailSender javaMailSender;
	
	private static final String USERGROUP_EMAIL_ADDRESS = ApplicationProperties.getUserGroupEmailAddress();
	public void updateSendEmail(ChargebackUpdateForm update, String AssignerEmail, String SmUserId) throws CbkServiceException, MessagingException {
		
		
		StringBuffer emailMessage = new StringBuffer();
		MimeMessage msg = javaMailSender.createMimeMessage();
		MimeMessageHelper message = new MimeMessageHelper(msg, true);
		message.setFrom(USERGROUP_EMAIL_ADDRESS);

		emailMessage.append("<h1>Central Disbursements Chargeback Application</h1>");
		emailMessage.append("<br/>");
		emailMessage.append("Chargeback # " + update.getInvoiceNumber() + " has been approved by: " +update.getCreatorId()+" for Location: " 
		+ update.getLocationNumber() + ". You need to direct this Chargeback to the next approver.");
		
		emailMessage.append("<br/>");
		msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(AssignerEmail));
		message.setSubject("Chargeback Information Invoice updated by " + update.getCreatorId());
		message.setText(emailMessage.toString(), true);
		javaMailSender.send(msg);
		
		
	}
	
	public void createSendEmail(ChargebackCreateForm create, String AssignerEmail, String SmUserId) throws CbkServiceException, MessagingException {
		
		MimeMessage msg = javaMailSender.createMimeMessage();
		MimeMessageHelper message = new MimeMessageHelper(msg, true);
		message.setFrom(USERGROUP_EMAIL_ADDRESS);
		msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(AssignerEmail));
		message.setSubject("Chargeback Information Invoice created by "+SmUserId);
		message.setText("<h1>Central Disbursements Chargeback Application</h1>" + System.lineSeparator() 
				+ "Chargeback # "+create.getInvoiceNumber()+" has been created by "+ create.getCreatorId()
				+ " for Location "+create.getLocationNumber()+". Please launch the Chargeback Web application to check status/more details if needed."
				, true);
		javaMailSender.send(msg);
		

	}

	public void nextApproverSendEmail(ChargebackBO cbkbo, String AssignerEmail, String SmUserId) throws CbkServiceException, MessagingException {
		
		MimeMessage msg = javaMailSender.createMimeMessage();
		MimeMessageHelper message = new MimeMessageHelper(msg, true);
		message.setFrom(USERGROUP_EMAIL_ADDRESS);
		message.setTo(AssignerEmail);
		message.setSubject(
				"Chargeback Information Invoice #" + cbkbo.getInvoiceNumber()+ " approved by "+SmUserId);
		message.setText("<h1>Central Disbursements Chargeback Application</h1>" + System.lineSeparator() 
				+ "Chargeback # "+cbkbo.getInvoiceNumber()+" has been assigned to "+ cbkbo.getNextApprover()
				+ " for Location "+cbkbo.getLocationNumber()+". Please launch the Chargeback application from the Start>SV Apps>Chargeback menu option and select 'View Invoices For' section of the ‘Create New Chargeback’ screen. "
				, true);
		javaMailSender.send(msg);
		

	}

	public void finalApproverSendEmail(ChargebackBO cbkbo, String AssignerEmail, String SmUserId) throws CbkServiceException, MessagingException {
		
		MimeMessage msg = javaMailSender.createMimeMessage();
		MimeMessageHelper message = new MimeMessageHelper(msg, true);
		message.setFrom(USERGROUP_EMAIL_ADDRESS);
		message.setTo(AssignerEmail);
		message.setSubject(
				"Chargeback Information Invoice #" + cbkbo.getInvoiceNumber()+ " approved by "+SmUserId);
		message.setText("<h1>Central Disbursements Chargeback Application</h1>" + System.lineSeparator() 
				+ "Chargeback # "+cbkbo.getInvoiceNumber()+" has been approved by "+ cbkbo.getCreatorId()
				+ " for Location "+cbkbo.getLocationNumber()+". And reached maximum amount, hence no further approval is required."
				, true);
		javaMailSender.send(msg);
		

	}
	public void massApprovedInvoiceSendEmail(StringBuffer approvedInvoicesList, String location,  String AssignerEmail, String SmUserId) throws CbkServiceException, MessagingException {

		StringBuffer emailMessage = new StringBuffer();		
		approvedInvoicesList.setLength(Math.max(approvedInvoicesList.length() - 1, 0));
		String approvedInvList = approvedInvoicesList.toString();
		if (approvedInvList.endsWith(",")) {
			approvedInvList = approvedInvList.substring(0, approvedInvList.length() - 1) + "";
		}
		MimeMessage msg = javaMailSender.createMimeMessage();
		MimeMessageHelper message = new MimeMessageHelper(msg, true);
		message.setFrom(USERGROUP_EMAIL_ADDRESS);
		
		emailMessage.append("<h1>Central Disbursements Chargeback Application</h1>");
		emailMessage.append("<br/>");
		emailMessage.append("Below invoice(s) have been approved by " +SmUserId+ " for Location " +location+". Please launch the Chargeback Web application to check status/more details if needed.");
		emailMessage.append("<br/>");
		emailMessage.append("<br/>");
		emailMessage.append("Chargeback# "+approvedInvList+".");
			
		if(approvedInvoicesList != null){
				msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(AssignerEmail));
				message.setSubject(
						"Chargeback Information Invoice(s) approved by "+SmUserId);
				message.setText(emailMessage.toString(), true);
				javaMailSender.send(msg);
			}
		}
	public void massAssignedApproverInvoiceSendEmail(StringBuffer invoiceNumbers, String location,  String AssignerEmail,String SmUserId,  String assignedApproverId) throws CbkServiceException, MessagingException {
		
		StringBuffer emailMessage = new StringBuffer();
		invoiceNumbers.setLength(Math.max(invoiceNumbers.length() - 1, 0));
		String approvedInvList = invoiceNumbers.toString();
		MimeMessage msg = javaMailSender.createMimeMessage();
		MimeMessageHelper message = new MimeMessageHelper(msg, true);
		message.setFrom(USERGROUP_EMAIL_ADDRESS);
		
		emailMessage.append("<h1>Central Disbursements Chargeback Application</h1>");
		emailMessage.append("<br/>");
		emailMessage.append("Below invoice(s) have been approved by " +SmUserId+ " for Location " +location+". Please launch the Chargeback Web application to check status/more details if needed.");
		emailMessage.append("<br/>");
		emailMessage.append("<br/>");
		emailMessage.append("Chargeback# "+approvedInvList+".");
		
		if(invoiceNumbers != null){
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(AssignerEmail));
			message.setSubject("Chargeback Information Invoice(s) approved by "+SmUserId);
			message.setText(emailMessage.toString(), true);			
			javaMailSender.send(msg);
		}
	}
	
	public void fundsMgntEmail(ChargebackBO cbkBO, String AssignerEmail) throws CbkServiceException, MessagingException {

		StringBuffer emailMessage = new StringBuffer();
		MimeMessage msg = javaMailSender.createMimeMessage();
		MimeMessageHelper message = new MimeMessageHelper(msg, true);
		// message.setFrom(environment.getProperty("usergroup.email.address"));
		message.setFrom(USERGROUP_EMAIL_ADDRESS);

		emailMessage.append("<h1>Central Disbursements Chargeback Application</h1>");
		emailMessage.append("<br/>");
		emailMessage.append("Chargeback # " + cbkBO.getInvoiceNumber() + " has been created by: " +cbkBO.getCreatorId()+" for Location: " 
		+ cbkBO.getLocationNumber() + ". You need to direct this Chargeback to the next approver.");
		
		emailMessage.append("<br/>");
		msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(AssignerEmail));
		message.setSubject("Chargeback Information Invoice created by " + cbkBO.getCreatorId());
		message.setText(emailMessage.toString(), true);
		javaMailSender.send(msg);
	}

}
