/*
 * Created on Oct 14, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.unfi.cbk.exceptions;

/**
 * 
 * @author yhp6y2l
 *
 */
public class CbkServiceException extends Exception {

	/**
	 * Create an instance with the default message.
	 */
	public CbkServiceException() {
		this("Exception in service.");
	}

	/**
	 * Creates an instance with a specified message
	 * 
	 * @param message The message for the exception.
	 */
	public CbkServiceException(String message) {
		super(message);
	}

	/**
	 * Creates an instance with a message that wraps an existing exception.
	 * 
	 * @param message The text message
	 * @param cause   Exception to wrap.
	 */
	public CbkServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Creates an instance with a default message that wraps an existing exception.
	 * 
	 * @param cause The exception to wrap.
	 */
	public CbkServiceException(Throwable cause) {
		super("Exception in service.", cause);
	}
}
