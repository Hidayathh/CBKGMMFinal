package com.unfi.cbk.filter;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.beanutils.ConstructorUtils;
import org.apache.log4j.Logger;

/**
 * @author yhp6y2l
 * @version 1.0
 */
public class CBKRequestWrapperFactory {

	private static Logger log = Logger.getLogger(CBKRequestWrapperFactory.class);

	/**
	 * 
	 * @param request HttpServletRequest to be wrapped
	 * @return HttpServletRequest
	 * 
	 *         The factory attempts to instantiate a HttpServletRequestWrapper
	 *         object using the ServletRequest object passed in. The class of the
	 *         wrapper instantiated is determined by the current value of the
	 *         Constants.WRAPPER_CLASS variable. If no class is specified, or the
	 *         factory cannot instantiate the wrapper, the request is returned
	 *         without a wrapper.
	 */
	public static HttpServletRequest getCbkRequestWrapper(ServletRequest request) {
		HttpServletRequest req = (HttpServletRequest) request;
		String wClass = WrapperConstants.CBK_WRAPPER_CLASS;
		if (WrapperConstants.CBK_WRAPPER_CLASS != null && WrapperConstants.CBK_WRAPPER_CLASS.length() > 0
				&& !WrapperConstants.CBK_WRAPPER_CLASS.equalsIgnoreCase(WrapperConstants.NONE)) {

			try {
				Class c = Class.forName(wClass);
				Object obj = ConstructorUtils.invokeConstructor(c, request);
				if (obj != null) {
					// cast the returned object
					req = (HttpServletRequestWrapper) obj;
				}
			} catch (Exception e) {
				log.error("Cannot instantiate Wrapper " + e.getMessage(), e);
			}
		}
		return req;
	}

}
