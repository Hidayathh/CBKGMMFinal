package com.unfi.cbk.filter;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.unfi.cbk.b2aldap.LDAPFunction;
import com.unfi.cbk.b2aldap.LDAPHandler;

public class CBKTestHttpServletRequestWrapper extends ChargebackTestHttpServletRequestWrapper {

	private static Logger log = Logger.getLogger(CBKTestHttpServletRequestWrapper.class);


	@SuppressWarnings({ "rawtypes", "unchecked" })
	public CBKTestHttpServletRequestWrapper(HttpServletRequest request) {
		super(request);

		LDAPHandler lh = null;
		LDAPFunction ldap = null;

		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");
		HashMap<String, String> ldapProMap = (HashMap<String, String>) session.getAttribute("ldapProMap");

		if (SmUserId != null) {
			HashMap<String, String> roleBasedMenu = (HashMap<String, String>) session.getAttribute("roleBasedMenu");
			Iterator itr = roleBasedMenu.entrySet().iterator();
			while (itr.hasNext()) {
				Map.Entry entry = (Map.Entry) itr.next();
				harborRoles.add(entry.getValue());
			}
			lh = new LDAPHandler(SmUserId);
			try {
				ldap = lh.getLDAPConnection(SmUserId, ldapProMap);
				String userName = ldap.getUserName();
				session.setAttribute("userName", userName);
			} catch (Exception e) {
				e.printStackTrace();
				log.error("Exception obtaining ldap connection: " + e);
			} finally {

				try {
					lh.closeLDAPConnection(ldap);
				} catch (Exception ignore) {
				}
			}
		}
	}

}
