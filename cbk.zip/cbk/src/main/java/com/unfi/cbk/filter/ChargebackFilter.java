package com.unfi.cbk.filter;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.delegates.OpenIdConnectDelegate;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * 
 * @author q4gwckb
 *
 */
public class ChargebackFilter implements Filter {

	private static Logger log = Logger.getLogger(ChargebackFilter.class);
	@Autowired
	private OpenIdConnectDelegate openIdConnect;
	@Autowired
	private ChargebackSearchDelegate chargebackSearchDelegate;

	public void init(FilterConfig config) {
	}

	@SuppressWarnings("unchecked")
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		HttpSession session = req.getSession();
		String active = (String) session.getAttribute("active");
		//String SmUserId = (String) session.getAttribute("SmUserId");
		String   SmUserId =WrapperConstants.LOGGED_IN_USER;
		session.setAttribute("SmUserId", SmUserId);
		Map<String, String> createParametersFrom = new HashMap<String, String>();
		if (openIdConnect == null) {
			ServletContext servletContext = request.getServletContext();
			WebApplicationContext webApplicationContext = WebApplicationContextUtils
					.getWebApplicationContext(servletContext);
			openIdConnect = webApplicationContext.getBean(OpenIdConnectDelegate.class);
		}
		if (chargebackSearchDelegate == null) {
			ServletContext servletContext = request.getServletContext();
			WebApplicationContext webApplicationContext = WebApplicationContextUtils
					.getWebApplicationContext(servletContext);
			chargebackSearchDelegate = webApplicationContext.getBean(ChargebackSearchDelegate.class);
		}
		if (SmUserId != null) {
			HashMap<String, String> ldapProMap = (HashMap<String, String>) openIdConnect.ldapProperties();
			session.setAttribute("ldapProMap", ldapProMap);
			createParametersFrom.put("approverId", SmUserId);
			try {
				HashMap<String, String> menuMap = chargebackSearchDelegate.getRolesByUserForMenu(createParametersFrom);
				session.setAttribute("roleBasedMenu", menuMap);
			} catch (DataAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		request = CBKRequestWrapperFactory.getCbkRequestWrapper(request);
		if (response instanceof HttpServletResponse) {
			((HttpServletResponse) response).addHeader("X-UA-Compatible", "IE=EmulateIE7");
		}
		String path = ((HttpServletRequest) request).getRequestURI();

		if (path.contains(WrapperConstants.TESTAPP_JSP)) {
			chain.doFilter(request, response);
		} else if (path.contains(WrapperConstants.TOKEN)) {
			chain.doFilter(request, response);
		} else if (active == null || active.equalsIgnoreCase("false") || SmUserId == null) {
			res.sendRedirect(openIdConnect.redirectUrl());
		} else if (active.equalsIgnoreCase("true") && !SmUserId.isEmpty()) {
			chain.doFilter(request, response);
		}

	}

	public void destroy() {
	}

}
