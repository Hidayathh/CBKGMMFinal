package com.unfi.cbk.filter;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

/**
 * @author yhp6y2l
 * @version 1.0 <br>
 * 
 *          WrapperConstants provides the values used by the
 *          HarborRequestWrapperFactory, and also by the wrapper implementation
 *          HarborHttpServletRequestWrapper.
 * 
 *          Changes to the constants can be made directly if desired. A
 *          preferable means of making changes is to use the <method>
 *          setConstants() </method> method. If the roles are provided, they
 *          shoud be a comma separated list of roles.
 * 
 *          Alternately, the <method> setTestRoles</method> provides a means to
 *          set the roles that the application user should have when roles have
 *          not been populated by another method.
 * 
 */
public class WrapperConstants {

	// Define the default values and the keys used to retrieve them
	public static final String SM_USER_HEADER = "USER_HEADER";
	private static String sm_user_header = "SM_User";

	public static final String SM_LOGIN_HEADER = "LOGIN_HEADER";
	private static String sm_login_header = "LDAPCN";

	public static final String SM_ROLE_HEADER = "ROLE_HEADER";
	private static String sm_role_header = "sm_role";

	public static final String SM_ROLE_DELIMITER = "ROLE_DELIMITER";
	private static String sm_role_delimiter = "^";

	public static final String SM_REGION_HEADER = "REGION_HEADER";
	private static String sm_region_header = "REGION";

	public static final String WRAPPER_CLASS = "WRAPPER_CLASS";
	private static String wrapper_class = "None";

	public static final String DEFAULT_USER_NAME = "DEFAULT_USER_NAME";

	public static final String DEFAULT_USER_ID = "DEFAULT_USER_ID";

	public static final String DEFAULT_USER_ROLES = "DEFAULT_USER_ROLES";

	public static final String DEFAULT_USER_TYPE = "DEFAULT_USER_TYPE";

	public final static String INVALID_ACCOUNT = "You have selected an invalid Account or Product Group for this location.  Please re-enter this data.";
	public final static String VALID_ACCOUNT = "The selected Account and Product Group is valid to this location!";

	public final static String NONE = "None";
//	public final static String TOKEN = "/cbk/token";
	public final static String TOKEN = "/cbk";
	public final static String LOGGED_IN_USER = "YHP6Y2L";//DZIE005";//"YHP6Y2L";
	public final static String TESTAPP_JSP = "/testapp.jsp";
	public final static String CBK_WRAPPER_CLASS = "com.unfi.cbk.filter.CBKTestHttpServletRequestWrapper";
	private static Properties properties = null;

	private static List TEST_ROLES = null;

	static {
		properties = new Properties();
		properties.setProperty(SM_USER_HEADER, sm_user_header);
		properties.setProperty(SM_LOGIN_HEADER, sm_login_header);
		properties.setProperty(SM_ROLE_HEADER, sm_role_header);
		properties.setProperty(SM_ROLE_DELIMITER, sm_role_delimiter);
		properties.setProperty(SM_REGION_HEADER, sm_region_header);
		properties.setProperty(WRAPPER_CLASS, wrapper_class);
	}

	/**
	 * 
	 * @param list java.util.List implementation that contains String entries
	 *             corresponding to the roles to be added.
	 */
	public static void setTestRoles(List list) {
		TEST_ROLES = list;
	}

	public static List getTestRoles() {
		return TEST_ROLES;
	}

	public static String get(String key) {
		return properties.getProperty(key);
	}

	/**
	 * 
	 * @param properties java.util.Properties object containing the String values to
	 *                   be used for the WrapperClass constants. The key for the
	 *                   values must be one of the known constant names. If this
	 *                   class is extended, this method should also be extended to
	 *                   initialize the added constants.
	 * 
	 */
	public static void setConstants(Properties p) {
		String value = null;

		value = p.getProperty(SM_USER_HEADER);
		if (value != null) {
			properties.setProperty(SM_USER_HEADER, value);
		}

		value = p.getProperty(SM_LOGIN_HEADER);
		if (value != null) {
			properties.setProperty(SM_LOGIN_HEADER, value);
		}

		value = p.getProperty(SM_ROLE_HEADER);
		if (value != null) {
			properties.setProperty(SM_ROLE_HEADER, value);
		}

		value = p.getProperty(SM_ROLE_DELIMITER);
		if (value != null) {
			properties.setProperty(SM_ROLE_DELIMITER, value);
		}

		value = p.getProperty(SM_REGION_HEADER);
		if (value != null) {
			properties.setProperty(SM_REGION_HEADER, value);
		}

		value = p.getProperty(WRAPPER_CLASS);
		if (value != null) {
			properties.setProperty(WRAPPER_CLASS, value);
		}

		value = p.getProperty(DEFAULT_USER_ID);
		if (value != null) {
			properties.setProperty(DEFAULT_USER_ID, value);
		}

		value = p.getProperty(DEFAULT_USER_NAME);
		if (value != null) {
			properties.setProperty(DEFAULT_USER_NAME, value);
		}

		value = p.getProperty(DEFAULT_USER_TYPE);
		if (value != null) {
			properties.setProperty(DEFAULT_USER_TYPE, value);
		}

		value = p.getProperty(DEFAULT_USER_ROLES);
		// System.out.println("Roles from properties: " + value);
		if (value != null) {
			TEST_ROLES = new ArrayList();
			if (value.indexOf(get(SM_ROLE_DELIMITER)) > -1) {
				StringTokenizer st = new StringTokenizer(value, get(SM_ROLE_DELIMITER));
				while (st.hasMoreTokens()) {
					TEST_ROLES.add(st.nextToken());
				}
			} else {
				TEST_ROLES.add(value);
			}
		}
	}
}
