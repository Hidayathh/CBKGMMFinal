package com.unfi.cbk.forms;

/**
 * The RequestSourceForm class is the struts action form used
 * for the request source maintenance section.  It extends
 * the ValidatorActionForm class in order to utilize built-in
 * struts validation and implements Pageable in order to work
 * with the VCR buttons.
 *
 * @author      yhp6y2l
 * @version     1.0
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.Validations;

/**
 * The ChargebackSearchForm class is the struts action form used to search for
 * documents.
 *
 * @author vpil001
 * @since 1.0
 * 
 */
@Component
public class ChargebackAdminForm extends SortablePageableActionForm {

	static Logger log = Logger.getLogger(ChargebackAdminForm.class);

	// Page-specific properties not part of Map

	private List chargebacks;
	private String[] chargebackSelections = new String[] {};

	private Integer maxMonths;
	// private String[] locationNumberCombined;
	private String originator;
	private String user;
	private String location;
	private String locationNumber;
	private String roleSelected;
	private String statusSelected;
	private String Status;
	private String userId;
	private String userName;
	private Integer results = null;
	private String totalExports;
	private String roleSelText;
	private String totalAccruals;
	
	
	

	public String getRoleSelText() {
		return roleSelText;
	}

	public void setRoleSelText(String roleSelText) {
		this.roleSelText = roleSelText;
	}

	public String getTotalAccruals() {
		return totalAccruals;
	}

	public void setTotalAccruals(String totalAccruals) {
		this.totalAccruals = totalAccruals;
	}

	public String getTotalExports() {
		return totalExports;
	}

	public void setTotalExports(String totalExports) {
		this.totalExports = totalExports;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public String getExportedAmount() {
		return exportedAmount;
	}

	public void setExportedAmount(String exportedAmount) {
		this.exportedAmount = exportedAmount;
	}

	private String roles;
	private List searchResults = null;
	private String selectedResult = null;
	private String users;
	private String date;

	private String typeName;
	private String exportedAmount;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getStatusSelected() {
		return statusSelected;
	}

	public void setStatusSelected(String statusSelected) {
		this.statusSelected = statusSelected;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getRoleSelected() {
		return roleSelected;
	}

	public void setRoleSelected(String roleSelected) {
		this.roleSelected = roleSelected;
	}

	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	public String getUsers() {
		return users;
	}

	public void setUsers(String users) {
		this.users = users;
	}

	/**
	 * @return
	 */
	public Integer getResults() {
		return results;
	}

	public String getSelectedResult() {
		return selectedResult;
	}

	/**
	 * @return
	 */

	/**
	 * @param i
	 */
	public void setResults(Integer i) {
		results = i;
	}

	/**
	 * @param string
	 */
	public void setSelectedResult(String string) {
		selectedResult = string;
	}

	public String getUserName() {
		return userName;
	}

	/**
	 * @param string
	 */
	public void setUserName(String string) {
		userName = string;
	}

	/**
	 * @param string
	 */

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}

	public String getLocationNumber() {
		return locationNumber;
	}

	public String getOriginator() {
		return originator;
	}

	public void setOriginator(String originator) {
		this.originator = originator;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	public List getSearchResults() {
		return this.searchResults;
	}

	public void setSearchResults(List list) {
		this.searchResults = list;
	}

	public ChargebackBO[] getChargeback() {
		if (chargebacks == null) {
			chargebacks = new ArrayList();
		}
		ChargebackBO[] r = new ChargebackBO[chargebacks.size()];
		for (int i = 0; i < chargebacks.size(); i++) {
			r[i] = (ChargebackBO) chargebacks.get(i);
		}
		return r;
	}

	public void setChargeback(ChargebackBO[] r) {
		chargebacks = Arrays.asList(r);
	}

	public ChargebackBO getChargeback(int i) {
		if (chargebacks == null) {
			chargebacks = new ArrayList();
		}
		for (int j = chargebacks.size(); j <= i; j++) {
			chargebacks.add(j, new ChargebackBO());
		}
		return (ChargebackBO) chargebacks.get(i);
	}

	public void setChargeback(int i, ChargebackBO doc) {
		if (chargebacks == null) {
			chargebacks = new ArrayList();
		}
		chargebacks.add(i, doc);
	}

	public List getChargebacks() {
		return chargebacks;
	}

	public void setChargebacks(List doc) {
		chargebacks = doc;
	}

	public String[] getChargebackSelections() {
		return chargebackSelections;
	}

	public void setChargebackSelections(String[] strings) {
		chargebackSelections = strings;
	}

	public List getSelectedResults() {
		List l = null;
		if (chargebackSelections != null) {
			l = new ArrayList();
			for (int i = 0; i < chargebackSelections.length; i++) {
				int j = Integer.parseInt(chargebackSelections[i]);
				l.add(chargebacks.get(j));
			}
		}
		return l;
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.ActionForm#reset(org.apache.struts.action.
	 * ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	public void reset(HttpServletRequest request) {
		// Only Employees and Manufacturers can search by date
		if (request.isUserInRole(Constants.EMPLOYEE_ROLE) || request.isUserInRole(Constants.MANUFACTURER_ROLE)) {
			setValue("dateCriteria", "1");
		}

		// Brokers are the only ones that are required to select a searchBy property
		if (request.isUserInRole(Constants.BROKER_ROLE)) {
			setValue("searchBy", "docnum");
		}

		// setValue("documentOutputType", "pdf");
		setSortBy("userName");
		setSortOrder("asc");
		setShowAll(false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.
	 * ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	public ActionMessages validate(HttpServletRequest request, ActionMessages errors) {
		// ActionMessages errors = new ActionMessages();
		String user = request.getRemoteUser();
		Validations validations = new Validations();

		try {

			if (!request.isUserInRole(Constants.BROKER_ROLE) && getString("dateCriteria") != null
					&& getString("dateCriteria").equals("manual")) {
				// Verify the entered dates meet the following criteria:
				// (1) The from date is less than the to date.
				// (2) Neither date goes back farther than the specified
				// number of years (as defined in the Resource Bundle
				// under label.dateCriteria.spanMaxYears
				// (3) Neither date is in the future

				// Verify condition (1)
				if (!validations.isValidDateRange(getString("fromDate"), getString("toDate"))) {
					// The from date is greater than the to date - invalid.
					errors.add("fromDate", "errors.dateRange", null);
				}



				if (!validations.isValidTimePeriodMonths(getString("fromDate"), getString("toDate"),
						maxMonths.intValue())) {
					// One of the dates is more than the max specified months ago - invalid
					errors.add("fromDate", "errors.datePriorMonths", new String[] { maxMonths.toString() });
				}

				if (!validations.isNot30PlusDaysInFuture(getString("fromDate"), getString("toDate"))) {
					errors.add("fromDate", "errors.dateFuture", null);
				}
			}

		} catch (Exception e) {
			log.error("Exception in ChargebackSearchForm.validate()" + e);
		}

		return errors;
	}

	/**
	 * @return
	 */
	public Integer getMaxMonths() {
		return maxMonths;
	}

	/**
	 * @param integer
	 */
	public void setMaxMonths(Integer integer) {
		maxMonths = integer;
	}

}
