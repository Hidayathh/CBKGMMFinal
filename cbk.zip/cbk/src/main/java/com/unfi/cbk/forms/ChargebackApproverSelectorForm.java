package com.unfi.cbk.forms;

import java.util.List;

import org.apache.log4j.Logger;

/**
 * The ApproverSelectorForm class is the struts action form used for the user
 * selector pop up. It extends the ValidatorActionForm class in order to utilize
 * built-in struts validation.
 *
 * @author vpil001
 * @version 1.0
 */
public class ChargebackApproverSelectorForm {// extends ValidatorActionForm {

	static Logger log = Logger.getLogger(ChargebackApproverSelectorForm.class);

	private String userId = null;
	private String userName = null;
	private String stepNumber = null;
	private String locationNumber = null;
	private String typeId = null;
	private String invoiceNumber;
	private String chargbackTotal;
	private String noApproverStepNumber;

	public String getNoApproverStepNumber() {
		return noApproverStepNumber;
	}

	public void setNoApproverStepNumber(String noApproverStepNumber) {
		this.noApproverStepNumber = noApproverStepNumber;
	}

	public String getChargbackTotal() {
		return chargbackTotal;
	}

	public void setChargbackTotal(String chargbackTotal) {
		this.chargbackTotal = chargbackTotal;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getTypeId() {
		return typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	public String getLocationNumber() {
		return locationNumber;
	}

	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}

	private String lastStepNumber = null;

	public String getLastStepNumber() {
		return lastStepNumber;
	}

	public void setLastStepNumber(String lastStepNumber) {
		this.lastStepNumber = lastStepNumber;
	}
	
	public String getFirstStepNumber() {
		return firstStepNumber;
	}

	public void setFirstStepNumber(String firstStepNumber) {
		this.firstStepNumber = firstStepNumber;
	}

	private String firstStepNumber = null;

	private List searchResults = null;
	private Integer results = null;
	private String selectedResult = null;

	public String getStepNumber() {
		return stepNumber;
	}

	public void setStepNumber(String stepNumber) {
		this.stepNumber = stepNumber;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return
	 */
	public Integer getResults() {
		return results;
	}

	/**
	 * @return
	 */
	public List getSearchResults() {
		return searchResults;
	}

	/**
	 * @param i
	 */
	public void setResults(Integer i) {
		results = i;
	}

	/**
	 * @param list
	 */
	public void setSearchResults(List list) {
		searchResults = list;
	}

	/**
	 * @return
	 */
	public String getSelectedResult() {
		return selectedResult;
	}

	/**
	 * @param string
	 */
	public void setSelectedResult(String string) {
		selectedResult = string;
	}

}