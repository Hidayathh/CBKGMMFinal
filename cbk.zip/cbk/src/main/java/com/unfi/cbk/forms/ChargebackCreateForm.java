package com.unfi.cbk.forms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.VendorBO;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.util.Validations;

/**
 * The RequestSourceForm class is the struts action form used for the request
 * source maintenance section. It extends the ValidatorActionForm class in order
 * to utilize built-in struts validation and implements Pageable in order to
 * work with the VCR buttons.
 *
 * @author yhp6y2l
 * @version 1.0
 */
public class ChargebackCreateForm extends SortablePageableActionForm {
	static Logger log = Logger.getLogger(ChargebackCreateForm.class);

	private String invoiceNumber;
	private String nextInvoiceNumber;

	private String nextBarcode;
	private String insertType;
	private String locationNumber;
	private String invoiceDate;
	private String dueDate;
	private String vendorId;
	private String vendorName;
	private String vendorAddress;
	private String netAmount;
	private String originator;
	private String approver;
	private String typeName;
	private String creatorId;
	private String reasonCode;
	private String prdGrpCode;
	private String attachmentType;
	private String itemPriceFormat;
	private String companyCode;
	private String fin;
	private String ca;
	private int documentNumber;
	private Integer typeId;
	private Integer memberCount;
	private List memberList;
	private String documentEncKey;
	private Date checkDate;
	private String docType;
	private String mimeType;
	private String notFound;

	private String dcNumber;
	private Integer itemNumber;
	private Integer itemPack;
	private String itemSize;
	private String itemDesc;
	private String itemUpc;
	private String itemSlot;
	private String division;
	private String region;
	private String subFund;
	private Integer itemQuantity;
	private Double itemPrice;
	private Double extension;

	private String accountNumber;
	private String distLocNumber;
	private String productGrp;
	private Double distributionAmt;
	private String vendorInvoice;

	private Integer attachment;
	private Integer barCode;
	private String shortDesc;
	private Integer exported;
	private Integer cancelled;
	private Integer inProcess;
	private String nextAproverId;
	private String interInstr;
	private String referenceNumber;

	private String productGrpCode;
	private String department;
	private Integer lineNumber;
	private String productCode;

	private List reasons;
	private List productGroups;
	private List chargebackTypes;
	private List subFunds;
	private List locations;

	private String vendorAddr1;
	private String vendorAddr2;
	private String vendorCity;
	private String vendorState;
	private String vendorPostCode;
	private String extTotal;
	private String distTotal;

	private byte[] attachmentFile;
	private String filename;
	private String attachmentDate;

	private String validatorMessages;

	private String accountErorMessage;

	private int accountStatus;
	private String invalidAccount;
	private String approverName;
	
	
	
	public String getItemPriceFormat() {
		return itemPriceFormat;
	}



	public void setItemPriceFormat(String itemPriceFormat) {
		this.itemPriceFormat = itemPriceFormat;
	}



	public String getApproverName() {
        return approverName;
    }

 

    public void setApproverName(String approverName) {
        this.approverName = approverName;
    }
	public String getInvalidAccount() {
		return invalidAccount;
	}

	public void setInvalidAccount(String invalidAccount) {
		this.invalidAccount = invalidAccount;
	}

	public int getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(int accountStatus) {
		this.accountStatus = accountStatus;
	}

	public String getAccountErorMessage() {
		return accountErorMessage;
	}

	public void setAccountErorMessage(String accountErorMessage) {
		this.accountErorMessage = accountErorMessage;
	}

	public String getValidatorMessages() {
		return validatorMessages;
	}

	public void setValidatorMessages(String validatorMessages) {
		this.validatorMessages = validatorMessages;
	}

	public String getNextInvoiceNumber() {
		return nextInvoiceNumber;
	}

	public void setNextInvoiceNumber(String nextInvoiceNumber) {
		this.nextInvoiceNumber = nextInvoiceNumber;
	}

	public String getNextBarcode() {
		return nextBarcode;
	}

	public void setNextBarcode(String nextBarcode) {
		this.nextBarcode = nextBarcode;
	}

	public String getInsertType() {
		return insertType;
	}

	public void setInsertType(String insertType) {
		this.insertType = insertType;
	}

	public byte[] getAttachmentFile() {
		return attachmentFile;
	}

	public void setAttachmentFile(byte[] attachmentFile) {
		this.attachmentFile = attachmentFile;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getAttachmentDate() {
		return attachmentDate;
	}

	public void setAttachmentDate(String attachmentDate) {
		this.attachmentDate = attachmentDate;
	}

	public String getAttachmentType() {
		return attachmentType;
	}

	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}

	private Vector getVectorFromMap(String vectorName) {
		Object obj = getValue(vectorName);
		Vector v = null;
		if (obj != null) {
			if (obj instanceof java.util.ArrayList) {
				v = new Vector((ArrayList) obj);
			} else {
				v = (Vector) getValue(vectorName);
			}
		}

		if (v == null) {
			v = new Vector(0);
			setValue(vectorName, v);
		}

		return v;
	}

	/**
	 * Get all of the GL items from the Vector and return them in an array of
	 * ChargebackBO objects.
	 * 
	 * @return an array of ChargebackBO objects
	 */
	public ChargebackBO[] getGlItems() {

		/*
		 * When dealing with indexed properties, Struts tends to favor arrays over
		 * Lists. So here we build an array from the Vector that is stored in the map.
		 *
		 * Normally, we would just call .toArray() on the Vector, however when we do
		 * that, Struts doesn't like to iterate through the array properly. It appears
		 * to get confused on the object types.
		 */

		Vector v = getVectorFromMap("glItems");

		ChargebackBO[] gl = new ChargebackBO[v.size()];

		for (int i = 0; i < v.size(); i++) {
			gl[i] = (ChargebackBO) v.get(i);
		}

		return gl;
	}

	private Object createObjectAtIndex(int idx, Object obj, String vectorName) {
		// Get the vector from the parent map
		Vector v = getVectorFromMap(vectorName);

		// Test to see if the specified index is larger than the vector's
		// maximum size. If it is, increase the vector size.
		if (idx > v.size() - 1) {
			v.setSize(idx + 1);
		}

		// Put the new item into the vector at the specified index
		v.set(idx, obj);

		// Return the new item
		return obj;
	}

	/**
	 * Get and return the ChargebackBO object stored at the specified index in the
	 * glItems Vector.
	 * 
	 * If the object does not exist in the Vector, a new one will be created there
	 * and returned.
	 * 
	 * Struts calls this method to populate the glItems property of the ActionForm.
	 * 
	 * @param idx the index of the ChargebackBO object to get from the vector
	 * @return the ChargebackBO object retrieved from the vector
	 */
	public ChargebackBO getGlItems(int idx) {
		Vector v = getVectorFromMap("glItems");

		ChargebackBO item;

		try {
			item = (ChargebackBO) v.get(idx);
		}
		// If the vector is totally empty, it will throw an exception
		catch (IndexOutOfBoundsException e) {
			item = (ChargebackBO) createObjectAtIndex(idx, new ChargebackBO(), "glItems");
		}
		// Otherwise it just returns a null object
		if (item == null) {
			item = (ChargebackBO) createObjectAtIndex(idx, new ChargebackBO(), "glItems");
		}

		return item;
	}

	/**
	 * Return all of the ChargebackBO objects in the Vector as a List
	 * 
	 * @return the ChargebackBO objects in the Vector as a List
	 */
	public List<ChargebackBO> getGlItemList() {
		return (List) getVectorFromMap("glItems");
	}

	/**
	 * Set the GL items in the Map with the values contained in the List parameter.
	 * 
	 * @param l the List of ChargebackBO objects to put into the map
	 */
	public void setGlItems(List l) {
		setValue("glItems", l);
	}

	/**
	 * Return all of the SL items as a List
	 * 
	 * @return
	 */
	public List<ChargebackBO> getSlItemList() {
		return (List) getVectorFromMap("slItems");
	}

	/**
	 * Get all of the SL items from the Vector and return them in an array of
	 * ChargebackBO objects.
	 * 
	 * @return
	 */
	public ChargebackBO[] getSlItems() {

		/*
		 * When dealing with indexed properties, Struts tends to favor arrays over
		 * Lists. So here we build an array from the Vector that is stored in the map.
		 *
		 * Normally, we would just call .toArray() on the Vector, however when we do
		 * that, Struts doesn't like to iterate through the array properly. It appears
		 * to get confused on the object types.
		 */

		Vector v = getVectorFromMap("slItems");

		ChargebackBO[] sl = new ChargebackBO[v.size()];

		for (int i = 0; i < v.size(); i++) {
			sl[i] = (ChargebackBO) v.get(i);
		}

		return sl;
	}

	/**
	 * Get and return the ChargebackBO object stored at the specified index in the
	 * slItems Vector.
	 * 
	 * If the object does not exist in the Vector, a new one will be created there
	 * and returned.
	 * 
	 * Struts calls this method to populate the slItems property of the ActionForm.
	 * 
	 * @param idx
	 * @return
	 */
	public ChargebackBO getSlItems(int idx) {
		Vector v = getVectorFromMap("slItems");
		ChargebackBO item;

		try {
			item = (ChargebackBO) v.get(idx);
		}
		// If the vector is totally empty, it will throw an exception
		catch (IndexOutOfBoundsException e) {
			item = (ChargebackBO) createObjectAtIndex(idx, new ChargebackBO(), "slItems");
		}
		// Otherwise it just returns a null object
		if (item == null) {
			item = (ChargebackBO) createObjectAtIndex(idx, new ChargebackBO(), "slItems");
		}

		return item;
	}

	/**
	 * Set the SL items in the Map with the values contained in the List parameter.
	 * 
	 * @param l
	 */
	public void setSlItems(List l) {
		setValue("slItems", l);
	}

	public String getDistTotal() {
		return distTotal;
	}

	public void setDistTotal(String distTotal) {
		this.distTotal = distTotal;
	}

	public String getExtTotal() {
		return extTotal;
	}

	public void setExtTotal(String extTotal) {
		this.extTotal = extTotal;
	}

	public String getVendorAddr1() {
		return vendorAddr1;
	}

	public void setVendorAddr1(String vendorAddr1) {
		this.vendorAddr1 = vendorAddr1;
	}

	public String getVendorAddr2() {
		return vendorAddr2;
	}

	public void setVendorAddr2(String vendorAddr2) {
		this.vendorAddr2 = vendorAddr2;
	}

	public String getVendorCity() {
		return vendorCity;
	}

	public void setVendorCity(String vendorCity) {
		this.vendorCity = vendorCity;
	}

	public String getVendorState() {
		return vendorState;
	}

	public void setVendorState(String vendorState) {
		this.vendorState = vendorState;
	}

	public String getVendorPostCode() {
		return vendorPostCode;
	}

	public void setVendorPostCode(String vendorPostCode) {
		this.vendorPostCode = vendorPostCode;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public List getLocations() {
		return locations;
	}

	public void setLocations(List locations) {
		this.locations = locations;
	}

	public List getSubFunds() {
		return subFunds;
	}

	public void setSubFunds(List subFunds) {
		System.out.println("--------subFunds----List---" + subFunds);
		this.subFunds = subFunds;
	}

	public List getReasons() {
		return reasons;
	}

	public void setReasons(List reasons) {
		this.reasons = reasons;
	}

	public List getProductGroups() {
		return productGroups;
	}

	public void setProductGroups(List productGroups) {
		this.productGroups = productGroups;
	}

	public List getChargebackTypes() {
		return chargebackTypes;
	}

	public void setChargebackTypes(List chargebackTypes) {
		System.out.println("--------chargebackTypes----List---" + chargebackTypes);
		this.chargebackTypes = chargebackTypes;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Double getExtension() {
		return extension;
	}

	public void setExtension(Double extension) {
		this.extension = extension;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getFin() {
		return fin;
	}

	public void setFin(String fin) {
		this.fin = fin;
	}

	public String getCa() {
		return ca;
	}

	public void setCa(String ca) {
		this.ca = ca;
	}

	public int getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(int documentNumber) {
		this.documentNumber = documentNumber;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public Integer getMemberCount() {
		return memberCount;
	}

	public void setMemberCount(Integer memberCount) {
		this.memberCount = memberCount;
	}

	public List getMemberList() {
		return memberList;
	}

	public void setMemberList(List memberList) {
		this.memberList = memberList;
	}

	public String getDocumentEncKey() {
		return documentEncKey;
	}

	public void setDocumentEncKey(String documentEncKey) {
		this.documentEncKey = documentEncKey;
	}

	public Date getCheckDate() {
		return checkDate;
	}

	public void setCheckDate(Date checkDate) {
		this.checkDate = checkDate;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getMimeType() {
		return mimeType;
	}

	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	public String getNotFound() {
		return notFound;
	}

	public void setNotFound(String notFound) {
		this.notFound = notFound;
	}

	public String getDcNumber() {
		return dcNumber;
	}

	public void setDcNumber(String dcNumber) {
		this.dcNumber = dcNumber;
	}

	public Integer getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Integer itemNumber) {
		this.itemNumber = itemNumber;
	}

	public Integer getItemPack() {
		return itemPack;
	}

	public void setItemPack(Integer itemPack) {
		this.itemPack = itemPack;
	}

	public String getItemSize() {
		return itemSize;
	}

	public void setItemSize(String itemSize) {
		this.itemSize = itemSize;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public String getItemUpc() {
		return itemUpc;
	}

	public void setItemUpc(String itemUpc) {
		this.itemUpc = itemUpc;
	}

	public String getItemSlot() {
		return itemSlot;
	}

	public void setItemSlot(String itemSlot) {
		this.itemSlot = itemSlot;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getSubFund() {
		return subFund;
	}

	public void setSubFund(String subFund) {
		this.subFund = subFund;
	}

	public Integer getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(Integer itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

	public Double getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(Double itemPrice) {
		this.itemPrice = itemPrice;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getDistLocNumber() {
		return distLocNumber;
	}

	public void setDistLocNumber(String distLocNumber) {
		this.distLocNumber = distLocNumber;
	}

	public String getProductGrp() {
		return productGrp;
	}

	public void setProductGrp(String productGrp) {
		this.productGrp = productGrp;
	}

	public Double getDistributionAmt() {
		return distributionAmt;
	}

	public void setDistributionAmt(Double distributionAmt) {
		this.distributionAmt = distributionAmt;
	}

	public String getVendorInvoice() {
		return vendorInvoice;
	}

	public void setVendorInvoice(String vendorInvoice) {
		this.vendorInvoice = vendorInvoice;
	}

	public Integer getAttachment() {
		return attachment;
	}

	public void setAttachment(Integer attachment) {
		this.attachment = attachment;
	}

	public Integer getBarCode() {
		return barCode;
	}

	public void setBarCode(Integer barCode) {
		this.barCode = barCode;
	}

	public String getShortDesc() {
		return shortDesc;
	}

	public void setShortDesc(String shortDesc) {
		this.shortDesc = shortDesc;
	}

	public Integer getExported() {
		return exported;
	}

	public void setExported(Integer exported) {
		this.exported = exported;
	}

	public Integer getCancelled() {
		return cancelled;
	}

	public void setCancelled(Integer cancelled) {
		this.cancelled = cancelled;
	}

	public Integer getInProcess() {
		return inProcess;
	}

	public void setInProcess(Integer inProcess) {
		this.inProcess = inProcess;
	}

	public String getNextAproverId() {
		return nextAproverId;
	}

	public void setNextAproverId(String nextAproverId) {
		this.nextAproverId = nextAproverId;
	}

	public String getInterInstr() {
		return interInstr;
	}

	public void setInterInstr(String interInstr) {
		this.interInstr = interInstr;
	}

	public String getProductGrpCode() {
		return productGrpCode;
	}

	public void setProductGrpCode(String productGrpCode) {
		this.productGrpCode = productGrpCode;
	}

	private List detailResults;
	// Page-specific properties not part of Map
	private List chargebacks;
	private String[] chargebackSelections = new String[] {};

	public List getDetailResults() {
		return detailResults;
	}

	public void setDetailResults(List detailResults) {
		this.detailResults = detailResults;
	}

	private List distributionResults;

	public List getDistributionResults() {
		return distributionResults;
	}

	public void setDistributionResults(List distributionResults) {
		this.distributionResults = distributionResults;
	}

	private boolean isNew;

	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		System.out.println("-----ChargebackCreateForm---invoiceNumber:::" + invoiceNumber);
		this.invoiceNumber = invoiceNumber;
	}

	public String getLocationNumber() {
		return locationNumber;
	}

	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}

	public String getOriginator() {
		return originator;
	}

	public void setOriginator(String originator) {
		this.originator = originator;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	public ChargebackBO[] getChargeback() {
		if (chargebacks == null) {
			chargebacks = new ArrayList();
		}
		ChargebackBO[] r = new ChargebackBO[chargebacks.size()];
		for (int i = 0; i < chargebacks.size(); i++) {
			r[i] = (ChargebackBO) chargebacks.get(i);
		}
		return r;
	}

	public void setChargeback(ChargebackBO[] r) {
		chargebacks = Arrays.asList(r);
	}

	public ChargebackBO getChargeback(int i) {
		if (chargebacks == null) {
			chargebacks = new ArrayList();
		}
		for (int j = chargebacks.size(); j <= i; j++) {
			chargebacks.add(j, new ChargebackBO());
		}
		return (ChargebackBO) chargebacks.get(i);
	}

	public void setChargeback(int i, ChargebackBO doc) {
		if (chargebacks == null) {
			chargebacks = new ArrayList();
		}
		chargebacks.add(i, doc);
	}

	public List getChargebacks() {
		return chargebacks;
	}

	public void setChargebacks(List doc) {
		chargebacks = doc;
	}

	public String[] getChargebackSelections() {
		return chargebackSelections;
	}

	public void setChargebackSelections(String[] strings) {
		chargebackSelections = strings;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.ActionForm#reset(org.apache.struts.action.
	 * ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	public void reset() {
		// Only Employees and Manufacturers can search by date

		// setValue("invoiceNumber","");
		setValue("vendorInvoice", "");
		setValue("referenceNumber", "");
		setValue("attachmentType", "");
		setValue("shortDesc", "");
		setValue("glItems[]", "");
		setValue("slItems[]", "");
		setValue("approver", "");
		setValue("extnTotal", "");
		setValue("distTotal", "");
		setSortBy("docnum");
		setSortOrder("asc");
		setShowAll(false);
	}
	
	public void resetForm(ChargebackCreateForm form) {
		
		form.setApprover("");
		form.setDistTotal("");
		form.setExtTotal("");
		form.setInterInstr("");
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.
	 * ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	public ActionMessages validate(HttpServletRequest request, ActionMessages errors) {
		// ActionMessages errors = new ActionMessages();
		String user = request.getRemoteUser();
		// String userType = null;
		Validations validations = new Validations();

		try {

		} catch (Exception e) {
			log.error("Exception in ChargebackSearchForm.validate()" + e);
		}

		return errors;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getPrdGrpCode() {
		return prdGrpCode;
	}

	public void setPrdGrpCode(String prdGrpCode) {
		this.prdGrpCode = prdGrpCode;
	}

	public Integer getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(Integer lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorAddress() {
		return vendorAddress;
	}

	public void setVendorAddress(String vendorAddress) {
		this.vendorAddress = vendorAddress;
	}

	/**
	 * @param cbk
	 */
	public void populateFormFromObject(ChargebackBO cbk) {
		this.isNew = false;
		this.setLocationNumber(cbk.getLocationNumber());
		this.setVendorId(cbk.getVendorId());
		this.setInvoiceNumber(cbk.getInvoiceNumber());
		this.setInvoiceDate(DateFunctions.formatDate(cbk.getInvoiceDate()));
		this.setTypeName(cbk.getTypeName());
		this.setCreatorId(cbk.getCreatorId());
		this.setPrdGrpCode(cbk.getPrdGrpCode());
		this.setReasonCode(cbk.getReasonCode());
		this.setApprover(cbk.getApprover());
		this.setDueDate(DateFunctions.formatDate(cbk.getDueDate()));
		this.setVendorName(cbk.getVendorName());
		this.setVendorAddr1(cbk.getVendorAddr1());
		this.setVendorAddr2(cbk.getVendorAddr2());
		this.setVendorCity(cbk.getVendorCity());
		this.setVendorState(cbk.getVendorState());
		this.setVendorPostCode(cbk.getVendorPostCode());
		this.setReferenceNumber(cbk.getReferenceNumber());
		this.setShortDesc(cbk.getShortDesc());
		this.setVendorInvoice(cbk.getVendorInvoice());
		this.setCreatorId(cbk.getCreatorId());

		this.setVendorInvoice(cbk.getVendorInvoice());
		this.setAttachment(cbk.getAttachment());
		this.setTypeId(cbk.getTypeId());
		this.setBarCode(cbk.getBarCode());
		this.setExported(cbk.getExported());
		this.setCancelled(cbk.getCancelled());
		this.setNextAproverId(cbk.getNextAproverId());
		this.setInterInstr(cbk.getInterInstr());
		this.setInProcess(cbk.getInProcess());
		this.setCompanyCode(cbk.getCompanyCode());
		this.setAccountNumber(cbk.getAccountNumber());
		this.setDistributionAmt(cbk.getDistributionAmt());
		this.setDistLocNumber(cbk.getDistLocNumber());
		this.setProductGrp(cbk.getProductGrp());
		this.setLineNumber(cbk.getLineNumber());
		this.setItemNumber(cbk.getItemNumber());
		this.setItemPack(cbk.getItemPack());
		this.setItemSize(cbk.getItemSize());
		this.setItemDesc(cbk.getItemDesc());
		this.setItemUpc(cbk.getItemUpc());
		this.setItemSlot(cbk.getItemSlot());
		this.setItemQuantity(cbk.getItemQuantity());
		this.setItemPrice(cbk.getItemPrice());
		this.setProductCode(cbk.getProductCode());
		this.setDcNumber(cbk.getDcNumber());
		this.setRegion(cbk.getRegion());
		this.setDivision(cbk.getDivision());
		this.setSubFund(cbk.getSubFund());

	}
	/*<result property="vendorId" column="vendorNumber" />
	<result property="vendorName" column="vendorName" />
	<result property="remitAddress" column="remitAddress1" />
	<result property="address2" column="Address2" />
	<result property="city" column="City" />
	<result property="stateCode" column="State" />
	<result property="zipCode" column="Zip" />
	*/
	public void populateFormFromObjectVendor(ChargebackCreateForm createForm, VendorBO vbo) {
		if (vbo != null && vbo.getVendorName() != null) {
			createForm.setVendorName(vbo.getVendorName());
		}
		String vendorCompleteAdd = null;
		if (vbo != null && vbo.getRemitAddress() != null) {
			vendorCompleteAdd = vbo.getRemitAddress();

		}
		if (vbo != null && vbo.getAddress2() != null) {
			vendorCompleteAdd = vendorCompleteAdd +" "+vbo.getAddress2();
			
		}
		if (vbo != null && vbo.getCity() != null) {
			
			vendorCompleteAdd = vendorCompleteAdd +" "+vbo.getCity() + "  " + vbo.getStateCode() + "  " + vbo.getZipCode();
		}
		createForm.setVendorAddress(vendorCompleteAdd);

	}

}