package com.unfi.cbk.forms;

import org.apache.log4j.Logger;

public class ChargebackInterfaceForm extends SortablePageableActionForm {

	static Logger log = Logger.getLogger(ChargebackInterfaceForm.class);
	private String file;
	private Double distributionAmt;
	private int successCount;
	private int failCount;

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public Double getDistributionAmt() {
		return distributionAmt;
	}

	public void setDistributionAmt(Double distributionAmt) {
		this.distributionAmt = distributionAmt;
	}

	public int getSuccessCount() {
		return successCount;
	}

	public void setSuccessCount(int successCount) {
		this.successCount = successCount;
	}

	public int getFailCount() {
		return failCount;
	}

	public void setFailCount(int failCount) {
		this.failCount = failCount;
	}
	
	

}
