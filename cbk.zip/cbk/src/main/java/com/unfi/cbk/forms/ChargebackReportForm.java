package com.unfi.cbk.forms;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.unfi.cbk.util.Constants;

/**
 * The MassApprovalsForm class is the struts action form used to search for
 * documents.
 *
 * @author vpil001
 * @since 1.0
 * 
 */
@Component
public class ChargebackReportForm extends SortablePageableActionForm {
	static Logger log = Logger.getLogger(ChargebackReportForm.class);

	
	private String date_a;
	private String date_b;
	private List reason;
	private String reasonCode;
	private String vendorId;
	private List searchResults;
	
	
	
	
	
	public List getSearchResults() {
		return searchResults;
	}

	public void setSearchResults(List searchResults) {
		this.searchResults = searchResults;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public List getReason() {
		return reason;
	}

	public void setReason(List reason) {
		this.reason = reason;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}


	public String getDate_a() {
		return date_a;
	}

	public void setDate_a(String date_a) {
		this.date_a = date_a;
	}

	public String getDate_b() {
		return date_b;
	}

	public void setDate_b(String date_b) {
		this.date_b = date_b;
	}

	
	
	public void reset(HttpServletRequest request) {
		// Only Employees and Manufacturers can search by date
		if (request.isUserInRole(Constants.EMPLOYEE_ROLE) || request.isUserInRole(Constants.MANUFACTURER_ROLE)) {
			setValue("dateCriteria", "1");
		}

		// Brokers are the only ones that are required to select a searchBy property
		if (request.isUserInRole(Constants.BROKER_ROLE)) {
			setValue("searchBy", "docnum");
		}

		setValue("documentOutputType", "pdf");
		setSortBy("invoiceNumber");
		setSortOrder("asc");
		setShowAll(false);
	}

}