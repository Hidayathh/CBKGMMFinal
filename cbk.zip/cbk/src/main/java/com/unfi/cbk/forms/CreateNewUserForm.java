package com.unfi.cbk.forms;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.unfi.cbk.bo.CreateNewUserBO;
import com.unfi.cbk.util.Constants;

/**
 * The CreateNewUserForm class is the struts action form used to create newUser.
 * 
 * @author vpil001
 * @since 1.0
 * 
 */
@Component
public class CreateNewUserForm extends SortablePageableActionForm {
	static Logger log = Logger.getLogger(CreateNewUserForm.class);

	private String userId;
	private String userName;
	private String useremailId;

	private List locations;
	private List roles;

	private List userRolesLocations;
	private Map userRolesLocationsMap;

	private String distRoles;
	private String distLocNumber;

	private String status;

	private List rolesByUserForMenuList;

	// private Integer[] menuAccess;

	private Integer[] userAssignedMenus;

	private List<String> menuAccess;
	private String errorMessage;
	
	

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<String> getMenuAccess() {
		return menuAccess;
	}

	public void setMenuAccess(List<String> menuAccess) {
		this.menuAccess = menuAccess;
	}

	public Integer[] getUserAssignedMenus() {
		return userAssignedMenus;
	}

	public void setUserAssignedMenus(Integer[] userAssignedMenus) {
		this.userAssignedMenus = userAssignedMenus;
	}

	public List getRolesByUserForMenuList() {
		return rolesByUserForMenuList;
	}

	public void setRolesByUserForMenuList(List rolesByUserForMenuList) {
		this.rolesByUserForMenuList = rolesByUserForMenuList;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDistRoles() {
		return distRoles;
	}

	public void setDistRoles(String distRoles) {
		this.distRoles = distRoles;
	}

	public String getDistLocNumber() {
		return distLocNumber;
	}

	public void setDistLocNumber(String distLocNumber) {
		this.distLocNumber = distLocNumber;
	}

	public Map getUserRolesLocationsMap() {
		return userRolesLocationsMap;
	}

	public void setUserRolesLocationsMap(Map userRolesLocationsMap) {
		this.userRolesLocationsMap = userRolesLocationsMap;
	}

	public List getUserRolesLocations() {
		return userRolesLocations;
	}

	public void setUserRolesLocations(List userRolesLocations) {
		this.userRolesLocations = userRolesLocations;
	}

	private List userDetails;

	public List getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(List userDetails) {
		this.userDetails = userDetails;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUseremailId() {
		return useremailId;
	}

	public void setUseremailId(String useremailId) {
		this.useremailId = useremailId;
	}

	public List getLocations() {
		return locations;
	}

	public void setLocations(List locations) {
		this.locations = locations;
	}

	public List getRoles() {
		return roles;
	}

	public void setRoles(List roles) {
		this.roles = roles;
	}

	private boolean isNew;

	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	private Object createObjectAtIndex(int idx, Object obj, String vectorName) {
		// Get the vector from the parent map
		Vector v = getVectorFromMap(vectorName);
		System.out.println("--------in  createObjectAtIndex()-----");
		// Test to see if the specified index is larger than the vector's
		// maximum size. If it is, increase the vector size.
		if (idx > v.size() - 1) {
			v.setSize(idx + 1);
		}

		// Put the new item into the vector at the specified index
		v.set(idx, obj);

		// Return the new item
		return obj;
	}

	/**
	 * Get all of the locationRoles from the Vector and return them in an array of
	 * CreateNewUserBO objects.
	 * 
	 * @return an array of CreateNewUserBO objects
	 */
	public CreateNewUserBO[] getLocationRoles() {

		/*
		 * When dealing with indexed properties, Struts tends to favor arrays over
		 * Lists. So here we build an array from the Vector that is stored in the map.
		 *
		 * Normally, we would just call .toArray() on the Vector, however when we do
		 * that, Struts doesn't like to iterate through the array properly. It appears
		 * to get confused on the object types.
		 */
		// System.out.println("-----in
		// getLocationRoles()-----CreateNewUSerForm.java---");
		Vector v = getVectorFromMap("locationRoles");

		CreateNewUserBO[] gl = new CreateNewUserBO[v.size()];

		for (int i = 0; i < v.size(); i++) {
			gl[i] = (CreateNewUserBO) v.get(i);
		}

		return gl;
	}

	/**
	 * Get and return the CreateNewUserBO object stored at the specified index in
	 * the glItems Vector.
	 * 
	 * If the object does not exist in the Vector, a new one will be created there
	 * and returned.
	 * 
	 * Struts calls this method to populate the glItems property of the ActionForm.
	 * 
	 * @param idx the index of the CreateNewUserBO object to get from the vector
	 * @return the CreateNewUserBO object retrieved from the vector
	 */
	public CreateNewUserBO getLocationRoles(int idx) {
		Vector v = getVectorFromMap("locationRoles");

		CreateNewUserBO item;
		// System.out.println("-----getLocationRoles(inf idx)------");
		try {
			item = (CreateNewUserBO) v.get(idx);
		}
		// If the vector is totally empty, it will throw an exception
		catch (IndexOutOfBoundsException e) {
			item = (CreateNewUserBO) createObjectAtIndex(idx, new CreateNewUserBO(), "locationRoles");
		}
		// Otherwise it just returns a null object
		if (item == null) {
			item = (CreateNewUserBO) createObjectAtIndex(idx, new CreateNewUserBO(), "locationRoles");
		}
		System.out.println("--getLocationRoles(int idx----item---" + item);
		return item;
	}

	/**
	 * Return all of the CreateNewUserBO objects in the Vector as a List
	 * 
	 * @return the CreateNewUserBO objects in the Vector as a List
	 */
	public List<CreateNewUserBO> getLocationRolesList() {
		return (List) getVectorFromMap("locationRoles");
	}

	/**
	 * Set the GL items in the Map with the values contained in the List parameter.
	 * 
	 * @param l the List of CreateNewUserBO objects to put into the map
	 */
	public void setLocationRoles(List l) {
		setValue("locationRoles", l);
	}

	private Vector getVectorFromMap(String vectorName) {
		Object obj = getValue(vectorName);
		Vector v = null;
		if (obj != null) {
			if (obj instanceof java.util.ArrayList) {
				v = new Vector((ArrayList) obj);
			} else {
				v = (Vector) getValue(vectorName);
			}
		}

		if (v == null) {
			v = new Vector(0);
			setValue(vectorName, v);
		}

		return v;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.ActionForm#reset(org.apache.struts.action.
	 * ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	public void reset(HttpServletRequest request) {
		// Only Employees and Manufacturers can search by date
		if (request.isUserInRole(Constants.EMPLOYEE_ROLE) || request.isUserInRole(Constants.MANUFACTURER_ROLE)) {
			setValue("dateCriteria", "1");
		}

		// Brokers are the only ones that are required to select a searchBy property
		if (request.isUserInRole(Constants.BROKER_ROLE)) {
			setValue("searchBy", "docnum");
		}

	}

	public void populateFormFromObject(CreateNewUserBO cbk) {
		this.isNew = false;
		this.setUserId(cbk.getUserId());
		this.setUserName(cbk.getUserName());
		this.setUseremailId(cbk.getUseremailId());
		this.setStatus(cbk.getStatus());
	}

}