/**
 * 
 */
package com.unfi.cbk.resources;

/*
 *  */
public class PackageInfo {

}
