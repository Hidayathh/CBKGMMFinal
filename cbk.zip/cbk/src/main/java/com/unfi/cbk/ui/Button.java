package com.unfi.cbk.ui;

public class Button {
	private String alt;
	private String text;
	private String url;
	private String onClick;
	private Roles roles;

	public Button(String text, String alt, String URL, String onClick) {
		this.setAlt(alt);
		this.setText(text);
		this.setUrl(URL);
		this.setOnClick(onClick);
	}

	public Button() {

	}

	public String getOnClick() {
		return onClick;
	}

	public String getAlt() {
		// default the title to the text of the button
		if (alt == null) {
			return this.getText();
		}

		return alt;
	}

	public String getUrl() {
		return url;
	}

	public void setOnClick(String string) {
		onClick = string;
	}

	public Roles getRoles() {
		if (roles == null) {
			roles = new Roles();
		}
		return roles;
	}

	public void setRoles(Roles roles) {
		this.roles = roles;
	}

	public void setAlt(String string) {
		alt = string;
	}

	public void setUrl(String string) {
		url = string;
	}

	// set button access control
	public boolean hasAccess() {
		return true;
	}

	public boolean isLarge() {
		if (this.getText().length() > 9) {
			return true;
		}
		return false;
	}

	public String getButtonStr() {
		StringBuffer buf = new StringBuffer();
		buf.append("<a href=\"");

		// decide if it's a link or an onClick button
		if (this.getUrl() != null && !this.getUrl().equals("")) {
			buf.append(this.getUrl());
		} else {
			buf.append("javascript:;");
		}
		buf.append("\">");

		// now build up the button
		buf.append("<button class=\"long\" type=\"button\"");
		// decide if it's a link or an onClick button
		if (this.getOnClick() != null && !this.getOnClick().equals("")) {
			buf.append(" onClick=\"");
			buf.append(this.getOnClick());
			buf.append("\"");
		} else {
			buf.append(" onClick=\"javascript:document.location='");
			buf.append(this.getUrl());
			buf.append("'\"");
		}
		// add the rest of the button and link
		buf.append(" title=\"" + this.getAlt() + "\">" + this.getText() + "</button></a>");

		return buf.toString();
	}

	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append("--- " + this.getAlt() + " ---\n");
		buf.append("URL: " + this.getUrl() + "\n");
		buf.append("onClick: " + this.getOnClick() + "\n");
		buf.append(this.getRoles().toString() + "\n");
		return buf.toString();
	}

	public String getText() {
		return text;
	}

	public void setText(String string) {
		text = string;
	}

}