
/**
 * 
 */

package com.unfi.cbk.util;

import org.owasp.encoder.Encode;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.codecs.DB2Codec;

/**
 * @author yhp6y2l
 *
 */
public final class ESAPIUtil {
	private static DB2Codec db2Codec = null;

	private ESAPIUtil() {
	}

	public static String encode(String message) {
		if (message == null || message.isEmpty()) {
			return message;
		}
		message = message.replace('\n', '_').replace('\r', '_').replace('\t', '_');
		// message = Encode.forHtmlContent(message );
		return message;
	}

	/**
	 * Encode input for use in a DB2 SQL query.
	 * 
	 * @param pText
	 * @return
	 */
	public static final String encodeForDB2SQL(final String pText) {
		String ret = null;

		if (pText != null) {
			ret = ESAPI.encoder().encodeForSQL(getDB2Codec(), pText);
		}

		return ret;
	}

	private static DB2Codec getDB2Codec() {
		if (db2Codec == null) {
			synchronized (ESAPIUtil.class) {
				// Make sure another thread didn't instantiate the db2Codec.
				if (db2Codec == null) {
					db2Codec = new DB2Codec();
				}
			}
		}
		return db2Codec;
	}

	public static String encodeforXSS(String message) {
		if (message == null || message.isEmpty()) {
			return message;
		}

		return Encode.forHtmlContent(message);

	}
}
