package com.unfi.cbk.util;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.lang.Nullable;
import org.springframework.util.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * Common utilities for interacting with the Spring framework
 * 
 * @author yhp6y2l
 * @version 1.0
 */
public class SpringUtils {

	/**
	 * Retrieve a Spring-managed bean from the current application context using a
	 * HttpServletRequest object.
	 * 
	 * @param request  the HttpServletRequest object to use when looking for the
	 *                 bean
	 * @param beanName the name of the Spring-managed bean to retrieve from the
	 *                 context
	 * @return the Spring-managed bean
	 */
	public static Object getBeanFromRequest(HttpServletRequest request, String beanName) {
		ServletContext servletContext = request.getSession().getServletContext();
		WebApplicationContext ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
		return ctx.getBean(beanName);
	}

	/**
	 * Retrieve a Spring-managed bean from the current application context using a
	 * ServletContext object.
	 * 
	 * @param servletContext the ServletContext object to use when looking for the
	 *                       bean
	 * @param beanName       the name of the Spring-managed bean to retrieve from
	 *                       the context
	 * @return the Spring-managed bean
	 */
	public static Object getBeanFromServletContext(ServletContext servletContext, String beanName) {
		WebApplicationContext ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
		return ctx.getBean(beanName);
	}

	private final static String FOLDER_SEPARATOR_FORWARD = "/";
	public static String getFilename(@Nullable String path) {
		if (path == null) {
			return null;
		}
		path = StringUtils.cleanPath(path);

//		if(path.contains(FOLDER_SEPARATOR_BACKWARD))
//		{
//			path = path.replaceAll(FOLDER_SEPARATOR_BACKWARD, FOLDER_SEPARATOR_FORWARD);
//		}

		int separatorIndex = path.lastIndexOf(FOLDER_SEPARATOR_FORWARD);
		return (separatorIndex != -1 ? path.substring(separatorIndex + 1) : path);
	}
}