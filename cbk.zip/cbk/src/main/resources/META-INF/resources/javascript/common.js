/*
	Common JavaScript functions
*/

function getFormObj() {
	return document.forms[1];
}		

function getCheckedValue(radioObj) {
	if ( radioObj ) {
		if( radioObj.length == undefined ) {
			if( radioObj.checked ) {
				return radioObj.value;
			}
		}
		for( var i = 0; i < radioObj.length; i++ ) {
			if( radioObj[i].checked ) {
				return radioObj[i].value;
			}
		}
	}
	return undefined;
}	

function showDiv(ObjectID){			
	if (document.getElementById(ObjectID) !=  null){
		var div = document.getElementById(ObjectID);
		div.style.visibility="visible";			
	}
}	

function hideDiv(ObjectID){
	if (document.getElementById(ObjectID) != null){
		var div = document.getElementById(ObjectID);	
		div.style.visibility="hidden";
	}
}

function changeRadio(field, radiobutton) {
	var radios = document.getElementsByName(field);
	radios[radiobutton].checked = true;
}

function clearDiv(divID, fldType){
		var d = divID;
		var f = fldType;
		if (document.getElementById(d) != null){
			var div = document.getElementById(d);
			if (div.getElementsByTagName(f) != null){
				var flds = div.getElementsByTagName(f);
				if (flds[0]){
					for (var i=0; i<flds.length;i++){
						flds[i].value="";
					}
				}
				else{
					flds.value="";
				}
			}
		}
}
							
function clearValue(objectName){	
		if (document.getElementById(objectName) != null){
			var ctl = document.getElementById(objectName);
			ctl.value = "";
		}
}

function validateDecimal(objTxt,objTxtName){
	var errMsg = '';
	var x=objTxt;
	var anum=/^((\+|-)?\d*(\.\d{1,2})?|(\+|-)?\d+(\.\d{1,2})?)$/
	if (objTxt != "" && objTxt != null && anum.test(x)) {
		errMsg='';
	} else {
    	errMsg = objTxtName+" should be a valid dollar amount\n";
    }
	return errMsg;
}

function validateNumber(objTxt,objTxtName){
	var errMsg = '';
	var x=objTxt;
	var anum=/^((\+|-)?\d*(\.\d{1,2})?|(\+|-)?\d+(\.\d{1,2})?)$/
	if (objTxt != "" && objTxt != null && anum.test(x)) {
		errMsg='';
	} else {
    	errMsg = objTxtName+" should be a numeric value\n";
    }
	return errMsg;
}

//Validate if String Value, return false if it is an empty 
function validateString(objTxt,objTxtName){
	var errMsg = '';
    if (objTxt == null || objTxt == "") {
    	errMsg = objTxtName+" cannot be empty\n";
	}
	return errMsg;
}

function validateFilenameLength(filename, attachmentType, maxLength) {
	var errMsg = '';
	if (filename != null) {
		var lastSlash = filename.lastIndexOf("\\");
		var actualFilename = filename.substring(lastSlash+1, filename.length);
		if (actualFilename.length > maxLength) {
			errMsg = "The " + attachmentType + " filename must be less than 50 characters.";
		}
	}
	return errMsg;
}

function setCursor(fieldName) {
	if (document.getElementsByName(fieldName)[0] != undefined && document.getElementsByName(fieldName)[0].type != "hidden") {
		document.getElementsByName(fieldName)[0].focus();
	}
}

//Trim spaces
function trim(s) {
    return s.replace( /^\s*/, "" ).replace( /\s*$/, "" );
} 

function trim2(str){
	var trimmed = str.replace(/^\s+|\s+$/g, '') ;
	return trimmed;
}

 function checkDates()
    {
    
      var frmDate=document.getElementsByName("fromDate")[0].value;      
      var nfromDate=new Date(frmDate);
     
      var toDate=document.getElementsByName("toDate")[0].value;     
      var nToDate=new Date(toDate);
     
      var today=new Date();
    
      if(nfromDate > nToDate)
      {
        alert("From Date can not be greater than To Date!!");
        return false;
      }
   
      var diff=monthsBetween(frmDate, today);
      var diff1=monthsBetween(toDate, today);      
   
      if(diff>18)
      {
      alert("From Date should be upto 18 months prior to Current Date!!");
      return false;
      }
      else
      {
       if(diff1>18)
       {
       alert("To Date should be upto 18 months prior to Current Date!!");
       return false;
       }
      }
 
      return true;
      
    }
    function monthsBetween(frmDate, today) { 
  
     
         var number = 0;
         var fromDate=new Date(frmDate);         
         if (today.getFullYear() > fromDate.getFullYear())
          { 
             number = number + (today.getFullYear() - fromDate.getFullYear() - 1) * 12; 
          
          } else {
               return today.getMonth() - fromDate.getMonth(); 
          }  
          if (today.getMonth() > fromDate.getMonth())
          { 
            number = number + 12 + today.getMonth() - fromDate.getMonth(); 
           
          }
         else 
         {   
          number = number + (12 - fromDate.getMonth()) + today.getMonth();
         } 
       return number;
   }

	function saveChargeback() {
		 
		var itemTableId = document.getElementById('glItems');
		var itemRows = itemTableId.rows.length - 1;
		var distTableId = document.getElementById('slItems');
		var rows = distTableId.rows.length - 1;
		var itemCount = 0;
		var distriCount = 0;
		var doc = document.forms[1];
		var newLine = "\r\n";
		
		
	var type = document.getElementById("typeId");
	var typeSel = type.options[type.selectedIndex].value;
	var location = document.getElementById('locationNumber').value;
	var vendor  =  document.getElementById('vendorId').value;
	var desc = document.getElementById("shortDesc").value;
	var reason = document.getElementById("reasonCode");
	var reasonSel = reason.options[reason.selectedIndex].value;
	var prodGrp = document.getElementById("prdGrpCode");
	var prodGrpSel = prodGrp.options[prodGrp.selectedIndex].value;
	var refNum = document.getElementById("referenceNumber").value;
	
	
				

	if (typeSel == '' || location == '' || vendor == '' || desc == '' || reasonSel == '' || (refNum == '' && typeSel == 2) || prodGrpSel == '') {
		var message = '';
			  if(location == '') {message = newLine + "Location Number"}
		      if (typeSel == '') {message = message + newLine + "Chargeback type"}
              if(vendor == '') {message = message + newLine + "Vendor Number"}
              if (reasonSel == '') {message = message + newLine + "Reason for Chargeback"}
              if(refNum == '' && typeSel == 2) {message = message + newLine + "Return Auth"}
              if (prodGrpSel == '') {message = message + newLine + "Prodcut Group"}
              if (desc == '') {message = message + newLine + "Brief Description"}
              
              alert("Please Select/Enter: "+newLine+message);

        if (location == '') {
	         document.getElementById('locationNumber').focus();
	         return false;
	    }
        else if (typeSel == ''){
             document.getElementById("typeId").focus();
             return false;
        }
		else if (vendor == '') {
			document.getElementById('vendorId').focus();
			return false;
		}
		else if (reasonSel == '') {
			document.getElementById("reasonCode").focus();
			return false;
		} 
		else if(typeSel == 2){
					if (refNum == "") {
						document.getElementById("referenceNumber").focus();
						return false;
					}
		}
		else if(prodGrpSel == '') {
			document.getElementById("prdGrpCode").focus();
			return false;
		}
		else if (desc == '') {
			document.getElementById("shortDesc").focus();
			return false;
		}
	}
	//get today's date in string
	var todayDate = new Date();
	//need to add one to get current month as it is start with 0
	var todayMonth = todayDate.getMonth() + 1;
	var todayDay = todayDate.getDate();
	var todayYear = todayDate.getFullYear();
	var curDateText = todayMonth + "/" + todayDay + "/" + todayYear;
	var dueDtText = document.getElementById('dueDate').value;

	var dueDt = Date.parse(dueDtText);
	var curDate = Date.parse(curDateText);

	 if(dueDt < curDate)
	{
		alert("You have entered a date in the past.  Please enter a valid due date.");
		document.getElementById('dueDate').focus();
		return false;			
	} 

    var file = document.getElementById('file').value;
    var type = document.getElementById('attachmentType').value;
    if (file != "") {
           if (type == 0) {
                  alert("Please Select Attachment Type(Internal/External)");
                  document.getElementById("attachmentType").focus();
                  return false;
           }
    } else if (file == "") {
           if (type == 1 || type == -1) {
                  alert("Please Select Your Attachment");
                  document.getElementById("file").focus();
                  return false;
           }
           
    }
	var ext  = /(\.pdf|\.xls)$/i;
	if (file != "") {
		if(!ext.exec(file))
			{
			alert("The document trying to attach won't appear correctly in NetSearch."+newLine+"Preferred Attachment files are .pdf or .xls");							
			}
	}

	for (var i = 1; i <= itemRows; i++) {
		var itemDesc = document.getElementsByName('glItems[' + i + '].itemDesc')[0].value;
	if(itemDesc == ''){
		itemCount++;
		}
	}
	for (var j = 1; j <= rows; j++) {
		var distLocNumb = document.getElementsByName('slItems[' + j + '].distLocNumber')[0].value;
	if (distLocNumb == ''){
		distriCount++;
		}		
	}
		var flag =0;
		var invoice =  document.getElementById('invoiceNumber').value;
		var location = document.getElementById('locationNumber').value;
		if(invoice != '')
		    {
	    	   var data = 'invoice='
	    	         + encodeURIComponent(invoice)
	    	         + '&location='
	    	         + encodeURIComponent(location);
	    	          $.ajax({
	    	         url : 'validateInvoiceNumber?action=validateInvoice',
	    	         type : 'GET',
	    	         dataType : 'json',
	    	         data: data,
	    	         async:false,
	    	         contentType: 'application/json; charset=utf-8',
	    	         success: function(data) { 
	    	             if(data){
	    	            	 flag =1;
	    	            	// document.getElementById("result").className = "error";
	    	            	alert("The invoice number you have entered has already been used.  Please enter a different Invoice number.")
	    	                  // $('#result').html("Invoice number already exists.");
	    	                     document.getElementById('invoiceNumber').focus();
	    	                     
	    	                 }
	    	         },
	    	         error : function() {
	    	             alert("Unable to validate Invoice number.");
	    	         },
	    	     });
		    }

			if(flag == 1){return false;} else if(invoice == ''){
			
				alert("Please enter invoice number.")
             	document.getElementById('invoiceNumber').focus();
             	return false;
			} else if (itemRows>=1 && itemRows == itemCount && rows == distriCount) {
					var aType = document.getElementById('attachmentType').value;
	                if (aType == 0){
	                document.getElementById("file").disabled = false;
	                }
					doc.action = "createChargeback?action=save";
				    doc.submit();
			} else { 
			var itemTableId = document.getElementById('glItems');
			var itemRows = itemTableId.rows.length - 1;
			var message = '';	
			if(itemRows == 1){

				//var  returnMerch = 2;
				var itemNum = document.getElementsByName('glItems[' + itemRows + '].itemNumber')[0].value;
				var dcNumber  = document.getElementsByName('glItems[' + itemRows + '].dcNumber')[0].value;
				if(typeSel == 2)
				{
					if(dcNumber == '')
					{
						alert("Please enter DC  for Item Line - " +itemRows);
						document.getElementsByName('glItems[' + itemRows + '].dcNumber')[0].focus();
						return false;
					}
					else if(itemNum == '')
					{
						alert("Please enter Item # for Item Line - " +itemRows);
						document.getElementsByName('glItems[' + itemRows + '].itemNumber')[0].focus();
						return false;
					}
				}
				
				var itemDesc = document.getElementsByName('glItems[' + itemRows + '].itemDesc')[0].value;
				
				if (itemDesc == '') {
					alert("Please enter Description for Item Line - " + itemRows)
					document.getElementsByName('glItems[' + itemRows + '].itemDesc')[0].focus();
					return false;
				}
			}
		for (var i = 1; i < itemRows; i++) {
			
			var itemNum = document.getElementsByName('glItems[' + i + '].itemNumber')[0].value;
			var dcNumber = document.getElementsByName('glItems[' + i + '].dcNumber')[0].value;
			var itemDesc = document.getElementsByName('glItems[' + i + '].itemDesc')[0].value;
			var itemQuantity = document.getElementsByName('glItems[' + i + '].itemQuantity')[0].value;
			var itemPriceFormat = document.getElementsByName('glItems[' + i + '].itemPriceFormat')[0].value;
			
			if(itemNum != '' || dcNumber != '' || itemDesc != '' ||  itemQuantity != '' || itemPriceFormat != '')
			{

				if(typeSel == 2)
				{
					if (dcNumber == '') {message = "DC  for Item Line - "+i}
		            if(itemNum == '') {message = message + newLine + "Item # for Item Line - "+i}
		            if (dcNumber == '' || itemNum == ''){
		            alert("Please enter: "+newLine+message);
		            }
		            if (dcNumber == '') {
		            	document.getElementsByName('glItems[' + i + '].dcNumber')[0].focus();
		   	         return false;
		   	        }
		            else if (itemNum == ''){
		        	   document.getElementsByName('glItems[' + i + '].itemNumber')[0].focus();
		                return false;
		            }
				}
				
				var itemDesc = document.getElementsByName('glItems[' + i + '].itemDesc')[0].value;
				var itemQuantity = document.getElementsByName('glItems[' + i + '].itemQuantity')[0].value;
				var itemPriceFormat = document.getElementsByName('glItems[' + i + '].itemPriceFormat')[0].value;
				if (itemDesc == '') {
					alert("Please enter Description for Item Line - " + i)
					document.getElementsByName('glItems[' + i + '].itemDesc')[0].focus();
					return false;
				}
				else if (itemQuantity == '') {
					alert("Please enter Quantity for Item Line - " + i)
					document.getElementsByName('glItems[' + i + '].itemQuantity')[0].focus();
					return false;
				}
				else if (itemPriceFormat == '') {
					alert("Please enter Price for Item Line - " + i)
					document.getElementsByName('glItems[' + i + '].itemPriceFormat')[0].focus();
					return false;
				}
	
			}	//IF END

		}//FOR END
		var typeSel = document.getElementById("typeId");
		var typeSelValue = typeSel.options[typeSel.selectedIndex].value;
		if (typeSelValue != 2) {
			var distTableId = document.getElementById('slItems');
			var rows = distTableId.rows.length - 1;

			if(rows == 1){
				var distLocNumb = document.getElementsByName('slItems[' + rows
						+ '].distLocNumber')[0].value;
				if (distLocNumb == '') {
					alert("Please select Location on Distribution Line - " + rows)
					return false;
				}
				var productGrp = document.getElementsByName('slItems[' + rows
						+ '].productGrp')[0].value;
				if (productGrp == '') {
					alert("Please enter Product Group on Distribution Line - " + rows)
					return false;
				}
				var accountNumber = document.getElementsByName('slItems[' + rows
						+ '].accountNumber')[0].value;
				if (accountNumber == '') {
					alert("Please enter Account Number on Distribution Line - " + rows)
					return false;
				}
				var amt = document.getElementsByName('slItems[' + rows
						+ '].distributionAmt')[0].value;
				if (amt == '') {
					alert("Please enter Amount on Distribution Line - " + rows)
					return false;
				}
			}
			
			for (var j = 1; j < rows; j++) {

				var distLocNumb = document.getElementsByName('slItems[' + j
						+ '].distLocNumber')[0].value;
				var productGrp = document.getElementsByName('slItems[' + j
						+ '].productGrp')[0].value;
				var accountNumber = document.getElementsByName('slItems[' + j
						+ '].accountNumber')[0].value;
				var amt = document.getElementsByName('slItems[' + j
						+ '].distributionAmt')[0].value;
				if(distLocNumb != '' || productGrp != '' || accountNumber != '' ||  amt != '0.00')
				{
					if (distLocNumb == '') {
						alert("Please select Location on Distribution Line - " + j)
						return false;
					}
					
					if (productGrp == '') {
						alert("Please enter Product Group on Distribution Line - " + j)
						return false;
					}
					
					if (accountNumber == '') {
						alert("Please enter Account Number on Distribution Line - " + j)
						return false;
					}
					
					if (amt == '') {
						alert("Please enter Amount on Distribution Line - " + j)
						return false;
					}
				}
			}
		}
		//var doc = document.forms[1];

		var detailTotal = document.getElementById('extTotal').value;
		var distributionTotal = document.getElementById('distTotal').value;
		var invoiceNumber = document.getElementById('invoiceNumber').value;
		//2
		var defaultAmount = 5000;
		var amount = 0;
		var tempDetailTotal = detailTotal;
		detailTotal = detailTotal.replaceAll(',','');
		detailTotal = parseFloat(detailTotal);
		distributionTotal = distributionTotal.replaceAll(',','');
		if(detailTotal == amount)
		{
			alert("Cannot save a chargeback with no amount.");
			return false;
		}
		
		var returnMerc = 2;
		if (typeSelValue == returnMerc) 
		{
            var aType = document.getElementById('attachmentType').value;
            if (aType == 0){
            document.getElementById("file").disabled = false;
            }
            var itemTableId = document.getElementById('glItems');
            var itemRows = itemTableId.rows.length - 1;
            		
            for (var i = 1; i < itemRows; i++) {
                var actualExt = document.getElementsByName('glItems[' + i + '].extension')[0].value;
                actualExt = actualExt.replaceAll(',','');
                actualExt = parseFloat(actualExt);
                document.getElementsByName('glItems[' + i + '].extension')[0].value = actualExt;
            }
            var distTableId = document.getElementById('slItems');
            var rows = distTableId.rows.length - 1;
            for (var j = 1; j <= rows; j++) {
                var actualDamount = document.getElementsByName('slItems[' + j + '].distributionAmt')[0].value;
                if (actualDamount != '0.00') {
                actualDamount = actualDamount.replaceAll(',','');
                actualDamount = parseFloat(actualDamount);
                document.getElementsByName('slItems[' + j + '].distributionAmt')[0].value = actualDamount;
                } else {
                	document.getElementsByName('slItems[' + j + '].distributionAmt')[0].value = "";
                    }
            }
			if (detailTotal > 0) {
				alert(" You are saving the chargeback for the total amount:  $ "
						+ tempDetailTotal
						+ "  for the  invoice number: "
						+ invoiceNumber);

				doc.action = "createChargeback?action=save&detailTotal=" + detailTotal;
				doc.submit();
			} 

		} else {
			if (detailTotal == distributionTotal) {
	              var aType = document.getElementById('attachmentType').value;
                  if (aType == 0){
                  document.getElementById("file").disabled = false;
                  }
                  var itemTableId = document.getElementById('glItems');
                  var itemRows = itemTableId.rows.length - 1;
                  for (var i = 1; i < itemRows; i++) {
                      var actualExt = document.getElementsByName('glItems[' + i + '].extension')[0].value;
                      actualExt = actualExt.replaceAll(',','');
                      actualExt = parseFloat(actualExt);
                      document.getElementsByName('glItems[' + i + '].extension')[0].value = actualExt;
                  }
                  var distTableId = document.getElementById('slItems');
                  var rows = distTableId.rows.length - 1;
                  for (var j = 1; j <= rows; j++) {
                      var actualDamount = document.getElementsByName('slItems[' + j + '].distributionAmt')[0].value;
                      actualDamount = actualDamount.replaceAll(',','');
                      actualDamount = parseFloat(actualDamount);
                      if (actualDamount != '0.00') {
                      document.getElementsByName('slItems[' + j + '].distributionAmt')[0].value = actualDamount;
                      } else {
                      	document.getElementsByName('slItems[' + j + '].distributionAmt')[0].value = "";
                        }
                  }
				if (detailTotal > 0) {
					alert(" You are saving the chargeback for the total amount:  $ "
							+ tempDetailTotal
							+ "  for the  invoice number: "
							+ invoiceNumber);
					doc.action = "createChargeback?action=save&detailTotal=" + detailTotal;
					doc.submit();
				} 
			} else {
				alert(" Distribution Total and Detail Total do not match.")
				return false;
			}
		}
	} 
} //end of save chargeback

